import type {
  TrainingTargetSelection,
  TutorAxes,
  TutorFinding,
  TutorOutputSettings,
  TutorRecipe,
  TutorSentenceLength
} from './contract.js';
import { TUTOR_MAP_VERSION } from './map.js';
import { validateTutorSelection } from './selection.js';

export const TUTOR_RECIPE_CODES = {
  exampleCountOutOfRange: 'recipe.exampleCountOutOfRange',
  minimumWordsOutOfRange: 'recipe.minimumWordsOutOfRange',
  maximumWordsOutOfRange: 'recipe.maximumWordsOutOfRange',
  minimumAboveMaximum: 'recipe.minimumAboveMaximum',
  invalidTolerance: 'recipe.invalidTolerance',
  scenarioTooLong: 'recipe.scenarioTooLong',
  questionTooLong: 'recipe.questionTooLong'
} as const;

export interface TutorRecipeInput {
  selection: readonly TrainingTargetSelection[];
  /**
   * Build a lesson with no map target, from the reader's question alone.
   *
   * Off by default, so every existing caller keeps the rule that a lesson teaches one named
   * thing. A recipe built this way carries no `primaryTarget`, and validation skips the
   * checks that compare a lesson's choice against a request that was never made.
   */
  allowNoPrimary?: boolean;
  output: Omit<TutorOutputSettings, 'sentenceLength'> & {
    sentenceLength: Omit<TutorSentenceLength, 'tolerance'> & { tolerance?: number };
  };
  axes: TutorAxes;
  scenario?: string;
  question?: string;
}

export class TutorRecipeError extends Error {
  public constructor(public readonly findings: TutorFinding[]) {
    super(findings[0]?.code ?? 'recipe.invalid');
    this.name = 'TutorRecipeError';
  }
}

export function buildTutorRecipe(input: TutorRecipeInput): TutorRecipe {
  const findings = validateTutorSelection(input.selection, undefined, {
    allowNoPrimary: input.allowNoPrimary === true
  });
  const { exampleCount, sentenceLength } = input.output;
  if (!Number.isInteger(exampleCount) || exampleCount < 1 || exampleCount > 20) {
    findings.push(error(TUTOR_RECIPE_CODES.exampleCountOutOfRange, { actual: exampleCount }));
  }
  if (!Number.isInteger(sentenceLength.minimumWords) ||
      sentenceLength.minimumWords < 3 || sentenceLength.minimumWords > 40) {
    findings.push(error(TUTOR_RECIPE_CODES.minimumWordsOutOfRange, {
      actual: sentenceLength.minimumWords
    }));
  }
  if (!Number.isInteger(sentenceLength.maximumWords) ||
      sentenceLength.maximumWords < 3 || sentenceLength.maximumWords > 40) {
    findings.push(error(TUTOR_RECIPE_CODES.maximumWordsOutOfRange, {
      actual: sentenceLength.maximumWords
    }));
  }
  if (sentenceLength.minimumWords > sentenceLength.maximumWords) {
    findings.push(error(TUTOR_RECIPE_CODES.minimumAboveMaximum, {
      minimumWords: sentenceLength.minimumWords,
      maximumWords: sentenceLength.maximumWords
    }));
  }
  const tolerance = sentenceLength.tolerance ?? 0;
  if (!Number.isInteger(tolerance) || tolerance < 0) {
    findings.push(error(TUTOR_RECIPE_CODES.invalidTolerance, { actual: tolerance }));
  }
  if (input.scenario !== undefined && input.scenario.length > 500) {
    findings.push(error(TUTOR_RECIPE_CODES.scenarioTooLong, {
      actualCharacters: input.scenario.length,
      maximumCharacters: 500
    }));
  }
  // The same cap as a scenario, and for the same reason: this reaches an instruction, and a
  // field with no ceiling is a field a reader can paste a document into.
  if (input.question !== undefined && input.question.length > 500) {
    findings.push(error(TUTOR_RECIPE_CODES.questionTooLong, {
      actualCharacters: input.question.length,
      maximumCharacters: 500
    }));
  }
  if (findings.length > 0) throw new TutorRecipeError(findings);

  const primaries = input.selection
    .filter((target) => target.role === 'primary')
    .map((target) => target.nodeId);
  const supports = input.selection
    .filter((target) => target.role === 'support')
    .map((target) => target.nodeId);
  return {
    schemaVersion: 1,
    mapVersion: TUTOR_MAP_VERSION,
    ...(primaries.length === 0 ? {} : { primaryTargets: primaries }),
    supportingTargets: supports,
    output: {
      ...input.output,
      sentenceLength: { ...sentenceLength, tolerance }
    },
    axes: input.axes,
    ...(input.scenario === undefined ? {} : { scenario: input.scenario }),
    ...(input.question === undefined ? {} : { question: input.question })
  };
}

function error(code: string, detail: Record<string, number>): TutorFinding {
  return { code, severity: 'error', subjects: [], detail };
}
