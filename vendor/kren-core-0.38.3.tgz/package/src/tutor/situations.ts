/**
 * The situations a conversation can be set in.
 *
 * A conversation seeded only by the lesson recipe asks about grammar in the abstract, which
 * is the least like the thing the reader is practising for. A situation gives the exchange a
 * place, a relationship and a purpose, and those three are what decide which English is
 * right, so they are what a diagnosis needs in order to judge register at all.
 *
 * `register` is the load-bearing field and is not decoration. The diagnostic protocol's
 * fourth level, "below the purpose", requires a mismatch that is evident in the material
 * rather than assumed, and for a conversation the situation is where that evidence lives.
 * A model told the exchange is a job interview can say an answer is too casual for it; a
 * model told nothing can only guess, and guessing here produces exactly the stylistic
 * nagging that level is written to forbid.
 *
 * Situation identifiers are stable because stored choices reference them. Groups organize
 * distinct settings and registers; a counterpart's disposition or a complication can vary
 * in the conversation's opening scene without requiring a separate situation identifier.
 */

/** How formal the English of a situation is expected to be. */
export type TutorSituationRegister = 'casual' | 'neutral' | 'professional' | 'formal';

/** One of the situations offered for a conversation, or one the reader wrote. */
export interface TutorSituation {
  /** Stable identifier. Never shown, and never reused for a different situation. */
  id: string;
  /** What the reader picks from the list. */
  label: string;
  /** The group the list is ordered by. */
  group: TutorSituationGroup;
  /**
   * The setting, told to the model in the second person. It names where the reader is, who
   * they are speaking to and what they want, because a situation missing any of the three
   * leaves the model to invent it and the exchange drifts somewhere else by turn three.
   */
  setting: string;
  /** The register this situation calls for, against which a mismatch is judged. */
  register: TutorSituationRegister;
}

export type TutorSituationGroup =
  | 'Everyday errands'
  | 'Travel'
  | 'Eating out'
  | 'Health'
  | 'Social'
  | 'Work'
  | 'Academic teaching'
  | 'Research and conferences'
  | 'Executive and board';

const situation = (
  id: string,
  group: TutorSituationGroup,
  label: string,
  register: TutorSituationRegister,
  setting: string
): TutorSituation => ({ id, group, label, register, setting });

/**
 * The predefined situations, in the order they are offered.
 *
 * Ordered by group rather than alphabetically, because a reader browsing for something to
 * practise is looking for a part of their life, not for a word beginning with a letter.
 */
export const TUTOR_SITUATIONS: readonly TutorSituation[] = [
  situation('grocery-store', 'Everyday errands', 'At the grocery store', 'casual',
    'You are in a grocery store and cannot find an item. You ask a member of staff where it is, and whether there is an alternative.'),
  situation('pharmacy', 'Everyday errands', 'At the pharmacy', 'neutral',
    'You are at a pharmacy counter collecting a prescription and want to ask how and when to take it.'),
  situation('bank-account', 'Everyday errands', 'At the bank', 'professional',
    'You are at a bank asking about opening an account, and you need to understand the fees and what documents to bring.'),
  situation('post-office', 'Everyday errands', 'At the post office', 'neutral',
    'You are posting a parcel abroad and need to ask about cost, speed and insurance.'),
  situation('hairdresser', 'Everyday errands', 'At the hairdresser', 'casual',
    'You are in a hairdresser explaining what you want done, and answering questions about how you usually wear your hair.'),
  situation('repair-call', 'Everyday errands', 'Calling about a repair', 'neutral',
    'You are on the phone to a plumber describing a problem at home and arranging a time for them to come.'),
  situation('neighbour-noise', 'Everyday errands', 'Raising a problem with a neighbor', 'neutral',
    'You are speaking to a neighbor about noise late at night. You want it to stop and you want to stay on good terms.'),
  situation('faulty-return', 'Everyday errands', 'Returning a faulty purchase', 'neutral',
    'You are at a shop counter returning something that stopped working, explaining what it does and asking for a refund.'),
  situation('phone-contract', 'Everyday errands', 'Setting up a phone contract', 'professional',
    'You are in a phone shop comparing two contracts with an assistant, and you want to know what is not included before you sign.'),
  situation('lost-property', 'Everyday errands', 'At a lost property office', 'neutral',
    'You are at a lost property desk describing something you left behind precisely enough for the clerk to find it.'),

  situation('airport-checkin', 'Travel', 'Checking in at the airport', 'neutral',
    'You are at an airline check-in desk with a bag that may be over the limit, and a seat you would like to change.'),
  situation('immigration', 'Travel', 'Going through immigration', 'formal',
    'You are at a border control desk answering an officer’s questions about the purpose and length of your visit.'),
  situation('hotel-checkin', 'Travel', 'Checking into a hotel', 'professional',
    'You are checking into a hotel, confirming your booking, and asking about breakfast and a late checkout.'),
  situation('hotel-complaint', 'Travel', 'A problem with your hotel room', 'professional',
    'Your hotel room has a problem. You are at reception explaining it and asking for it to be put right.'),
  situation('directions', 'Travel', 'Asking for directions', 'casual',
    'You are lost in an unfamiliar city and stop someone in the street to ask the way.'),
  situation('train-ticket', 'Travel', 'Buying a train ticket', 'neutral',
    'You are at a ticket counter buying a train ticket, and you need to ask about times, changes and price.'),
  situation('car-rental', 'Travel', 'Renting a car', 'professional',
    'You are at a car rental desk arranging a car, and you need to understand the insurance and the fuel policy.'),
  situation('lost-luggage', 'Travel', 'Reporting lost luggage', 'professional',
    'Your suitcase did not arrive. You are at a baggage desk describing it and asking what happens next.'),
  situation('local-recommendation', 'Travel', 'Asking a local what is worth seeing', 'casual',
    'You are talking to someone who lives in the city you are visiting, and you want what they would actually recommend rather than the obvious sights.'),
  situation('long-journey', 'Travel', 'Sharing a long journey', 'casual',
    'You are seated beside a stranger on a long flight, and a conversation has started that you are willing to keep going.'),

  situation('restaurant-order', 'Eating out', 'Ordering in a restaurant', 'neutral',
    'You are ordering in a restaurant, asking what a dish contains and mentioning something you cannot eat.'),
  situation('restaurant-complaint', 'Eating out', 'Sending a dish back', 'neutral',
    'A dish has arrived wrong or cold. You are telling the waiter, politely, and asking for it to be fixed.'),
  situation('coffee-shop', 'Eating out', 'At a coffee shop', 'casual',
    'You are ordering at a busy coffee shop, changing your mind once, and asking whether you can sit and work there.'),
  situation('dinner-party', 'Eating out', 'Small talk at a dinner party', 'casual',
    'You are at a friend’s dinner party talking to someone you have just met, about where you are from and what you do.'),
  situation('dietary-restriction', 'Eating out', 'Explaining a dietary restriction', 'neutral',
    'You are ordering somewhere unfamiliar and need the waiter and the kitchen to understand what you cannot eat, and why it matters.'),
  situation('hosting-visitor', 'Eating out', 'Hosting a visitor over dinner', 'professional',
    'You have taken a visiting colleague to dinner. You are carrying the conversation and keeping it off work for most of the meal.'),
  situation('splitting-bill', 'Eating out', 'Splitting the bill', 'casual',
    'You are with friends working out who owes what now the bill has arrived, when one of you ordered a great deal more than the others.'),

  situation('doctor-symptoms', 'Health', 'Describing symptoms to a doctor', 'neutral',
    'You are with a doctor describing how you feel, when it started, and what makes it worse.'),
  situation('doctor-questions', 'Health', 'Asking a doctor about treatment', 'neutral',
    'A doctor has told you what is wrong. You are asking what the treatment involves, how long it takes, and what the alternatives are.'),
  situation('dentist', 'Health', 'At the dentist', 'neutral',
    'You are at a dentist explaining where the pain is and asking what needs doing and what it will cost.'),
  situation('gym-signup', 'Health', 'Joining a gym', 'casual',
    'You are asking at a gym about membership, opening hours and whether you can cancel.'),
  situation('urgent-appointment', 'Health', 'Making an urgent appointment', 'neutral',
    'You are on the phone to a receptionist who has offered you an appointment in three weeks, and you need to explain why that will not do.'),

  situation('friend-partner', 'Social', 'Meeting a friend’s partner', 'casual',
    'You are meeting a close friend’s partner for the first time and looking for things you have in common.'),
  situation('old-colleague', 'Social', 'Running into an old colleague', 'casual',
    'You have unexpectedly run into someone you used to work with, and you are catching up on the last few years.'),
  situation('apologise-late', 'Social', 'Apologizing for being late', 'casual',
    'You have kept someone waiting. You are apologizing, explaining briefly, and moving on.'),
  situation('decline-invitation', 'Social', 'Declining an invitation', 'casual',
    'You have been invited to something you do not want to go to. You are saying no without giving offense.'),
  situation('making-plans', 'Social', 'Making plans with a friend', 'casual',
    'You are arranging to meet a friend, working around what neither of you can do, and settling on a time and place.'),
  situation('what-you-do', 'Social', 'Being asked what you do', 'casual',
    'You are at a party and someone from outside your field has asked what you do. You want to be understood rather than impressive.'),
  situation('wedding-strangers', 'Social', 'At a wedding table of strangers', 'neutral',
    'You are seated at a wedding with people you have never met, finding something to talk about that lasts the meal.'),
  situation('friend-advice', 'Social', 'Giving a friend advice', 'casual',
    'You are with a friend who is describing a decision they are weighing. They want your view, not to be told what to do.'),
  situation('friend-disagreement', 'Social', 'Disagreeing with a friend', 'casual',
    'A friend has said something you think is wrong. You want to say so without turning it into a quarrel.'),

  situation('job-interview', 'Work', 'A job interview', 'professional',
    'You are being interviewed for a job. You are asked about your experience, why you want the role, and how you handle difficulty.'),
  situation('performance-review', 'Work', 'A performance review', 'professional',
    'You are in a review with your manager discussing what went well this year, what did not, and what you want next.'),
  situation('standup', 'Work', 'A team stand-up', 'neutral',
    'You are giving a short update to your team on what you did yesterday, what you are doing today, and what is blocking you.'),
  situation('meeting-disagree', 'Work', 'Disagreeing in a meeting', 'professional',
    'You disagree with a decision being made in a meeting. You want to say so without damaging the relationship.'),
  situation('client-presentation', 'Work', 'Presenting to a client', 'professional',
    'You are presenting your work to a client, who interrupts with questions about cost and timing.'),
  situation('deadline-negotiation', 'Work', 'Negotiating a deadline', 'professional',
    'A deadline you were given is not realistic. You are explaining why and proposing another.'),
  situation('time-off', 'Work', 'Asking for time off', 'professional',
    'You are asking your manager for time off at a busy period, and explaining how the work will be covered.'),
  situation('new-colleague', 'Work', 'Meeting a new colleague', 'neutral',
    'A new colleague has joined. You are introducing yourself, explaining what you work on, and offering help.'),
  situation('explaining-failure', 'Work', 'Explaining a failure', 'professional',
    'Something you were responsible for has gone wrong. You are telling your manager yourself, before they hear it from anyone else.'),
  situation('work-handover', 'Work', 'Handing work over', 'neutral',
    'You are briefing a colleague who is taking something over from you, and they will have to run it without you.'),

  situation('office-hours', 'Academic teaching', 'Office hours with a professor', 'professional',
    'You are asking a professor about something in their course you did not follow, and about what to read next.'),
  situation('office-hours-teaching', 'Academic teaching', 'Office hours with a confused student', 'professional',
    'A student has come to your office confused about material you taught. You need to find where they actually lost it rather than repeat the lecture.'),
  situation('grade-dispute', 'Academic teaching', 'A student disputing a grade', 'professional',
    'A student is in your office arguing that their mark is unfair. You have to hold the mark or change it on reasons you can state.'),
  situation('stalled-project', 'Academic teaching', 'Supervising a stalled project', 'professional',
    'You are meeting a graduate student whose project has not moved for months. The conversation has to be honest without ending them.'),
  situation('thesis-defence', 'Academic teaching', 'A thesis defense as examiner', 'formal',
    'You are examining a candidate in front of colleagues, pressing on the weakest claim in their thesis.'),
  situation('lecture-questions', 'Academic teaching', 'Lecturing and taking questions', 'professional',
    'You have finished a lecture and are taking questions from a room of students, including one you cannot answer.'),
  situation('faculty-disagreement', 'Academic teaching', 'A faculty meeting disagreement', 'formal',
    'You are in a departmental meeting opposing a proposal your colleagues are inclined to accept.'),
  situation('recruiting-student', 'Academic teaching', 'Recruiting a graduate student', 'professional',
    'You are talking to a prospective student about joining your group, describing the work and its difficulties honestly.'),
  situation('reference-reservations', 'Academic teaching', 'Raising reservations about a reference', 'professional',
    'Someone has asked you to recommend them and you have reservations. You are raising them with the person rather than writing them down.'),
  situation('teaching-language-gap', 'Academic teaching', 'Teaching across a language gap', 'neutral',
    'You are explaining a technical idea to students who do not share your first language, simplifying without patronising them.'),

  situation('conference-smalltalk', 'Research and conferences', 'Small talk at a conference', 'neutral',
    'You are at a conference coffee break talking to someone whose work you have read but have never met.'),
  situation('conference-question', 'Research and conferences', 'Asking a question after a talk', 'formal',
    'A talk has just finished. You are asking the speaker a question about their method, in front of the room.'),
  situation('poster-session', 'Research and conferences', 'Explaining your poster', 'professional',
    'You are standing by your poster explaining your work to someone who has stopped to look, and answering their questions.'),
  situation('supervisor-catchup', 'Research and conferences', 'Catching up with a former supervisor', 'professional',
    'You have run into a former supervisor at a conference. You are catching up on what you have both been doing since.'),
  situation('result-challenged', 'Research and conferences', 'Defending a result under challenge', 'formal',
    'A senior researcher is publicly questioning your method. You have to answer the substance rather than the tone.'),
  situation('journal-editor', 'Research and conferences', 'A call with a journal editor', 'formal',
    'You are on a call with a journal editor about review comments you believe are mistaken, and you need to say so without antagonising them.'),
  situation('grant-panel', 'Research and conferences', 'A grant panel interview', 'formal',
    'You are before a funding panel explaining why your proposal is worth the money and what happens if it does not work.'),
  situation('collaboration-proposal', 'Research and conferences', 'Proposing a collaboration', 'professional',
    'You are asking a researcher you respect to work with you, and you need to say what each side brings to it.'),
  situation('authorship', 'Research and conferences', 'Negotiating authorship', 'professional',
    'You are agreeing with collaborators who goes where on a paper, and you do not agree.'),
  situation('lab-safety', 'Research and conferences', 'A lab safety briefing', 'neutral',
    'You are taking a new member through what is dangerous in your lab and what they must never do, making sure they have understood.'),
  situation('bad-data', 'Research and conferences', 'Bad data in a group meeting', 'professional',
    'You are telling your group that a result they have built on does not hold, and what you propose to do about it.'),

  situation('board-report', 'Executive and board', 'Reporting to the board', 'formal',
    'You are presenting results to a board that is not satisfied with them, and you must not lose the room.'),
  situation('unpopular-decision', 'Executive and board', 'Announcing an unpopular decision', 'professional',
    'You are telling your organization about a decision that will cost some of them something.'),
  situation('contract-negotiation', 'Executive and board', 'Negotiating a contract', 'professional',
    'You are across a table on terms, conceding what you can afford to and holding what you cannot.'),
  situation('press-question', 'Executive and board', 'A press question you cannot answer', 'formal',
    'You are being asked by a journalist about something you are not able to discuss, and refusing has to not sound like hiding.'),
  situation('senior-hire', 'Executive and board', 'Interviewing a senior hire', 'professional',
    'You are assessing a candidate more experienced than you in their own field, and you have to probe rather than defer.'),
  situation('peer-conflict', 'Executive and board', 'A difficult conversation with a peer', 'professional',
    'Another executive is undermining something you are responsible for. You are raising it with them directly.'),
  situation('chairing-drift', 'Executive and board', 'Chairing a meeting that has drifted', 'professional',
    'You are chairing, the discussion has gone somewhere unproductive, and you have to bring it back without slighting anyone.'),
  situation('technical-risk', 'Executive and board', 'Explaining technical risk to non-specialists', 'professional',
    'You are telling a board what could go wrong technically, in terms that let them decide rather than defer to you.'),
  situation('mentoring-manager', 'Executive and board', 'Mentoring a new manager', 'neutral',
    'You are with someone you promoted who is finding management harder than they expected, and who is asking how you do it.')
] as const;

/** A situation the reader described in their own words. */
export const TUTOR_CUSTOM_SITUATION_ID = 'custom';

/**
 * The situation groups, in list order, with no group appearing twice.
 *
 * Derived from the catalogue rather than written out beside it, because two lists that must
 * agree are two lists that will not.
 */
export function tutorSituationGroups(): TutorSituationGroup[] {
  const seen: TutorSituationGroup[] = [];
  for (const entry of TUTOR_SITUATIONS) {
    if (!seen.includes(entry.group)) seen.push(entry.group);
  }
  return seen;
}

export function findTutorSituation(id: string): TutorSituation | undefined {
  return TUTOR_SITUATIONS.find((entry) => entry.id === id);
}

/**
 * A situation the reader wrote, as a `TutorSituation` the rest of the code cannot tell apart.
 *
 * Its register is `neutral` and is not inferred from the text. Guessing a register from a
 * free-text description and then judging the reader against that guess would let a level-4
 * finding rest on KREN's own invention, which is the one thing the fourth level forbids.
 */
export function tutorCustomSituation(description: string): TutorSituation | undefined {
  const setting = description.trim();
  if (!setting) return undefined;
  return {
    id: TUTOR_CUSTOM_SITUATION_ID,
    label: 'My own situation',
    group: 'Social',
    setting,
    register: 'neutral'
  };
}
