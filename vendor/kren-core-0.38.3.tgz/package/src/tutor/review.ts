import {
  isTrainingReviewCorrectionCategory,
  type TrainingReview,
  type TutorFinding
} from './contract.js';

export const TRAINING_REVIEW_CODES = {
  noSpans: 'review.noSpans',
  excerptMissing: 'review.excerptMissing',
  invalidCorrectedText: 'review.invalidCorrectedText',
  invalidCategory: 'review.invalidCategory'
} as const;

export function validateTrainingReview(review: TrainingReview): TutorFinding[] {
  const findings: TutorFinding[] = [];
  if ('correctedText' in review &&
      (typeof review.correctedText !== 'string' || !review.correctedText.trim())) {
    findings.push(error(TRAINING_REVIEW_CODES.invalidCorrectedText, [review.exerciseId]));
  }
  const spans = [...review.correct, ...review.incorrect];
  if (spans.length === 0) {
    findings.push(error(TRAINING_REVIEW_CODES.noSpans, [review.exerciseId]));
  }
  for (const [index, span] of spans.entries()) {
    if (span.excerpt.length === 0 || !review.learnerText.includes(span.excerpt)) {
      findings.push({
        ...error(TRAINING_REVIEW_CODES.excerptMissing, [review.exerciseId]),
        detail: { spanIndex: index }
      });
    }
  }
  for (const [index, correction] of review.incorrect.entries()) {
    if ('category' in correction &&
        !isTrainingReviewCorrectionCategory(correction.category)) {
      findings.push({
        ...error(TRAINING_REVIEW_CODES.invalidCategory, [review.exerciseId]),
        detail: { correctionIndex: index }
      });
    }
  }
  return findings;
}

function error(code: string, subjects: string[]): TutorFinding {
  return { code, severity: 'error', subjects };
}
