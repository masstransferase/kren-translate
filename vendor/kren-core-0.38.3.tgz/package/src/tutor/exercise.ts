import type { TutorExerciseRequest, TutorExerciseSet, TutorFinding } from './contract.js';

export const TUTOR_EXERCISE_CODES = {
  schemaVersionMismatch: 'exercise.schemaVersionMismatch',
  mapVersionMismatch: 'exercise.mapVersionMismatch',
  countMismatch: 'exercise.countMismatch',
  setChannelMismatch: 'exercise.setChannelMismatch',
  exerciseChannelMismatch: 'exercise.exerciseChannelMismatch',
  duplicateIdentifier: 'exercise.duplicateIdentifier',
  unknownAnswerExercise: 'exercise.unknownAnswerExercise',
  spokenTurnsMissing: 'exercise.spokenTurnsMissing',
  writtenTurnsPresent: 'exercise.writtenTurnsPresent',
  answerKeyMissing: 'exercise.answerKeyMissing'
} as const;

export function validateTutorExerciseSet(
  exerciseSet: TutorExerciseSet,
  request: TutorExerciseRequest
): TutorFinding[] {
  const findings: TutorFinding[] = [];
  if (exerciseSet.schemaVersion !== 1) {
    findings.push(error(TUTOR_EXERCISE_CODES.schemaVersionMismatch, []));
  }
  if (exerciseSet.mapVersion !== request.recipe.mapVersion) {
    findings.push(error(TUTOR_EXERCISE_CODES.mapVersionMismatch, []));
  }
  if (exerciseSet.exercises.length !== request.count) {
    findings.push({
      ...error(TUTOR_EXERCISE_CODES.countMismatch, exerciseSet.exercises.map((item) => item.id)),
      detail: { actual: exerciseSet.exercises.length, requested: request.count }
    });
  }
  if (exerciseSet.channel !== request.channel) {
    findings.push(error(TUTOR_EXERCISE_CODES.setChannelMismatch, []));
  }

  const identifiers = new Set<string>();
  for (const exercise of exerciseSet.exercises) {
    if (identifiers.has(exercise.id)) {
      findings.push(error(TUTOR_EXERCISE_CODES.duplicateIdentifier, [exercise.id]));
    }
    identifiers.add(exercise.id);
    if (exercise.channel !== request.channel) {
      findings.push(error(TUTOR_EXERCISE_CODES.exerciseChannelMismatch, [exercise.id]));
    }
    if (request.channel === 'written') {
      if (exercise.turns !== undefined) {
        findings.push(error(TUTOR_EXERCISE_CODES.writtenTurnsPresent, [exercise.id]));
      }
    } else if (exercise.turns === undefined) {
      findings.push(error(TUTOR_EXERCISE_CODES.spokenTurnsMissing, [exercise.id]));
    }
  }

  for (const answer of exerciseSet.answerKey ?? []) {
    if (!identifiers.has(answer.exerciseId)) {
      findings.push(error(
        TUTOR_EXERCISE_CODES.unknownAnswerExercise,
        [answer.id, answer.exerciseId]
      ));
    }
  }
  /*
   * No answer-key rule here, deliberately.
   *
   * A practice set has no answer key in its contract and the request's schema has no field
   * for one, so this rejected every set the reader generated while "Include answer key" was
   * on, for a field the model was never offered. Practice marks each answer with its own
   * review, which is where a reader learns what was right, so an answer key would duplicate
   * the review rather than add anything.
   *
   * `includeAnswerKey` governs the lesson, which does carry one. See validation.ts.
   */
  return findings;
}

function error(code: string, subjects: string[]): TutorFinding {
  return { code, severity: 'error', subjects };
}
