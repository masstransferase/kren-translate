import type { RewriteAxes } from '../rewriteAxes.js';

function isClosedUnion<T extends readonly unknown[]>(
  values: T,
  value: unknown
): value is T[number] {
  return values.some((candidate) => candidate === value);
}

export const CEFR_LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'] as const;
export type CefrLevel = typeof CEFR_LEVELS[number];
export const isCefrLevel = (value: unknown): value is CefrLevel =>
  isClosedUnion(CEFR_LEVELS, value);

/** The tutor has no source text, so Rewrite Text's transformation length has no meaning. */
export type TutorAxes = Omit<RewriteAxes, 'length'>;

export const TRAINING_NODE_KINDS = ['hub', 'cluster', 'skill', 'microTarget'] as const;
export type TrainingNodeKind = typeof TRAINING_NODE_KINDS[number];
export const isTrainingNodeKind = (value: unknown): value is TrainingNodeKind =>
  isClosedUnion(TRAINING_NODE_KINDS, value);

export const TRAINING_TARGET_ROLES = ['primary', 'support'] as const;
export type TrainingTargetRole = typeof TRAINING_TARGET_ROLES[number];
export const isTrainingTargetRole = (value: unknown): value is TrainingTargetRole =>
  isClosedUnion(TRAINING_TARGET_ROLES, value);

export interface TrainingTargetSelection {
  nodeId: string;
  role: TrainingTargetRole;
}

/**
 * A target after the map has been consulted: what was selected, plus enough about it to
 * render and to validate against, so a consumer never has to hold the map to show a lesson.
 */
export interface ResolvedTrainingTarget {
  nodeId: string;
  label: string;
  kind: TrainingNodeKind;
  role: TrainingTargetRole;
  description: string;
  /**
   * Set when the reader selected a parent in Explore mode and KREN chose this leaf beneath
   * it. It names the parent that was selected. Absent for an exact leaf selection, which is
   * how a consumer knows whether to offer the reader a chance to change the choice.
   */
  chosenUnder?: string;
}

export interface TutorSentenceLength {
  minimumWords: number;
  maximumWords: number;
  /** Grammar sometimes will not fit the band. Default 0. See section 5.1 point 2. */
  tolerance: number;
}

export const TUTOR_LEARNER_LEVELS = [...CEFR_LEVELS, 'auto'] as const;
export const isTutorLearnerLevel = (
  value: unknown
): value is TutorOutputSettings['learnerLevel'] =>
  isClosedUnion(TUTOR_LEARNER_LEVELS, value);

export const TUTOR_LESSON_MODES = [
  'explain', 'examples', 'explainAndExamples', 'contrast', 'transform', 'errorClinic',
  'miniPractice'
] as const;
export const isTutorLessonMode = (
  value: unknown
): value is TutorOutputSettings['lessonMode'] =>
  isClosedUnion(TUTOR_LESSON_MODES, value);

export const TUTOR_EXPLANATION_DEPTHS = ['brief', 'standard', 'detailed'] as const;
export const isTutorExplanationDepth = (
  value: unknown
): value is TutorOutputSettings['explanationDepth'] =>
  isClosedUnion(TUTOR_EXPLANATION_DEPTHS, value);

export const TUTOR_ANNOTATION_LEVELS = [
  'none', 'highlight', 'explainEach', 'fullAnalysis'
] as const;
export const isTutorAnnotationLevel = (
  value: unknown
): value is TutorOutputSettings['annotationLevel'] =>
  isClosedUnion(TUTOR_ANNOTATION_LEVELS, value);

export interface TutorOutputSettings {
  exampleCount: number;
  sentenceLength: TutorSentenceLength;
  learnerLevel: typeof TUTOR_LEARNER_LEVELS[number];
  lessonMode: typeof TUTOR_LESSON_MODES[number];
  explanationDepth: typeof TUTOR_EXPLANATION_DEPTHS[number];
  annotationLevel: typeof TUTOR_ANNOTATION_LEVELS[number];
  includeCommonErrors: boolean;
  includePractice: boolean;
  includeAnswerKey: boolean;
}

export interface TutorRecipe {
  schemaVersion: 1;
  mapVersion: string;
  /**
   * The map nodes the lesson teaches, when the reader chose any.
   *
   * Absent for a question-only lesson, where the reader turned target selection off and the
   * subject comes from their own question instead. The lesson still returns a primaryTarget
   * of its own naming the subject it taught, so the lesson contract is unchanged; what is
   * absent here is the identifier KREN would otherwise check that answer against.
   *
   * Plural since 0.18.0. A reader may teach several targets at once as long as they can sit
   * together, which `assessTutorCompatibility` decides pairwise and this array does not
   * second-guess. Every one of them obliges every example, so the ceiling is three.
   *
   * The lesson's own `primaryTarget` stays singular deliberately. It is the subject the
   * model names, which is a label, whereas these are the constraint each example is checked
   * against. Making the model return an array as well would change an output shape that two
   * live provider failures were paid for settling, for a label.
   */
  primaryTargets?: string[];
  supportingTargets: string[];
  output: TutorOutputSettings;
  axes: TutorAxes;
  scenario?: string;
  /**
   * The reader's own question, when they typed one instead of only picking targets.
   *
   * It steers a lesson that still has a primary target: the question says what the
   * reader wants explained, and the target says which part of the map explains it. A
   * lesson with no target at all is a different shape and is deliberately not this
   * field, because `selection.missingPrimary` still refuses one.
   */
  question?: string;
}

export const TRAINING_CLAIM_STATUSES = [
  'rule', 'strongTendency', 'stylePreference'
] as const;
/**
 * A claim's force. A learner who cannot tell a rule from a preference over-applies the
 * preference, which is the most common way explicit instruction makes someone sound worse.
 */
export type TrainingClaimStatus = typeof TRAINING_CLAIM_STATUSES[number];
export const isTrainingClaimStatus = (value: unknown): value is TrainingClaimStatus =>
  isClosedUnion(TRAINING_CLAIM_STATUSES, value);

export interface TrainingRule {
  statement: string;
  status: TrainingClaimStatus;
}

export interface TrainingAnnotation {
  targetId: string;
  /** Occurs verbatim in the sentence it annotates. Validated, not trusted. */
  excerpt: string;
  explanation: string;
}

export interface TrainingExample {
  id: string;
  sentence: string;
  targetIds: string[];
  annotations: TrainingAnnotation[];
  usageNote?: string;
  /** True only for a deliberately wrong example. See section 5.1 point 4. */
  intentionalError?: boolean;
}

export interface TrainingErrorContrast {
  id: string;
  incorrect: string;
  corrected: string;
  explanation: string;
  status: TrainingClaimStatus;
}

export interface TutorLesson {
  schemaVersion: 1;
  mapVersion: string;
  lessonTitle: string;
  level: CefrLevel;
  primaryTarget: ResolvedTrainingTarget;
  supportingTargets: ResolvedTrainingTarget[];
  conceptExplanation: string;
  interactionExplanation: string;
  /**
   * One sentence naming the pattern every example demonstrates, shown above whichever example
   * the reader is on. The lesson reader shows one example at a time, so the pattern can no
   * longer be induced from seeing six sentences together and is stated instead.
   *
   * Optional here and required in the request schema, deliberately. A model that omits it
   * should cost the reader one line, not the whole lesson.
   */
  patternStatement?: string;
  rules: TrainingRule[];
  examples: TrainingExample[];
  commonErrors: TrainingErrorContrast[];
  practice?: TrainingExercise[];
  answerKey?: TrainingAnswer[];
  generationNotes: string[];
}

export const TUTOR_EXERCISE_CHANNELS = [
  'written', 'spokenScripted', 'spokenTyped', 'spokenVoice'
] as const;
export type TutorExerciseChannel = typeof TUTOR_EXERCISE_CHANNELS[number];
export const isTutorExerciseChannel = (value: unknown): value is TutorExerciseChannel =>
  isClosedUnion(TUTOR_EXERCISE_CHANNELS, value);

export const TRAINING_DIALOGUE_SPEAKERS = ['tutor', 'learner'] as const;
export const isTrainingDialogueSpeaker = (
  value: unknown
): value is TrainingDialogueTurn['speaker'] =>
  isClosedUnion(TRAINING_DIALOGUE_SPEAKERS, value);

export interface TrainingDialogueTurn {
  speaker: typeof TRAINING_DIALOGUE_SPEAKERS[number];
  /** The tutor's line. Absent on a learner turn, which is a gap for the learner to fill. */
  text?: string;
  pauseAfterMilliseconds?: number;
  /** Offered only when the learner asks. Never rendered with the prompt. */
  suggested?: string;
}

export interface TrainingExercise {
  id: string;
  channel: TutorExerciseChannel;
  prompt: string;
  targetIds: string[];
  /** Present only for a spoken channel. Empty or absent for `written`. */
  turns?: TrainingDialogueTurn[];
}

export interface TrainingAnswer {
  id: string;
  /** Names a TrainingExercise.id in the same set. Validated. */
  exerciseId: string;
  answer: string;
  explanation: string;
}

export interface TutorExerciseRequest {
  schemaVersion: 1;
  recipe: TutorRecipe;
  count: number;
  channel: TutorExerciseChannel;
}

export interface TutorExerciseSet {
  schemaVersion: 1;
  mapVersion: string;
  channel: TutorExerciseChannel;
  exercises: TrainingExercise[];
  answerKey?: TrainingAnswer[];
}

export interface TrainingReviewSpan {
  /** Occurs verbatim in the learner's own text. Validated, which is the point. */
  excerpt: string;
  reason: string;
}

export const TRAINING_REVIEW_CORRECTION_CATEGORIES = [
  'grammar', 'spelling', 'punctuation', 'wording'
] as const;
export type TrainingReviewCorrectionCategory =
  typeof TRAINING_REVIEW_CORRECTION_CATEGORIES[number];
export const isTrainingReviewCorrectionCategory = (
  value: unknown
): value is TrainingReviewCorrectionCategory =>
  isClosedUnion(TRAINING_REVIEW_CORRECTION_CATEGORIES, value);

export interface TrainingReviewCorrection extends TrainingReviewSpan {
  corrected: string;
  status: TrainingClaimStatus;
  /** The kind of mistake. This is separate from status, which says how strong the norm is. */
  category?: TrainingReviewCorrectionCategory;
}

export interface TrainingReview {
  schemaVersion: 1;
  exerciseId: string;
  learnerText: string;
  /** The sentence shown to the reader and the model answer for a composition exercise. */
  correctedText?: string;
  correct: TrainingReviewSpan[];
  incorrect: TrainingReviewCorrection[];
}

export const TUTOR_FINDING_SEVERITIES = ['warning', 'error'] as const;
export type TutorFindingSeverity = typeof TUTOR_FINDING_SEVERITIES[number];
export const isTutorFindingSeverity = (value: unknown): value is TutorFindingSeverity =>
  isClosedUnion(TUTOR_FINDING_SEVERITIES, value);

export interface TutorFinding {
  code: string;
  severity: TutorFindingSeverity;
  /** Example, exercise, answer, or map node identifiers this finding is about. */
  subjects: string[];
  /** Numbers a consumer needs to phrase the message, such as an actual word count. */
  detail?: Record<string, string | number>;
}
