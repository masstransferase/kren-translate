import type { TrainingTargetSelection, TutorFinding } from './contract.js';
import { TUTOR_MAP, type TrainingMapNode } from './map.js';

export const TUTOR_SELECTION_CODES = {
  missingPrimary: 'selection.missingPrimary',
  tooManyPrimaries: 'selection.tooManyPrimaries',
  tooManySupports: 'selection.tooManySupports',
  duplicateTarget: 'selection.duplicateTarget',
  ancestorDescendant: 'selection.ancestorDescendant',
  unknownTarget: 'selection.unknownTarget'
} as const;

export function validateTutorSelection(
  selection: readonly TrainingTargetSelection[],
  map: readonly TrainingMapNode[] = TUTOR_MAP,
  options: { allowNoPrimary?: boolean } = {}
): TutorFinding[] {
  const findings: TutorFinding[] = [];
  const primaries = selection.filter((target) => target.role === 'primary');
  const supports = selection.filter((target) => target.role === 'support');

  /*
   * A missing primary is a defect in every ordinary lesson and is the whole point of a
   * question-only one, so the caller says which it is asking about. It stays an error by
   * default, because the reader who has not turned the switch on must still be told.
   */
  if (primaries.length === 0) {
    if (!options.allowNoPrimary) {
      findings.push(error(TUTOR_SELECTION_CODES.missingPrimary, []));
    }
  } else if (primaries.length > 3) {
    /*
     * More than one primary is allowed, and whether a particular pair may sit together is
     * not decided here.
     *
     * `assessTutorCompatibility` already compares every pair in the selection regardless of
     * role: a recorded conflict is an error, and a level-range or modality mismatch is a
     * warning. Repeating any of that here would give two places an opinion about the same
     * question, and the two would eventually disagree.
     *
     * What is decided here is the count, and the ceiling is three for the same reason the
     * support ceiling is three: `primary` obliges every example to exercise the target, so a
     * fourth turns six examples into a puzzle no model reliably solves, and the failure
     * arrives as six `primaryTargetMissing` findings rather than as anything a reader can
     * act on.
     */
    findings.push(error(
      TUTOR_SELECTION_CODES.tooManyPrimaries,
      primaries.map((target) => target.nodeId)
    ));
  }
  if (supports.length > 3) {
    findings.push(error(
      TUTOR_SELECTION_CODES.tooManySupports,
      supports.map((target) => target.nodeId)
    ));
  }

  const counts = new Map<string, number>();
  for (const target of selection) {
    counts.set(target.nodeId, (counts.get(target.nodeId) ?? 0) + 1);
  }
  for (const [nodeId, count] of counts) {
    if (count > 1) findings.push(error(TUTOR_SELECTION_CODES.duplicateTarget, [nodeId]));
  }

  const nodesById = new Map(map.map((candidate) => [candidate.id, candidate]));
  for (const target of selection) {
    if (!nodesById.has(target.nodeId)) {
      findings.push(error(TUTOR_SELECTION_CODES.unknownTarget, [target.nodeId]));
    }
  }

  const distinctIds = [...counts.keys()].filter((nodeId) => nodesById.has(nodeId));
  for (let firstIndex = 0; firstIndex < distinctIds.length; firstIndex += 1) {
    const first = distinctIds[firstIndex]!;
    for (let secondIndex = firstIndex + 1; secondIndex < distinctIds.length; secondIndex += 1) {
      const second = distinctIds[secondIndex]!;
      if (isAncestor(first, second, nodesById)) {
        findings.push(error(TUTOR_SELECTION_CODES.ancestorDescendant, [first, second]));
      } else if (isAncestor(second, first, nodesById)) {
        findings.push(error(TUTOR_SELECTION_CODES.ancestorDescendant, [second, first]));
      }
    }
  }

  return findings;
}

export function isTutorSelectionValid(
  selection: readonly TrainingTargetSelection[],
  map: readonly TrainingMapNode[] = TUTOR_MAP
): boolean {
  return validateTutorSelection(selection, map).length === 0;
}

function isAncestor(
  possibleAncestor: string,
  possibleDescendant: string,
  nodesById: ReadonlyMap<string, TrainingMapNode>
): boolean {
  const visited = new Set<string>();
  let current = nodesById.get(possibleDescendant);
  while (current?.parentId !== undefined && !visited.has(current.id)) {
    if (current.parentId === possibleAncestor) return true;
    visited.add(current.id);
    current = nodesById.get(current.parentId);
  }
  return false;
}

function error(code: string, subjects: string[]): TutorFinding {
  return { code, severity: 'error', subjects };
}
