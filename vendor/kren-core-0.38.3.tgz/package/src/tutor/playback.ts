import type { TutorLesson } from './contract.js';

export const TRAINING_PLAYBACK_SCOPES = [
  'currentExample', 'allExamples', 'explanation', 'contrastPair', 'practicePrompt'
] as const;
export const isTrainingPlaybackScope = (
  value: unknown
): value is TrainingPlaybackPlan['scope'] =>
  typeof value === 'string' && TRAINING_PLAYBACK_SCOPES.some((candidate) => candidate === value);

export const TRAINING_PLAYBACK_REPEAT_COUNTS = [1, 2, 3] as const;
export const isTrainingPlaybackRepeatCount = (
  value: unknown
): value is TrainingPlaybackPlan['repeatCount'] =>
  typeof value === 'number' &&
  TRAINING_PLAYBACK_REPEAT_COUNTS.some((candidate) => candidate === value);

export const TRAINING_PLAYBACK_PAUSES = [1000, 2000, 3000, 5000] as const;
export const isTrainingPlaybackPause = (value: unknown): value is number =>
  typeof value === 'number' && TRAINING_PLAYBACK_PAUSES.some((candidate) => candidate === value);

export interface TrainingPlaybackPlan {
  scope: typeof TRAINING_PLAYBACK_SCOPES[number];
  segments: Array<{
    id: string;
    text: string;
    pauseAfterMilliseconds: number;
    label?: string;
  }>;
  repeatCount: typeof TRAINING_PLAYBACK_REPEAT_COUNTS[number];
}

export interface TrainingPlaybackRequest {
  scope: TrainingPlaybackPlan['scope'];
  subjectId?: string;
  pauseAfterMilliseconds?: number;
  repeatCount?: TrainingPlaybackPlan['repeatCount'];
}

export class TrainingPlaybackPlanError extends Error {
  public constructor(public readonly code: string) {
    super(code);
    this.name = 'TrainingPlaybackPlanError';
  }
}

export function buildTrainingPlaybackPlan(
  lesson: TutorLesson,
  request: TrainingPlaybackRequest
): TrainingPlaybackPlan {
  const pause = request.pauseAfterMilliseconds ?? TRAINING_PLAYBACK_PAUSES[1];
  const repeatCount = request.repeatCount ?? TRAINING_PLAYBACK_REPEAT_COUNTS[0];
  if (!isTrainingPlaybackPause(pause)) {
    throw new TrainingPlaybackPlanError('playback.invalidPause');
  }
  if (!isTrainingPlaybackRepeatCount(repeatCount)) {
    throw new TrainingPlaybackPlanError('playback.invalidRepeatCount');
  }

  let segments: TrainingPlaybackPlan['segments'];
  switch (request.scope) {
    case 'allExamples':
      segments = lesson.examples
        .filter((example) => example.intentionalError !== true)
        .map((example) => segment(example.id, example.sentence, pause));
      break;
    case 'currentExample': {
      const example = lesson.examples.find((candidate) => candidate.id === request.subjectId);
      if (!example) throw new TrainingPlaybackPlanError('playback.subjectNotFound');
      segments = [segment(example.id, example.sentence, pause)];
      break;
    }
    case 'explanation':
      segments = [
        segment('concept-explanation', lesson.conceptExplanation, pause),
        segment('interaction-explanation', lesson.interactionExplanation, pause)
      ];
      break;
    case 'contrastPair': {
      const contrast = lesson.commonErrors.find((candidate) => candidate.id === request.subjectId);
      if (!contrast) throw new TrainingPlaybackPlanError('playback.subjectNotFound');
      segments = [
        segment(`${contrast.id}-incorrect`, contrast.incorrect, pause, 'incorrect'),
        segment(`${contrast.id}-corrected`, contrast.corrected, pause, 'corrected')
      ];
      break;
    }
    case 'practicePrompt': {
      const exercise = lesson.practice?.find((candidate) => candidate.id === request.subjectId);
      if (!exercise) throw new TrainingPlaybackPlanError('playback.subjectNotFound');
      segments = [segment(exercise.id, exercise.prompt, pause)];
      break;
    }
  }
  return { scope: request.scope, segments, repeatCount };
}

function segment(
  id: string,
  text: string,
  pauseAfterMilliseconds: number,
  label?: string
): TrainingPlaybackPlan['segments'][number] {
  return { id, text, pauseAfterMilliseconds, ...(label === undefined ? {} : { label }) };
}
