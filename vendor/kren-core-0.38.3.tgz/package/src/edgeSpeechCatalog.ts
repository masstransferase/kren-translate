import type { EdgeSpeechLocale } from './edgeSpeech.js';

/**
 * The Microsoft Edge Online voices KREN offers, one entry per Rewrite Text output language.
 *
 * Generated from `edge_tts.list_voices()` against edge-tts 7.2.8 on 2026-08-24 and checked
 * in rather than queried at runtime. Querying means spawning the configured Python
 * executable whenever the settings page opens, and Edge speech is already disabled in
 * Restricted Mode for exactly that reason, so the settings page would inherit the
 * restriction. The reader keeps an escape hatch: the Voice ID field accepts any identifier
 * the runtime knows, so a voice absent from this list, or added by Microsoft after it was
 * generated, is still reachable by typing it.
 *
 * Twenty-one locales. The two Persian voices were verified against `edge_tts.list_voices()`.
 * The label "Persian (Farsi)" lets a reader looking for either name find the same entry.
 *
 * The other twenty match the Rewrite Text output language list, so the two
 * features name the same languages. The four languages that list leaves regionally open
 * take their majority region here.
 *
 * No `Multilingual` voice is a default. Microsoft publishes no machine-readable statement of
 * which languages those voices cover, and a catalog entry carries only a home locale, so
 * defaulting to one would promise coverage that cannot be checked from the runtime. They
 * remain selectable.
 */
export const EDGE_SPEECH_LOCALES: readonly EdgeSpeechLocale[] = [
  { id: 'en-US', label: 'English (United States)', defaultVoice: 'en-US-AvaNeural', voices: [{ id: 'en-US-AnaNeural', label: 'Ana (Female)' }, { id: 'en-US-AndrewMultilingualNeural', label: 'AndrewMultilingual (Male)' }, { id: 'en-US-AndrewNeural', label: 'Andrew (Male)' }, { id: 'en-US-AriaNeural', label: 'Aria (Female)' }, { id: 'en-US-AvaMultilingualNeural', label: 'AvaMultilingual (Female)' }, { id: 'en-US-AvaNeural', label: 'Ava (Female)' }, { id: 'en-US-BrianMultilingualNeural', label: 'BrianMultilingual (Male)' }, { id: 'en-US-BrianNeural', label: 'Brian (Male)' }, { id: 'en-US-ChristopherNeural', label: 'Christopher (Male)' }, { id: 'en-US-EmmaMultilingualNeural', label: 'EmmaMultilingual (Female)' }, { id: 'en-US-EmmaNeural', label: 'Emma (Female)' }, { id: 'en-US-EricNeural', label: 'Eric (Male)' }, { id: 'en-US-GuyNeural', label: 'Guy (Male)' }, { id: 'en-US-JennyNeural', label: 'Jenny (Female)' }, { id: 'en-US-MichelleNeural', label: 'Michelle (Female)' }, { id: 'en-US-RogerNeural', label: 'Roger (Male)' }, { id: 'en-US-SteffanNeural', label: 'Steffan (Male)' }] },
  { id: 'en-GB', label: 'English (United Kingdom)', defaultVoice: 'en-GB-LibbyNeural', voices: [{ id: 'en-GB-LibbyNeural', label: 'Libby (Female)' }, { id: 'en-GB-MaisieNeural', label: 'Maisie (Female)' }, { id: 'en-GB-RyanNeural', label: 'Ryan (Male)' }, { id: 'en-GB-SoniaNeural', label: 'Sonia (Female)' }, { id: 'en-GB-ThomasNeural', label: 'Thomas (Male)' }] },
  { id: 'en-AU', label: 'English (Australia)', defaultVoice: 'en-AU-NatashaNeural', voices: [{ id: 'en-AU-NatashaNeural', label: 'Natasha (Female)' }, { id: 'en-AU-WilliamMultilingualNeural', label: 'WilliamMultilingual (Male)' }] },
  { id: 'en-CA', label: 'English (Canada)', defaultVoice: 'en-CA-ClaraNeural', voices: [{ id: 'en-CA-ClaraNeural', label: 'Clara (Female)' }, { id: 'en-CA-LiamNeural', label: 'Liam (Male)' }] },
  { id: 'en-IN', label: 'English (India)', defaultVoice: 'en-IN-NeerjaNeural', voices: [{ id: 'en-IN-NeerjaExpressiveNeural', label: 'NeerjaExpressive (Female)' }, { id: 'en-IN-NeerjaNeural', label: 'Neerja (Female)' }, { id: 'en-IN-PrabhatNeural', label: 'Prabhat (Male)' }] },
  { id: 'ar-SA', label: 'Arabic', defaultVoice: 'ar-SA-HamedNeural', voices: [{ id: 'ar-SA-HamedNeural', label: 'Hamed (Male)' }, { id: 'ar-SA-ZariyahNeural', label: 'Zariyah (Female)' }] },
  { id: 'zh-HK', label: 'Chinese (Hong Kong)', defaultVoice: 'zh-HK-HiuGaaiNeural', voices: [{ id: 'zh-HK-HiuGaaiNeural', label: 'HiuGaai (Female)' }, { id: 'zh-HK-HiuMaanNeural', label: 'HiuMaan (Female)' }, { id: 'zh-HK-WanLungNeural', label: 'WanLung (Male)' }] },
  { id: 'zh-CN', label: 'Chinese (Simplified)', defaultVoice: 'zh-CN-XiaoxiaoNeural', voices: [{ id: 'zh-CN-XiaoxiaoNeural', label: 'Xiaoxiao (Female)' }, { id: 'zh-CN-XiaoyiNeural', label: 'Xiaoyi (Female)' }, { id: 'zh-CN-YunjianNeural', label: 'Yunjian (Male)' }, { id: 'zh-CN-YunxiNeural', label: 'Yunxi (Male)' }, { id: 'zh-CN-YunxiaNeural', label: 'Yunxia (Male)' }, { id: 'zh-CN-YunyangNeural', label: 'Yunyang (Male)' }] },
  { id: 'zh-TW', label: 'Chinese (Traditional)', defaultVoice: 'zh-TW-HsiaoChenNeural', voices: [{ id: 'zh-TW-HsiaoChenNeural', label: 'HsiaoChen (Female)' }, { id: 'zh-TW-HsiaoYuNeural', label: 'HsiaoYu (Female)' }, { id: 'zh-TW-YunJheNeural', label: 'YunJhe (Male)' }] },
  { id: 'fr-FR', label: 'French', defaultVoice: 'fr-FR-DeniseNeural', voices: [{ id: 'fr-FR-DeniseNeural', label: 'Denise (Female)' }, { id: 'fr-FR-EloiseNeural', label: 'Eloise (Female)' }, { id: 'fr-FR-HenriNeural', label: 'Henri (Male)' }, { id: 'fr-FR-RemyMultilingualNeural', label: 'RemyMultilingual (Male)' }, { id: 'fr-FR-VivienneMultilingualNeural', label: 'VivienneMultilingual (Female)' }] },
  { id: 'de-DE', label: 'German', defaultVoice: 'de-DE-AmalaNeural', voices: [{ id: 'de-DE-AmalaNeural', label: 'Amala (Female)' }, { id: 'de-DE-ConradNeural', label: 'Conrad (Male)' }, { id: 'de-DE-FlorianMultilingualNeural', label: 'FlorianMultilingual (Male)' }, { id: 'de-DE-KatjaNeural', label: 'Katja (Female)' }, { id: 'de-DE-KillianNeural', label: 'Killian (Male)' }, { id: 'de-DE-SeraphinaMultilingualNeural', label: 'SeraphinaMultilingual (Female)' }] },
  { id: 'hi-IN', label: 'Hindi', defaultVoice: 'hi-IN-MadhurNeural', voices: [{ id: 'hi-IN-MadhurNeural', label: 'Madhur (Male)' }, { id: 'hi-IN-SwaraNeural', label: 'Swara (Female)' }] },
  { id: 'it-IT', label: 'Italian', defaultVoice: 'it-IT-DiegoNeural', voices: [{ id: 'it-IT-DiegoNeural', label: 'Diego (Male)' }, { id: 'it-IT-ElsaNeural', label: 'Elsa (Female)' }, { id: 'it-IT-GiuseppeMultilingualNeural', label: 'GiuseppeMultilingual (Male)' }, { id: 'it-IT-IsabellaNeural', label: 'Isabella (Female)' }] },
  { id: 'ja-JP', label: 'Japanese', defaultVoice: 'ja-JP-NanamiNeural', voices: [{ id: 'ja-JP-KeitaNeural', label: 'Keita (Male)' }, { id: 'ja-JP-NanamiNeural', label: 'Nanami (Female)' }] },
  { id: 'ko-KR', label: 'Korean', defaultVoice: 'ko-KR-SunHiNeural', voices: [{ id: 'ko-KR-HyunsuMultilingualNeural', label: 'HyunsuMultilingual (Male)' }, { id: 'ko-KR-InJoonNeural', label: 'InJoon (Male)' }, { id: 'ko-KR-SunHiNeural', label: 'SunHi (Female)' }] },
  { id: 'pt-BR', label: 'Portuguese (Brazilian)', defaultVoice: 'pt-BR-FranciscaNeural', voices: [{ id: 'pt-BR-AntonioNeural', label: 'Antonio (Male)' }, { id: 'pt-BR-FranciscaNeural', label: 'Francisca (Female)' }, { id: 'pt-BR-ThalitaMultilingualNeural', label: 'ThalitaMultilingual (Female)' }] },
  { id: 'pt-PT', label: 'Portuguese (European)', defaultVoice: 'pt-PT-RaquelNeural', voices: [{ id: 'pt-PT-DuarteNeural', label: 'Duarte (Male)' }, { id: 'pt-PT-RaquelNeural', label: 'Raquel (Female)' }] },
  { id: 'es-ES', label: 'Spanish', defaultVoice: 'es-ES-XimenaNeural', voices: [{ id: 'es-ES-AlvaroNeural', label: 'Alvaro (Male)' }, { id: 'es-ES-ElviraNeural', label: 'Elvira (Female)' }, { id: 'es-ES-XimenaNeural', label: 'Ximena (Female)' }] },
  { id: 'th-TH', label: 'Thai', defaultVoice: 'th-TH-PremwadeeNeural', voices: [{ id: 'th-TH-NiwatNeural', label: 'Niwat (Male)' }, { id: 'th-TH-PremwadeeNeural', label: 'Premwadee (Female)' }] },
  { id: 'fa-IR', label: 'Persian (Farsi)', defaultVoice: 'fa-IR-DilaraNeural', voices: [{ id: 'fa-IR-DilaraNeural', label: 'Dilara (Female)' }, { id: 'fa-IR-FaridNeural', label: 'Farid (Male)' }] },
  { id: 'vi-VN', label: 'Vietnamese', defaultVoice: 'vi-VN-HoaiMyNeural', voices: [{ id: 'vi-VN-HoaiMyNeural', label: 'HoaiMy (Female)' }, { id: 'vi-VN-NamMinhNeural', label: 'NamMinh (Male)' }] },
];
