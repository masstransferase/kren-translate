import type { GrammarChoice, GrammarIssue, GrammarSource } from './contracts.js';
import { MINIMAL_CORRECTION_POLICY } from './rewriteVariants.js';

interface GrammarToken {
  text: string;
  start: number;
  end: number;
}

interface DiffOperation {
  kind: 'equal' | 'replace' | 'delete' | 'insert';
  oldIndex: number;
  newIndex: number;
}

interface ChangedRun {
  oldStart: number;
  oldEnd: number;
  newStart: number;
  newEnd: number;
}

interface GrammarEdit {
  start: number;
  end: number;
  replacement: string;
}

interface SmartGrammarEdit extends GrammarEdit {
  original: string;
}

export const SMART_GRAMMAR_RESPONSE_SCHEMA: Record<string, unknown> = {
  type: 'object',
  additionalProperties: false,
  required: ['correctedText'],
  properties: {
    correctedText: { type: 'string' }
  }
};

/**
 * Smart Grammar Check corrects unnatural phrasing without applying style preferences.
 * MINIMAL_CORRECTION_POLICY is shared with Minimal Rewrite because both perform the same
 * corrections, presented as findings or as a draft. The response shape, error classes, and
 * worked examples are specific to this feature.
 *
 * DEFAULT_SMART_GRAMMAR_MAX_CHANGED_PROPORTION rejects corrections that change too much
 * of the input, preventing a restyled paragraph from reaching the document.
 */
export const SMART_GRAMMAR_INSTRUCTION = [
  `Smart Grammar Check: ${MINIMAL_CORRECTION_POLICY}`,
  'Correct grammar, spelling, punctuation, and agreement as part of that set.',
  'Phrasing is wrong when a native speaker of the text\'s language would not say it: a collocation the language does not use, a verb or preposition that does not pair with its noun, a literal rendering of an idiom from another language, and vocabulary belonging to a register or an age group that does not fit the writer. A sentence containing no grammatical error can still be wrong in this way.',
  // Spelling candidates must fit the sentence because edit distance alone cannot identify
  // the intended word. A nearby real word can still leave the sentence meaningless.
  'Correct a misspelling to the word the sentence needs, not to whichever real word is closest in spelling or sound. Read the whole sentence first and ask which word makes it mean something; a candidate that leaves the sentence meaningless is the wrong candidate however few letters separate it from the input.',
  // OpenAI and Anthropic receive the schema, but Gemini cannot. The instruction
  // therefore repeats the shape literally, and a test keeps both statements aligned.
  'Return JSON only, with exactly this shape and no other keys:',
  '{"correctedText":"corrected text"}',
  'Return the complete corrected text in correctedText only. Do not return an explanation, notes, alternatives, or character offsets.',
  'Minimal-change example:',
  'Input: He showed up my office today',
  'Output: {"correctedText":"He showed up at my office today"}',
  'Register example, where the grammar is already correct:',
  'Input: I played with my friends last weekend.',
  'Output: {"correctedText":"I hung out with my friends last weekend."}',
  'Collocation example, where the grammar is already correct:',
  'Input: We discussed about the schedule.',
  'Output: {"correctedText":"We discussed the schedule."}',
  'Misspelling example, where the nearest-looking word is not the right one:',
  'Input: She go to the school without breakfast this moringn.',
  'Output: {"correctedText":"She goes to school without breakfast this morning."}',
  'No-change example:',
  'Input: The report is ready.',
  'Output: {"correctedText":"The report is ready."}'
].join('\n');

/**
 * Harper's findings, written into the model's instruction as reference rather than left to
 * be reconciled afterwards.
 *
 * Harper is a local rule and dictionary engine reading one span at a time. Asked about
 * "moringn" it ranked candidates by edit distance and offered "miring", "mooing", and
 * "mooring", none of which the sentence can mean. It is still worth showing the model,
 * because it catches things a model glosses over and because its candidate list is usually
 * right; it just has no way to tell when it is not.
 *
 * So the model is given the flags and told what they are worth: adopt a candidate when the
 * sentence supports it, override it when the sentence does not, and treat the absence of a
 * flag as no evidence either way. Harper's findings quote the reader's own words, which are
 * already being sent as the passage itself, so this adds nothing new about the reader to
 * the request. It adds only what a local checker made of it.
 *
 * Returns the empty string when Harper found nothing, so a caller can concatenate it
 * unconditionally without printing a heading above an empty list.
 */
export function harperReferenceInstruction(issues: readonly GrammarIssue[]): string {
  if (issues.length === 0) return '';
  const lines = issues.map((issue) => {
    const candidates = issue.suggestions
      .map((suggestion) => suggestion.replacement.trim())
      .filter(Boolean);
    const offered = candidates.length > 0
      ? `candidates: ${candidates.map((candidate) => `"${candidate}"`).join(', ')}`
      : 'no candidate offered';
    return `- "${issue.original}" (${issue.category}); ${offered}`;
  });
  return [
    '',
    'A local rule-and-dictionary checker has already read this text and flagged the following. Its candidates are ranked by spelling similarity and it cannot read the sentence, so a candidate that leaves the sentence meaningless is wrong however close it looks.',
    ...lines,
    'Use these as evidence, not as instructions. Adopt a candidate when the sentence supports it. Override it when the sentence does not, and correct to the word the sentence needs instead. A span the checker did not flag can still be wrong, and a span it did flag can be correct as written.'
  ].join('\n');
}

// One changed token in a two-token clause is a legitimate correction, while changing
// more than half of a longer input is more likely restyling than grammar repair.
export const DEFAULT_SMART_GRAMMAR_MAX_CHANGED_PROPORTION = 0.5;

/**
 * Returns undefined when the correction changes too much of the input to be trusted.
 * An empty array means the model returned the input unchanged.
 */
export function smartGrammarCorrectionToIssues(
  sourceText: string,
  correctedText: string,
  maximumChangedProportion = DEFAULT_SMART_GRAMMAR_MAX_CHANGED_PROPORTION
): GrammarIssue[] | undefined {
  if (!Number.isFinite(maximumChangedProportion) || maximumChangedProportion < 0 ||
      maximumChangedProportion > 1) {
    throw new RangeError('The Smart Grammar changed proportion must be between zero and one.');
  }
  if (sourceText === correctedText) return [];

  const sourceTokens = grammarTokens(sourceText);
  const correctedTokens = grammarTokens(correctedText);
  const { distance, operations } = alignTokens(sourceTokens, correctedTokens);
  const changedProportion = sourceTokens.length === 0
    ? (distance === 0 ? 0 : Number.POSITIVE_INFINITY)
    : distance / sourceTokens.length;
  if (changedProportion > maximumChangedProportion) return undefined;

  const runs = changedRuns(operations, sourceTokens.length, correctedTokens.length);
  const edits = runs.map((run) =>
    runEdit(sourceText, correctedText, sourceTokens, correctedTokens, run)
  );
  edits.push(...unchangedGapEdits(
    sourceText,
    correctedText,
    sourceTokens,
    correctedTokens,
    operations
  ));
  return edits
    .filter((edit) => edit.original !== edit.replacement)
    .sort((left, right) => left.start - right.start || left.end - right.end)
    .map((edit, index) =>
      smartGrammarIssue(edit.start, edit.end, edit.original, edit.replacement, index)
    );
}

export function applyGrammarChoices(
  result: GrammarSource,
  choices: readonly GrammarChoice[]
): string {
  const selected = new Map<string, number>();
  for (const choice of choices) {
    if (Number.isInteger(choice.suggestionIndex) && choice.suggestionIndex >= 0) {
      selected.set(choice.issueId, choice.suggestionIndex);
    }
  }

  // One choice selects one finding. Ids are unique in practice, from a counter in the
  // Harper worker and from start, end, and index in the smart corrections, but the
  // selection above is keyed by id, so a repeated id used to spend a single choice on every
  // finding wearing it. Two of those overlap by construction, which threw. Consuming the id
  // makes the code mean what `GrammarChoice` says.
  const spent = new Set<string>();
  const edits = result.issues.flatMap((issue) => {
    if (spent.has(issue.id)) return [];
    const suggestionIndex = selected.get(issue.id);
    if (suggestionIndex !== undefined) spent.add(issue.id);
    return selectedEdit(result.sourceText, issue, suggestionIndex);
  });
  edits.sort((left, right) => right.start - left.start || right.end - left.end);

  for (let index = 1; index < edits.length; index += 1) {
    const previous = edits[index - 1];
    const current = edits[index];
    if (previous && current && current.end > previous.start) {
      throw new Error('Overlapping grammar corrections cannot be applied together.');
    }
  }

  return edits.reduce(
    (text, edit) => text.slice(0, edit.start) + edit.replacement + text.slice(edit.end),
    result.sourceText
  );
}

/**
 * Preselects the first suggestion of each finding that applyGrammarChoices can accept.
 * Overlapping spans, stale or reversed ranges, and repeated issue identifiers remain on
 * Keep original because selecting them would make application fail. Zero-width insertions
 * inside a replacement overlap it; insertions at the same offset can both be applied.
 * Reading the whole GrammarSource keeps text validation and insertion rules aligned with
 * application, so the returned choices can be applied without throwing.
 */
export function preselectedGrammarChoices(source: GrammarSource): GrammarChoice[] {
  const chosen: GrammarChoice[] = [];
  const spans: GrammarEdit[] = [];
  const seenIds = new Set<string>();
  for (const issue of source.issues) {
    const suggestion = issue.suggestions[0];
    if (!suggestion) continue;
    if (seenIds.has(issue.id)) continue;
    seenIds.add(issue.id);
    if (source.sourceText.slice(issue.start, issue.end) !== issue.original) continue;
    const span = editSpan(issue, suggestion.kind === 'insertAfter');
    if (spans.some((taken) => span.start < taken.end && taken.start < span.end)) continue;
    chosen.push({ issueId: issue.id, suggestionIndex: 0 });
    spans.push(span);
  }
  return chosen;
}

function editSpan(issue: GrammarIssue, insertion: boolean): GrammarEdit {
  return {
    start: insertion ? issue.end : issue.start,
    end: issue.end,
    replacement: ''
  };
}

function selectedEdit(
  sourceText: string,
  issue: GrammarIssue,
  suggestionIndex: number | undefined
): GrammarEdit[] {
  if (suggestionIndex === undefined) return [];
  const suggestion = issue.suggestions[suggestionIndex];
  if (!suggestion) return [];
  if (sourceText.slice(issue.start, issue.end) !== issue.original) {
    throw new Error('A grammar issue no longer matches the checked text.');
  }

  // Through editSpan, so the preselection above and the application here cannot disagree
  // about where an insertion lands. They did not have to agree while nothing was selected
  // by default; now a disagreement would preselect a set core then refuses to apply.
  return [{ ...editSpan(issue, suggestion.kind === 'insertAfter'), replacement: suggestion.replacement }];
}

function grammarTokens(text: string): GrammarToken[] {
  const tokens: GrammarToken[] = [];
  const pattern = /[\p{L}\p{M}\p{N}]+(?:['\u2019-][\p{L}\p{M}\p{N}]+)*|[^\s]/gu;
  for (const match of text.matchAll(pattern)) {
    const value = match[0];
    const start = match.index;
    tokens.push({ text: value, start, end: start + value.length });
  }
  return tokens;
}

function alignTokens(
  source: readonly GrammarToken[],
  corrected: readonly GrammarToken[]
): { distance: number; operations: DiffOperation[] } {
  const distances = Array.from(
    { length: source.length + 1 },
    () => Array<number>(corrected.length + 1).fill(0)
  );
  for (let oldIndex = source.length; oldIndex >= 0; oldIndex -= 1) {
    for (let newIndex = corrected.length; newIndex >= 0; newIndex -= 1) {
      if (oldIndex === source.length) {
        distances[oldIndex]![newIndex] = corrected.length - newIndex;
      } else if (newIndex === corrected.length) {
        distances[oldIndex]![newIndex] = source.length - oldIndex;
      } else if (source[oldIndex]!.text === corrected[newIndex]!.text) {
        distances[oldIndex]![newIndex] = distances[oldIndex + 1]![newIndex + 1]!;
      } else {
        distances[oldIndex]![newIndex] = 1 + Math.min(
          distances[oldIndex + 1]![newIndex + 1]!,
          distances[oldIndex + 1]![newIndex]!,
          distances[oldIndex]![newIndex + 1]!
        );
      }
    }
  }

  const operations: DiffOperation[] = [];
  let oldIndex = 0;
  let newIndex = 0;
  while (oldIndex < source.length || newIndex < corrected.length) {
    if (oldIndex < source.length && newIndex < corrected.length &&
        source[oldIndex]!.text === corrected[newIndex]!.text) {
      operations.push({ kind: 'equal', oldIndex, newIndex });
      oldIndex += 1;
      newIndex += 1;
      continue;
    }

    const replacement = oldIndex < source.length && newIndex < corrected.length
      ? distances[oldIndex + 1]![newIndex + 1]!
      : Number.POSITIVE_INFINITY;
    const deletion = oldIndex < source.length
      ? distances[oldIndex + 1]![newIndex]!
      : Number.POSITIVE_INFINITY;
    const insertion = newIndex < corrected.length
      ? distances[oldIndex]![newIndex + 1]!
      : Number.POSITIVE_INFINITY;
    if (replacement <= deletion && replacement <= insertion) {
      operations.push({ kind: 'replace', oldIndex, newIndex });
      oldIndex += 1;
      newIndex += 1;
    } else if (deletion <= insertion) {
      operations.push({ kind: 'delete', oldIndex, newIndex });
      oldIndex += 1;
    } else {
      operations.push({ kind: 'insert', oldIndex, newIndex });
      newIndex += 1;
    }
  }

  return { distance: distances[0]![0]!, operations };
}

function changedRuns(
  operations: readonly DiffOperation[],
  sourceLength: number,
  correctedLength: number
): ChangedRun[] {
  const runs: ChangedRun[] = [];
  let operationIndex = 0;
  while (operationIndex < operations.length) {
    const first = operations[operationIndex]!;
    if (first.kind === 'equal') {
      operationIndex += 1;
      continue;
    }
    const oldStart = first.oldIndex;
    const newStart = first.newIndex;
    while (operationIndex < operations.length &&
           operations[operationIndex]!.kind !== 'equal') {
      operationIndex += 1;
    }
    const next = operations[operationIndex];
    runs.push({
      oldStart,
      oldEnd: next?.oldIndex ?? sourceLength,
      newStart,
      newEnd: next?.newIndex ?? correctedLength
    });
  }
  return runs;
}

function runEdit(
  sourceText: string,
  correctedText: string,
  sourceTokens: readonly GrammarToken[],
  correctedTokens: readonly GrammarToken[],
  run: ChangedRun
): SmartGrammarEdit {
  if (run.oldStart < run.oldEnd && run.newStart < run.newEnd) {
    const firstSource = sourceTokens[run.oldStart]!;
    const lastSource = sourceTokens[run.oldEnd - 1]!;
    const firstCorrection = correctedTokens[run.newStart]!;
    const lastCorrection = correctedTokens[run.newEnd - 1]!;
    return {
      start: firstSource.start,
      end: lastSource.end,
      original: sourceText.slice(firstSource.start, lastSource.end),
      replacement: correctedText.slice(firstCorrection.start, lastCorrection.end)
    };
  }

  if (run.oldStart === run.oldEnd) {
    const nextSource = sourceTokens[run.oldStart];
    const firstCorrection = correctedTokens[run.newStart]!;
    const nextCorrection = correctedTokens[run.newEnd];
    const start = nextSource?.start ?? sourceText.length;
    const replacementStart = nextCorrection
      ? firstCorrection.start
      : (correctedTokens[run.newStart - 1]?.end ?? firstCorrection.start);
    const replacementEnd = nextCorrection?.start ?? correctedText.length;
    return {
      start,
      end: start,
      original: '',
      replacement: correctedText.slice(replacementStart, replacementEnd)
    };
  }

  const firstSource = sourceTokens[run.oldStart]!;
  const nextSource = sourceTokens[run.oldEnd];
  const previousSource = sourceTokens[run.oldStart - 1];
  const start = nextSource ? firstSource.start : (previousSource?.end ?? firstSource.start);
  const end = nextSource?.start ?? sourceText.length;
  return {
    start,
    end,
    original: sourceText.slice(start, end),
    replacement: ''
  };
}

function unchangedGapEdits(
  sourceText: string,
  correctedText: string,
  sourceTokens: readonly GrammarToken[],
  correctedTokens: readonly GrammarToken[],
  operations: readonly DiffOperation[]
): SmartGrammarEdit[] {
  if (operations.length === 0) {
    return sourceText === correctedText
      ? []
      : [{ start: 0, end: sourceText.length, original: sourceText, replacement: correctedText }];
  }

  const edits: SmartGrammarEdit[] = [];
  for (let index = 0; index < operations.length; index += 1) {
    const current = operations[index]!;
    if (current.kind !== 'equal') continue;
    const currentSource = sourceTokens[current.oldIndex]!;
    const currentCorrection = correctedTokens[current.newIndex]!;
    if (index === 0) {
      addGapEdit(edits, sourceText, correctedText, 0, currentSource.start, 0,
        currentCorrection.start);
    }

    const previous = operations[index - 1];
    if (previous?.kind === 'equal') {
      const previousSource = sourceTokens[previous.oldIndex]!;
      const previousCorrection = correctedTokens[previous.newIndex]!;
      addGapEdit(
        edits,
        sourceText,
        correctedText,
        previousSource.end,
        currentSource.start,
        previousCorrection.end,
        currentCorrection.start
      );
    }

    if (index === operations.length - 1) {
      addGapEdit(
        edits,
        sourceText,
        correctedText,
        currentSource.end,
        sourceText.length,
        currentCorrection.end,
        correctedText.length
      );
    }
  }
  return edits;
}

function addGapEdit(
  edits: SmartGrammarEdit[],
  sourceText: string,
  correctedText: string,
  sourceStart: number,
  sourceEnd: number,
  correctedStart: number,
  correctedEnd: number
): void {
  const original = sourceText.slice(sourceStart, sourceEnd);
  const replacement = correctedText.slice(correctedStart, correctedEnd);
  if (original !== replacement) {
    edits.push({ start: sourceStart, end: sourceEnd, original, replacement });
  }
}

function smartGrammarIssue(
  start: number,
  end: number,
  original: string,
  replacement: string,
  index: number
): GrammarIssue {
  const originalLabel = original.trim();
  const replacementLabel = replacement.trim();
  const spacingOnly = originalLabel === '' && replacementLabel === '';
  const message = spacingOnly
    ? 'Smart Grammar Check suggests changing the spacing.'
    : originalLabel === ''
    ? `Smart Grammar Check suggests inserting "${replacementLabel}".`
    : replacementLabel === ''
      ? `Smart Grammar Check suggests removing "${originalLabel}".`
      : `Smart Grammar Check suggests changing "${originalLabel}" to "${replacementLabel}".`;
  return {
    id: `smart-grammar-${start}-${end}-${index}`,
    start,
    end,
    original,
    category: 'grammar',
    message,
    suggestions: [{
      kind: replacement === '' ? 'remove' : 'replace',
      replacement,
      label: spacingOnly ? 'Change spacing' : replacementLabel || 'Remove'
    }]
  };
}

/**
 * The selection split into the whitespace the user swept up and the text they meant.
 *
 * Selecting a sentence in Word very often takes a leading or trailing space with it, and
 * KREN used to send that whitespace to Harper and to the model. Neither has anything useful
 * to say about it, and the model in particular returns the text trimmed, so the difference
 * between what was sent and what came back included the whitespace itself. That produced
 * findings at the edges of the selection that correct nothing, and accepting them silently
 * removed spacing the writer had put there.
 *
 * The affixes are kept rather than discarded so replacement can put them back. Trimming
 * without restoring would eat the space between two words in the document, which is a
 * quieter and worse failure than the one being fixed.
 */
export interface TrimmedSelection {
  readonly leading: string;
  readonly text: string;
  readonly trailing: string;
}

export function trimSelectionForChecking(selection: string): TrimmedSelection {
  // A selection of nothing but whitespace has no text to check. It is reported as empty
  // text with the whole selection as its leading affix, so restoring still returns exactly
  // what the writer had.
  const match = /^(\s*)([\s\S]*?)(\s*)$/u.exec(selection);
  if (!match) return { leading: '', text: selection, trailing: '' };
  return { leading: match[1] ?? '', text: match[2] ?? '', trailing: match[3] ?? '' };
}

/**
 * Collapses runs of repeated spaces to one.
 *
 * A single space at either edge of the selection is not an error and must never be
 * reported, while two or more spaces are an error wherever they
 * appear, including at the edges.
 *
 * **A value containing a line break is returned untouched.** A blank line between
 * paragraphs is structure, not repeated spacing, and collapsing it would join two
 * paragraphs. That is a worse edit than the one being made and the pane cannot undo it.
 */
export function collapseRepeatedSpaces(value: string): string {
  if (/[\r\n]/u.test(value)) return value;
  return value.replace(/ {2,}/gu, ' ');
}

export function restoreSelectionAffixes(
  trimmed: TrimmedSelection,
  replacement: string
): string {
  const leading = collapseRepeatedSpaces(trimmed.leading);
  const trailing = collapseRepeatedSpaces(trimmed.trailing);
  return `${leading}${replacement}${trailing}`;
}

/**
 * A finding for every run of two or more spaces inside the checked text.
 *
 * KREN produces these itself rather than hoping a checker notices. Harper's ruleset is not
 * guaranteed to cover repeated spacing, and Smart Grammar Check is a language model, so
 * neither is a dependable answer to "is the spacing right". This is decidable by looking,
 * so it is decided by looking.
 *
 * They are ordinary findings, so they appear in the review list, arrive already chosen like
 * every other first suggestion, and can be rejected individually.
 */
export function repeatedSpaceIssues(sourceText: string): GrammarIssue[] {
  const issues: GrammarIssue[] = [];
  for (const match of sourceText.matchAll(/ {2,}/gu)) {
    const start = match.index;
    const original = match[0];
    issues.push({
      id: `spacing-${start}-${original.length}`,
      start,
      end: start + original.length,
      original,
      category: 'style',
      message: `${original.length} spaces where one is expected.`,
      suggestions: [{ kind: 'replace', replacement: ' ', label: 'one space' }]
    });
  }
  return issues;
}
