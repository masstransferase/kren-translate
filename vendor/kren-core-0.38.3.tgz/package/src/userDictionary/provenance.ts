import type {
  MerriamWebsterReferenceWork,
  UserDictionaryEntryV1
} from './contract.js';

/**
 * Where a stored entry's wording came from, as one plain-text sentence group.
 *
 * Both hosts show this, and both must show the same words. A dictionary entry credits a
 * publisher, and a publisher credited differently in two products is two different claims
 * about the same stored record.
 *
 * What this must never say is that any Merriam-Webster wording is in the entry, because
 * none is. The live reference is displayed beside the draft during review and discarded on
 * save, and `attachUserDictionaryMerriamWebsterReference` stores a citation record rather
 * than text. The sentence therefore credits a consultation, which is what happened.
 *
 * Keyed on the stored citation record rather than on `capture.mode`, because the record is
 * what says a query actually ran. Returns plain text with no markup, so a host escapes it
 * for its own output.
 */
export function userDictionarySourceLine(entry: UserDictionaryEntryV1): string {
  if (entry.capture.mode === 'manual') {
    return 'Source: written or imported by you. No publisher and no language model contributed.';
  }
  // Stated because it changes what left the machine. Every other capture sends one
  // expression; this one sent a line of the reader's document as well, and the citation is
  // the only place that difference is recorded.
  const from = entry.capturedContext
    ? ' from your selection and the sentence around it'
    : '';
  const drafted =
    `Source: drafted by ${entry.capture.provider} / ${entry.capture.model}${from}.`;
  const reference = entry.merriamWebsterReference;
  const publisher = reference
    ? MERRIAM_WEBSTER_REFERENCE_WORK_LABELS[reference.referenceWork]
    : '';
  const consulted = !reference || reference.matchStatus === 'notQueried'
    ? ' No dictionary publisher was consulted.'
    : reference.matchStatus === 'matched'
      ? ` ${publisher} was consulted for review under "${reference.lookupTerm}"; its wording is not stored in this entry.`
      : ` ${publisher} returned no match for "${reference.lookupTerm}".`;
  const edited = entry.capture.userEdited ? ' Edited by you after generation.' : '';
  return `${drafted}${consulted}${edited}`;
}

export const MERRIAM_WEBSTER_REFERENCE_WORK_LABELS:
  Record<MerriamWebsterReferenceWork, string> = {
    collegiate: "Merriam-Webster's Collegiate® Dictionary"
  };
