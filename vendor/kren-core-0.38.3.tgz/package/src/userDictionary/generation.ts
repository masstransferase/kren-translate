import { isPlausibleLanguageCode } from '../validation.js';
import { tidyCapturedText } from './contextSentence.js';
import { USER_DICTIONARY_CONTEXT_MAX_CHARACTERS } from './contract.js';
import type {
  UserDictionaryCaptureMode,
  UserDictionaryEntryV1,
  UserDictionaryProvider
} from './contract.js';
import { normalizeUserDictionaryTerm } from './normalization.js';
import { validateUserDictionaryEntry } from './validation.js';

const USER_DICTIONARY_EXPRESSION_MAX_CHARACTERS = 200;
const USER_DICTIONARY_EXPRESSION_MAX_WORDS = 16;

export interface UserDictionaryCaptureSettings {
  captureMode?: UserDictionaryCaptureMode;
  entryLanguage: string;
  includePronunciation: boolean;
  includeSynonyms: boolean;
  includeUsageNotes: boolean;
  numberOfExamples: number;
  includeTechnicalMeanings: boolean;
}

interface GeneratedSense {
  partOfSpeech: string;
  pronunciation: string;
  definition: string;
  usageNote: string;
  synonyms: string[];
  antonyms: string[];
  relatedTerms: string[];
  examples: string[];
}

interface GeneratedDictionaryContent {
  term?: string;
  language: string;
  entryType: string;
  domains: string[];
  tags: string[];
  pronunciation: string;
  senses: GeneratedSense[];
  aliases: string[];
  contextSenseIndex?: number;
}

export class UserDictionaryMalformedOutputError extends Error {
  public constructor() {
    super('The selected language-model provider returned malformed User Dictionary output. No entry was saved.');
    this.name = 'UserDictionaryMalformedOutputError';
  }
}

export const USER_DICTIONARY_GENERATION_SCHEMA: Record<string, unknown> = {
  type: 'object',
  additionalProperties: false,
  required: [
    'term', 'language', 'entryType', 'domains', 'tags', 'pronunciation', 'senses', 'aliases'
  ],
  properties: {
    term: { type: 'string' },
    language: { type: 'string' },
    entryType: { type: 'string' },
    domains: { type: 'array', items: { type: 'string' }, maxItems: 12 },
    tags: { type: 'array', items: { type: 'string' }, maxItems: 20 },
    pronunciation: { type: 'string' },
    senses: {
      type: 'array',
      minItems: 1,
      maxItems: 12,
      items: {
        type: 'object',
        additionalProperties: false,
        required: [
          'partOfSpeech', 'pronunciation', 'definition', 'usageNote', 'synonyms', 'antonyms',
          'relatedTerms', 'examples'
        ],
        properties: {
          partOfSpeech: { type: 'string' },
          pronunciation: { type: 'string' },
          definition: { type: 'string' },
          usageNote: { type: 'string' },
          synonyms: { type: 'array', items: { type: 'string' }, maxItems: 20 },
          antonyms: { type: 'array', items: { type: 'string' }, maxItems: 20 },
          relatedTerms: { type: 'array', items: { type: 'string' }, maxItems: 20 },
          examples: { type: 'array', items: { type: 'string' }, maxItems: 3 }
        }
      }
    },
    aliases: { type: 'array', items: { type: 'string' }, maxItems: 20 }
  }
};

export interface UserDictionaryGenerationOptions {
  /**
   * True when the expression came from the user typing it rather than from a document
   * selection. Regenerating after editing the Expression field is the case that matters:
   * the user has already decided the headword, so proposing a different citation form
   * overrules a deliberate choice. Selecting "attached" in a document is ambiguous;
   * typing it into the field and asking again is not.
   */
  termSuppliedByUser?: boolean;
  /**
   * The sentence the expression was selected in, when the reader has Smart Word Capture on.
   * Supplying it changes what the model is asked for rather than merely adding detail: it
   * may then say which of the senses this sentence uses, so "turn up" resolves to "appear"
   * in one sentence and to "increase" in another. Absent means the expression stands alone.
   */
  contextSentence?: string;
}

/**
 * The provider schema, which gains one field when a context sentence is supplied. Derived
 * from the no-context schema rather than written out twice, because the inline shape in the
 * instruction is checked against this object and a second hand-maintained copy is exactly
 * how the two drift apart.
 */
export function userDictionaryGenerationSchema(
  options: UserDictionaryGenerationOptions = {}
): Record<string, unknown> {
  if (!options.contextSentence) return USER_DICTIONARY_GENERATION_SCHEMA;
  const base = USER_DICTIONARY_GENERATION_SCHEMA;
  const properties = base.properties as Record<string, unknown>;
  return {
    ...base,
    required: [...(base.required as string[]), 'contextSenseIndex'],
    properties: {
      ...properties,
      // -1 rather than an omitted field, because a provider that cannot answer must still
      // return the same shape; an optional field turns "undecided" into "malformed".
      contextSenseIndex: { type: 'integer', minimum: -1 }
    }
  };
}

export function userDictionaryGenerationInstruction(
  settings: UserDictionaryCaptureSettings,
  options: UserDictionaryGenerationOptions = {}
): string {
  const language = settings.entryLanguage === 'auto'
    ? 'Detect the expression language and return its BCP-47 language tag.'
    : `Use the BCP-47 entry language ${settings.entryLanguage}.`;
  const context = options.contextSentence?.trim();
  return [
    'Create a concise personal dictionary draft for exactly the expression supplied by the user.',
    context
      ? `The user selected this expression inside the following sentence, which is the only context that exists. Use it to judge which meaning applies, and do not infer a file, workspace, author, audience, or anything else it does not say.\nSentence: ${context}`
      : 'No surrounding document context exists. Do not infer a file, workspace, author, audience, or unstated context.',
    language,
    'The term is the citation form of the lexical unit actually being recorded, not the lemma of its first word, and this is not blind lemmatisation.',
    'When the selection is one lexical item in an inflected form, lemmatise that lexical item: "showed up" becomes "show up", and "shows" becomes "show".',
    'Keep the selected form unchanged when it is a phrase or clause rather than one lexical item: "an image attached to an email" stays "an image attached to an email".',
    'Keep an inflected-looking form unchanged when it is itself a distinct lexical item: the noun "meaning" stays "meaning", not "mean".',
    'Keep a participle unchanged only when the selection itself contains the noun it modifies: "attached" in "the attached file" stays "attached", not "attach".',
    context
      ? 'A past-tense or participle form is a verb form unless the sentence shows it modifying a noun: "attached" becomes "attach" in "he attached the file", and stays "attached" in "the attached file is large".'
      : 'A past-tense or participle form standing alone is a verb form, because no surrounding context exists to make it an adjective: "attached" alone becomes "attach", and "showed" alone becomes "show".',
    options.termSuppliedByUser
      ? 'The user supplied this expression directly rather than selecting it from a document, so it is already the term they want. Return it in term exactly as given, with no citation-form change, and describe that exact form.'
      : 'Return this citation form in term.',
    // OpenAI and Anthropic receive the schema, but Gemini cannot. The instruction
    // therefore repeats the shape literally, and a test keeps both statements aligned.
    'Return JSON only, with exactly this shape and no other keys:',
    '{"term":"citation form","language":"BCP-47 tag","entryType":"short label","domains":[],"tags":[],' +
      '"pronunciation":"","senses":[{"partOfSpeech":"","pronunciation":"","definition":"","usageNote":"",' +
      '"synonyms":[],"antonyms":[],"relatedTerms":[],"examples":[]}],"aliases":[]' +
      (context ? ',"contextSenseIndex":0' : '') + '}',
    'Use at least one sense with a non-empty definition. Keep every claim within ordinary lexical knowledge.',
    // The senses are still the whole entry. Asking the model to narrow the entry to the one
    // meaning the sentence uses would turn a dictionary entry into an annotation, and the
    // reader saved the word to learn it rather than to record one encounter with it.
    ...(context
      ? [
        'List every ordinary meaning of the expression, not only the one this sentence uses. The sentence selects among the senses; it does not limit them.',
        'Set contextSenseIndex to the zero-based position in senses of the meaning this sentence uses.',
        'Set contextSenseIndex to -1 when the sentence does not distinguish the senses, and do not guess. Returning -1 is a correct answer, not a failure.'
      ]
      : []),
    // entryType classifies the expression rather than naming the record. The vocabulary is
    // stated here and enforced below because instructions alone cannot guarantee validity.
    'entryType is the grammatical category of the expression as a whole: the part of speech when one applies, such as noun, verb, adjective, adverb, or proper noun, and otherwise the kind of unit, such as phrase, idiom, abbreviation, acronym, prefix, or suffix.',
    'When the first sense has a part of speech, return that same part of speech in entryType.',
    'entryType never names the record itself. Do not return headword, lemma, entry, term, word, definition, or expression.',
    settings.includePronunciation
      ? 'Include a readable pronunciation when appropriate; otherwise return an empty pronunciation string.'
      : 'Return an empty pronunciation string.',
    // Heteronyms are the case a single entry-level pronunciation gets wrong, and they are
    // exactly the words a reader records because the spelling misled them. Asked for per
    // sense, and asked for only where it differs, so the ordinary entry does not repeat one
    // pronunciation down every sense.
    settings.includePronunciation
      ? 'Set the sense pronunciation only for a heteronym, where this spelling is pronounced differently depending on which sense is meant, as with the noun and the verb "record", or "lead" the metal and "lead" the verb. Return an empty sense pronunciation string for every sense that takes the entry pronunciation, which is almost always all of them.'
      : 'Return an empty pronunciation string for every sense.',
    settings.includeSynonyms
      ? 'Include relevant synonyms, antonyms, and related expressions.'
      : 'Return empty synonyms, antonyms, and relatedTerms arrays.',
    settings.includeUsageNotes
      ? 'Include a short usage note only when it prevents misunderstanding.'
      : 'Return an empty usageNote string for every sense.',
    'Put in aliases the other surface forms a reader might search for: irregular inflected forms such as "gave" and "given" for "give", and spelling variants. Omit regular forms a reader can predict, and never repeat the term itself.',
    `Return no more than ${settings.numberOfExamples} example${settings.numberOfExamples === 1 ? '' : 's'} per sense.`,
    settings.includeTechnicalMeanings
      ? 'Include established technical meanings when they are genuinely applicable.'
      : 'Do not add a technical sense solely because one might exist.'
  ].join('\n');
}

export function assembleUserDictionaryDraft(
  expression: string,
  settings: UserDictionaryCaptureSettings,
  provider: UserDictionaryProvider,
  model: string,
  value: unknown,
  now: () => string = () => new Date().toISOString(),
  uuid: () => string = () => globalThis.crypto.randomUUID(),
  options: UserDictionaryGenerationOptions = {}
): UserDictionaryEntryV1 {
  const content = validateGeneratedContent(value, options);
  // Both clients expose term as an editable field. That is the safety net for a poor
  // model judgement, so core deliberately does not invent a semantic similarity check.
  // A user-typed expression is the term by definition, so the model's proposal is
  // discarded rather than trusted. Enforced here as well as in the instruction, because
  // an instruction is a request and this is a promise.
  const term = options.termSuppliedByUser ? expression : (content.term ?? expression);
  const aliases = [...content.aliases];
  const normalizedExpression = normalizeUserDictionaryTerm(expression);
  if (normalizedExpression !== normalizeUserDictionaryTerm(term) &&
      !aliases.some((alias) => normalizeUserDictionaryTerm(alias) === normalizedExpression)) {
    aliases.push(expression);
  }
  const timestamp = now();
  // Built before the entry so the sense identifiers the box points at are the same objects
  // the entry stores. Generating them twice is how a valid-looking senseId ends up naming
  // nothing.
  const senseIds = content.senses.map(() => uuid());
  // Dropped rather than truncated, and dropped rather than thrown: an over-long sentence is
  // a host that clipped to a different number, and failing the whole capture over it would
  // report malformed model output for something the model never touched.
  //
  // Tidied and re-checked here as well as in the extractor, because a host can supply a
  // sentence it did not extract. Context that repeats only the expression is dropped because
  // it supplies no additional context.
  const proposedContext = tidyCapturedText(options.contextSentence ?? '');
  const contextSentence = proposedContext &&
    proposedContext.length <= USER_DICTIONARY_CONTEXT_MAX_CHARACTERS &&
    !contextRepeatsExpression(proposedContext, expression)
    ? proposedContext
    : undefined;
  const contextSenseIndex = content.contextSenseIndex ?? -1;
  const entry: UserDictionaryEntryV1 = {
    schemaVersion: 1,
    id: uuid(),
    term,
    normalizedTerm: normalizeUserDictionaryTerm(term),
    language: settings.entryLanguage === 'auto' ? content.language : settings.entryLanguage,
    entryType: content.entryType,
    collection: 'Other',
    domains: content.domains,
    tags: content.tags,
    ...(settings.includePronunciation && content.pronunciation
      ? { pronunciation: { display: content.pronunciation, audioAvailable: false } }
      : {}),
    senses: content.senses.map((sense, index) => ({
      id: senseIds[index]!,
      ...(sense.partOfSpeech ? { partOfSpeech: sense.partOfSpeech } : {}),
      ...(settings.includePronunciation && sense.pronunciation
        ? { pronunciation: sense.pronunciation }
        : {}),
      definition: sense.definition,
      ...(settings.includeUsageNotes && sense.usageNote
        ? { usageNote: sense.usageNote }
        : {}),
      synonyms: settings.includeSynonyms ? sense.synonyms : [],
      antonyms: settings.includeSynonyms ? sense.antonyms : [],
      relatedTerms: settings.includeSynonyms ? sense.relatedTerms : [],
      examples: sense.examples.slice(0, settings.numberOfExamples)
    })),
    aliases,
    capture: {
      mode: settings.captureMode === 'merriamWebsterAndLlm'
        ? 'merriamWebsterAndLlm'
        : 'llmOnly',
      provider,
      model,
      generatedAt: timestamp,
      userEdited: false
    },
    ...(contextSentence
      ? {
        capturedContext: {
          sentence: contextSentence,
          ...(contextSenseIndex >= 0 ? { senseId: senseIds[contextSenseIndex]! } : {})
        }
      }
      : {}),
    createdAt: timestamp,
    updatedAt: timestamp
  };
  try {
    return validateUserDictionaryEntry(entry);
  } catch {
    throw new UserDictionaryMalformedOutputError();
  }
}

function validateGeneratedContent(
  value: unknown,
  options: UserDictionaryGenerationOptions
): GeneratedDictionaryContent {
  const withContext = Boolean(options.contextSentence?.trim());
  if (!isRecord(value) || !hasExpectedGeneratedFields(value, withContext)) {
    throw new UserDictionaryMalformedOutputError();
  }
  if (typeof value.language !== 'string' || !isPlausibleLanguageCode(value.language) ||
      typeof value.entryType !== 'string' || !value.entryType.trim() ||
      typeof value.pronunciation !== 'string' ||
      !isStringArray(value.domains, 12) || !isStringArray(value.tags, 20) ||
      !isStringArray(value.aliases, 20) || !Array.isArray(value.senses) ||
      value.senses.length < 1 || value.senses.length > 12) {
    throw new UserDictionaryMalformedOutputError();
  }
  const senses = value.senses.map((sense) => validateGeneratedSense(sense));
  const term = validGeneratedTerm(value.term);
  return {
    ...(term ? { term } : {}),
    language: value.language,
    entryType: resolveEntryType(value.entryType, senses),
    domains: cleanStrings(value.domains),
    tags: cleanStrings(value.tags),
    pronunciation: value.pronunciation.trim(),
    senses,
    aliases: cleanStrings(value.aliases),
    ...(withContext
      ? { contextSenseIndex: resolveContextSenseIndex(value.contextSenseIndex, senses.length) }
      : {})
  };
}

/**
 * Anything that is not a whole number naming an existing sense becomes -1, which renders as
 * "the sentence did not settle it". A model returning 7 for a four-sense entry has not made
 * a smaller mistake than one returning "second"; both mean the same thing, that no sense was
 * actually identified, and neither is a reason to discard an otherwise sound entry.
 */
function contextRepeatsExpression(sentence: string, expression: string): boolean {
  return comparableContext(sentence) === comparableContext(expression);
}

function comparableContext(value: string): string {
  return value.replace(/\s+/gu, ' ').replace(/[.!?。！？,;:'"“”‘’]/gu, '').trim().toLowerCase();
}

function resolveContextSenseIndex(value: unknown, senseCount: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value)) return -1;
  return value >= 0 && value < senseCount ? value : -1;
}

// Labels that name the dictionary record instead of classifying the expression. A model
// asked for a "short label" returned "headword" for the noun "repository", which reads as a
// classification and is not one. Rejecting the label here rather than only in the
// instruction is what makes the stored field mean the same thing for every provider.
const RECORD_NAMING_ENTRY_TYPES = new Set([
  'headword', 'lemma', 'entry', 'dictionary entry', 'term', 'word', 'definition',
  'expression', 'lexical item', 'lexical unit', 'short label', 'label'
]);

function resolveEntryType(entryType: string, senses: readonly GeneratedSense[]): string {
  const proposed = entryType.trim();
  if (!RECORD_NAMING_ENTRY_TYPES.has(proposed.toLowerCase())) return proposed;
  const partOfSpeech = senses[0]?.partOfSpeech.trim();
  return partOfSpeech ? partOfSpeech : 'unclassified';
}

function validateGeneratedSense(value: unknown): GeneratedSense {
  // The sense pronunciation is asked for in the schema and in the instruction, and it is
  // accepted as absent here. Requiring it would mean that any provider omitting one
  // optional string fails the whole capture after three retries, and the field is set only
  // for a heteronym, so an omission is the ordinary case rather than a malformed answer.
  const sense = isRecord(value) && !Object.hasOwn(value, 'pronunciation')
    ? { ...value, pronunciation: '' }
    : value;
  if (!isRecord(sense) || !hasExactFields(sense, [
    'partOfSpeech', 'pronunciation', 'definition', 'usageNote', 'synonyms', 'antonyms',
    'relatedTerms', 'examples'
  ]) || typeof sense.partOfSpeech !== 'string' || typeof sense.pronunciation !== 'string' ||
      typeof sense.definition !== 'string' ||
      !sense.definition.trim() || typeof sense.usageNote !== 'string' ||
      !isStringArray(sense.synonyms, 20) || !isStringArray(sense.antonyms, 20) ||
      !isStringArray(sense.relatedTerms, 20) || !isStringArray(sense.examples, 3)) {
    throw new UserDictionaryMalformedOutputError();
  }
  return {
    partOfSpeech: sense.partOfSpeech.trim(),
    pronunciation: sense.pronunciation.trim(),
    definition: sense.definition.trim(),
    usageNote: sense.usageNote.trim(),
    synonyms: cleanStrings(sense.synonyms),
    antonyms: cleanStrings(sense.antonyms),
    relatedTerms: cleanStrings(sense.relatedTerms),
    examples: cleanStrings(sense.examples)
  };
}

function validGeneratedTerm(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const term = value.trim();
  if (!term || term.length > USER_DICTIONARY_EXPRESSION_MAX_CHARACTERS ||
      /[\r\n\0]/u.test(term) || term.split(/\s+/u).length > USER_DICTIONARY_EXPRESSION_MAX_WORDS) {
    return undefined;
  }
  return term;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function hasExpectedGeneratedFields(
  value: Record<string, unknown>,
  withContext: boolean
): boolean {
  const required = [
    'language', 'entryType', 'domains', 'tags', 'pronunciation', 'senses', 'aliases'
  ];
  // Allowed but not required even when context was supplied, so a provider that ignores the
  // extra field still produces a usable entry rather than three retries and a hard failure.
  const allowed = new Set(['term', ...required, ...(withContext ? ['contextSenseIndex'] : [])]);
  return required.every((field) => Object.hasOwn(value, field)) &&
    Object.keys(value).every((field) => allowed.has(field));
}

function hasExactFields(value: Record<string, unknown>, fields: readonly string[]): boolean {
  const expected = new Set(fields);
  return Object.keys(value).length === expected.size &&
    Object.keys(value).every((field) => expected.has(field));
}

function isStringArray(value: unknown, maximum: number): value is string[] {
  return Array.isArray(value) && value.length <= maximum &&
    value.every((item) => typeof item === 'string');
}

function cleanStrings(values: string[]): string[] {
  return values.map((value) => value.trim()).filter(Boolean);
}
