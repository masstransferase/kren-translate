import type { GrammarChoice, GrammarIssue, GrammarSource } from './contracts.js';

interface GrammarEdit {
  start: number;
  end: number;
  replacement: string;
}

export function applyGrammarChoices(
  result: GrammarSource,
  choices: readonly GrammarChoice[]
): string {
  const selected = new Map<string, number>();
  for (const choice of choices) {
    if (Number.isInteger(choice.suggestionIndex) && choice.suggestionIndex >= 0) {
      selected.set(choice.issueId, choice.suggestionIndex);
    }
  }

  const edits = result.issues.flatMap((issue) =>
    selectedEdit(result.sourceText, issue, selected.get(issue.id))
  );
  edits.sort((left, right) => right.start - left.start || right.end - left.end);

  for (let index = 1; index < edits.length; index += 1) {
    const previous = edits[index - 1];
    const current = edits[index];
    if (previous && current && current.end > previous.start) {
      throw new Error('Overlapping grammar corrections cannot be applied together.');
    }
  }

  return edits.reduce(
    (text, edit) => text.slice(0, edit.start) + edit.replacement + text.slice(edit.end),
    result.sourceText
  );
}

function selectedEdit(
  sourceText: string,
  issue: GrammarIssue,
  suggestionIndex: number | undefined
): GrammarEdit[] {
  if (suggestionIndex === undefined) return [];
  const suggestion = issue.suggestions[suggestionIndex];
  if (!suggestion) return [];
  if (sourceText.slice(issue.start, issue.end) !== issue.original) {
    throw new Error('A grammar issue no longer matches the checked text.');
  }

  const insertion = suggestion.kind === 'insertAfter';
  return [{
    start: insertion ? issue.end : issue.start,
    end: issue.end,
    replacement: suggestion.replacement
  }];
}
