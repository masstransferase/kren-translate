import { EDGE_SPEECH_LOCALES, edgeSpeechLocaleFromLatinWords, edgeSpeechLocaleFromScript } from './edgeSpeech.js';

export interface KrenLanguage {
  code: string;
  name: string;
}

export const AUTO_ENGLISH_KOREAN_TARGET = 'auto-en-ko';
export const AUTO_REWRITE_SOURCE_LANGUAGE = 'auto';

export const KREN_LANGUAGES: readonly KrenLanguage[] = [
  { code: 'ar', name: 'Arabic' },
  { code: 'bn', name: 'Bengali' },
  { code: 'bg', name: 'Bulgarian' },
  { code: 'zh-CN', name: 'Chinese (Simplified)' },
  { code: 'zh-TW', name: 'Chinese (Traditional)' },
  { code: 'hr', name: 'Croatian' },
  { code: 'cs', name: 'Czech' },
  { code: 'da', name: 'Danish' },
  { code: 'nl', name: 'Dutch' },
  { code: 'en', name: 'English' },
  { code: 'et', name: 'Estonian' },
  { code: 'fil', name: 'Filipino' },
  { code: 'fi', name: 'Finnish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'el', name: 'Greek' },
  { code: 'he', name: 'Hebrew' },
  { code: 'hi', name: 'Hindi' },
  { code: 'hu', name: 'Hungarian' },
  { code: 'id', name: 'Indonesian' },
  { code: 'it', name: 'Italian' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'lv', name: 'Latvian' },
  { code: 'lt', name: 'Lithuanian' },
  { code: 'ms', name: 'Malay' },
  { code: 'no', name: 'Norwegian' },
  { code: 'fa', name: 'Persian' },
  { code: 'pl', name: 'Polish' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ro', name: 'Romanian' },
  { code: 'ru', name: 'Russian' },
  { code: 'sr', name: 'Serbian' },
  { code: 'sk', name: 'Slovak' },
  { code: 'sl', name: 'Slovenian' },
  { code: 'es', name: 'Spanish' },
  { code: 'sw', name: 'Swahili' },
  { code: 'sv', name: 'Swedish' },
  { code: 'ta', name: 'Tamil' },
  { code: 'te', name: 'Telugu' },
  { code: 'th', name: 'Thai' },
  { code: 'tr', name: 'Turkish' },
  { code: 'uk', name: 'Ukrainian' },
  { code: 'ur', name: 'Urdu' },
  { code: 'vi', name: 'Vietnamese' }
] as const;

export function languageName(code: string): string {
  if (code === 'auto') return 'Auto-detect';
  if (code === AUTO_ENGLISH_KOREAN_TARGET) {
    return 'Auto: English to Korean or Korean to English';
  }
  if (code === 'bilingual') return 'English and Korean';
  return KREN_LANGUAGES.find((language) => language.code === code)?.name ?? code;
}

export function isEnglishLanguageCode(code: string): boolean {
  return /^en(?:-|$)/iu.test(code.trim());
}

export function isSupportedTargetLanguage(code: string): boolean {
  return KREN_LANGUAGES.some((language) => language.code === code);
}

export function containsKorean(text: string): boolean {
  return /[\u1100-\u11ff\u3130-\u318f\ua960-\ua97f\uac00-\ud7af\ud7b0-\ud7ff]/u.test(text);
}

export function resolveTranslationTarget(text: string, selectedTarget: string): string {
  if (selectedTarget !== AUTO_ENGLISH_KOREAN_TARGET) return selectedTarget;
  return containsKorean(text) ? 'en' : 'ko';
}

/**
 * Whether a passage is plausibly English, which is the question "should the offline English
 * checker run on this" and not the question "what language is this".
 *
 * Harper carries English rules and an English dictionary. Run on Korean it finds nothing,
 * and run on French or Spanish it finds hundreds of spelling errors that are not errors,
 * because every word is outside its dictionary. Neither is a useful answer, so Grammar Check
 * skips it when this returns false and leaves the language model to read the passage.
 *
 * Two signals, in order. A passage written mostly in a non-Latin script is not English, and
 * that covers Korean, Japanese, Chinese, Russian, Greek, Arabic, Hebrew, Thai, and Hindi
 * without a word list. A Latin-script passage is judged on function words, because English
 * cannot be written at any length without them while French and Spanish supply their own.
 *
 * The honest limits, since this decides whether a check runs at all. A short Latin-script
 * fragment with no function word in it, such as a heading or a term, is treated as English
 * and Harper runs, which is the safe direction: the old behaviour, on text where Harper's
 * answer is cheap to dismiss. And a language with English function words embedded in it will
 * pass. This is a gate on a local checker, not a language identifier.
 */
export function isProbablyEnglish(text: string): boolean {
  const letters = text.match(/\p{L}/gu) ?? [];
  if (letters.length === 0) return true;
  const latin = letters.filter((letter) => /\p{Script=Latin}/u.test(letter)).length;
  if (latin / letters.length < 0.5) return false;

  // Whole Latin words, not [a-z] runs. Splitting on an accent turns "arrivé" into
  // "arriv" and "é" into nothing, and those fragments can collide with the list below.
  const words = text.toLowerCase().match(/[\p{Script=Latin}'’]+/gu) ?? [];
  // Below this a passage has too few words for an absent function word to mean anything,
  // and refusing to check a three-word heading would be worse than checking it.
  if (words.length < ENGLISH_FUNCTION_WORD_MINIMUM_WORDS) return true;
  return words.some((word) => ENGLISH_FUNCTION_WORDS.has(word));
}

const ENGLISH_FUNCTION_WORD_MINIMUM_WORDS = 6;

// Closed-class words, which a language does not borrow and cannot avoid. Deliberately short:
// a longer list adds words other languages also use and weakens the signal. "a" and "i" are
// left out for exactly that reason; Spanish "a" alone was enough to call a Spanish sentence
// English, and English of any length carries another word on this list anyway.
const ENGLISH_FUNCTION_WORDS = new Set([
  'the', 'an', 'and', 'or', 'but', 'if', 'of', 'to', 'in', 'on', 'at', 'by', 'for',
  'with', 'from', 'that', 'this', 'these', 'those', 'it', 'its', 'is', 'are', 'was', 'were',
  'be', 'been', 'have', 'has', 'had', 'does', 'did', 'not', 'as', 'we', 'you', 'they',
  'he', 'she', 'my', 'our', 'their', 'his', 'her', 'will', 'would', 'could',
  'should', 'there', 'which', 'who', 'when', 'what'
]);

/** Locale-aware names used by current language controls. The legacy languageName remains unchanged. */
export function localeLanguageName(code: string): string {
  if (code === 'auto') return 'Auto-detect';
  if (code === AUTO_ENGLISH_KOREAN_TARGET) return 'Auto: English ↔ Korean';
  const exact = KREN_LANGUAGES.find((language) => language.code === code)?.name;
  if (exact) return exact;
  const locale = EDGE_SPEECH_LOCALES.find(
    (entry) => entry.id.toLowerCase() === code.trim().toLowerCase()
  )?.label;
  if (locale) return locale;
  const bare = code.split('-')[0];
  return KREN_LANGUAGES.find((language) => language.code === bare)?.name ?? code;
}

export function isSameLanguage(left: string, right: string): boolean {
  if (left === 'auto' || right === 'auto') return false;
  const base = (code: string): string => code.trim().toLowerCase().split('-')[0] ?? '';
  return base(left) !== '' && base(left) === base(right);
}

/** Shared detector: script first, then clear evidence from Latin-script words. */
export function detectedLanguage(text: string): string | undefined {
  return edgeSpeechLocaleFromScript(text) ?? edgeSpeechLocaleFromLatinWords(text);
}
