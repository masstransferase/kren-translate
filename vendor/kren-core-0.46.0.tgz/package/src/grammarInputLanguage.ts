import type { GrammarDialect, GrammarInputLanguage } from './contracts.js';
import { isProbablyEnglish } from './languages.js';

// Grammar Check's Input language: Auto-detect, the English check, and the sentences a reader
// sees when the offline English checker did not run or was refused.

export const GRAMMAR_INPUT_LANGUAGE_MISMATCH =
  'Grammar Check is set to check English, and this text does not look like English. ' +
  'Set the Grammar Check input language to Auto-detect to check it, which skips the ' +
  'offline English checker and uses Smart Grammar Check instead.';

export const GRAMMAR_HARPER_SKIPPED_NOTICE =
  'This text does not look like English. ' +
  'Turn on Smart Grammar Check in Settings to check it.';

/**
 * What Harper should do for this setting and text: a dialect to check with, undefined when
 * Harper should not run (Auto-detect and text that is not English), or a refusal when an
 * explicit dialect meets text that is not English. Auto-detect makes no claim about the
 * language, so only an explicit dialect can be contradicted.
 */
export function planGrammarHarper(
  language: GrammarInputLanguage,
  text: string
): { dialect: GrammarDialect | undefined } | { refusal: string } {
  if (language === 'auto') return { dialect: isProbablyEnglish(text) ? 'american' : undefined };
  if (!isProbablyEnglish(text)) return { refusal: GRAMMAR_INPUT_LANGUAGE_MISMATCH };
  return { dialect: language };
}

/** True when nothing was checked: no issues, the offline check was skipped, and no Smart Grammar Check model ran. */
export function grammarNothingChecked(
  result: { issues: readonly unknown[]; harperSkipped?: boolean; smartModelId?: string }
): boolean {
  return result.issues.length === 0 && result.harperSkipped === true && !result.smartModelId;
}
