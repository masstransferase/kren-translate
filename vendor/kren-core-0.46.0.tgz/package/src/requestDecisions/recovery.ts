import { isRetryableLanguageModelStatus, retryDelayMs } from '../retry.js';
import { isLanguageModelRoutingProvider, type LanguageModelRoutingProvider } from '../languageModelRouting.js';
import type { FailureCause, FindingCode, RequestPolicy, RequestRoute, ReaderAction } from './contracts.js';
import { classifyGeminiRateLimit, isProviderQuotaExhausted } from './quota.js';
import { canEscalateThinking, type ThinkingMode } from './thinking.js';
import { identifier } from './usage.js';

export function classifyRequestStatus(provider: LanguageModelRoutingProvider, status: number, envelope?: unknown): {
  cause: FailureCause; retryable: boolean
} {
  const error = (envelope as { error?: { code?: unknown; type?: unknown } } | undefined)?.error;
  const quota = isProviderQuotaExhausted(provider, status, envelope) || status === 429 &&
    (error?.code === 'insufficient_quota' || error?.type === 'insufficient_quota');
  const overloaded = provider === 'gemini' && status !== 404 &&
    (status === 503 || (envelope as { error?: { status?: unknown } } | undefined)?.error?.status === 'UNAVAILABLE');
  const cause: FailureCause = quota ? 'quotaExhausted' : overloaded ? 'overloaded'
    : status === 401 || status === 403 ? 'authenticationRejected' : status === 429 ? 'rateLimit'
      : status >= 500 ? 'serviceUnavailable' : 'requestRejected';
  return { cause, retryable: !quota && (overloaded || isRetryableLanguageModelStatus(status)) };
}

export function requestRetryDelay(provider: LanguageModelRoutingProvider, attempt: number, retryAfter?: string | null,
  envelope?: unknown, now: () => number = Date.now, random?: () => number): number {
  return (provider === 'gemini' ? classifyGeminiRateLimit(envelope).retryDelayMs : undefined) ??
    retryDelayMs(attempt, retryAfter ?? null, { parseHttpDate: true, now, random });
}

export function responseRefused(provider: LanguageModelRoutingProvider, envelope: unknown): boolean {
  const record = (value: unknown): Record<string, unknown> => value && typeof value === 'object' ? value as Record<string, unknown> : {};
  const value = record(envelope);
  if (provider === 'gemini') return ['SAFETY', 'OTHER', 'BLOCKLIST', 'PROHIBITED_CONTENT', 'IMAGE_SAFETY'].includes(String(record(value.promptFeedback).blockReason)) ||
    ['SAFETY', 'RECITATION', 'BLOCKLIST', 'PROHIBITED_CONTENT', 'SPII', 'IMAGE_SAFETY'].includes(String(record(Array.isArray(value.candidates) ? value.candidates[0] : undefined).finishReason));
  if (provider === 'anthropic') return value.stop_reason === 'refusal';
  if (provider === 'openai') return Array.isArray(value.output) && value.output.some(item => {
    const content = record(item).content;
    return Array.isArray(content) && content.some(block => record(block).type === 'refusal');
  });
  return Array.isArray(value.choices) && Boolean(record(record(value.choices[0]).message).refusal);
}

export const safeCodes = (codes: readonly FindingCode[]): FindingCode[] => [...new Set(codes.filter(code =>
  ['unreadableOutput', 'requiredField', 'wordCount', 'excerpt', 'contentRejected', 'refused'].includes(code)))];
export const safeRoute = (route: RequestRoute): RequestRoute => ({ provider: route.provider, model: identifier(route.model),
  geminiProfile: route.geminiProfile, mode: route.mode, effort: route.effort });

/** Transport settings and the older center retain their distinct nonfinite handling. */
export function boundedTransportAttempts(configured: number, opening = false, openingCap = 3): number {
  return Math.max(1, Math.min(opening ? openingCap : 5, Number.isFinite(configured) ? Math.floor(configured) : 1));
}
export function centerTransportAttempts(policy: RequestPolicy, kind: string, original: LanguageModelRoutingProvider,
  selected: LanguageModelRoutingProvider, configured: Readonly<Record<LanguageModelRoutingProvider, number>>): number {
  const provider = policy.switchedAttemptSettings === 'originalProvider' ? original : selected;
  return Math.min(kind === 'conversationOpening' ? policy.openingAttemptCap ?? 5 : 5,
    Math.max(1, Math.min(5, Math.floor(configured[provider] || 1))));
}
export function consumeRequestBudget(remaining: number): { allowed: boolean; remaining: number } {
  return remaining <= 0 ? { allowed: false, remaining } : { allowed: true, remaining: remaining - 1 };
}
export function routeBudgetAvailable(total: number, used: number, totalRequests: number, perRouteAttempts: number): boolean {
  return !(total >= totalRequests || used >= perRouteAttempts);
}
export function requestBoundary(canceled: boolean, expired: boolean, now: number, deadline: number): 'canceled' | 'deadline' | undefined {
  return canceled ? 'canceled' : expired || now >= deadline ? 'deadline' : undefined;
}
export function retryAttempt(retryable: boolean, index: number, attempts: number): boolean {
  return retryable && index !== attempts - 1;
}

export interface FailureSummary { providerError: boolean; status?: number; reason?: string; retryable?: boolean }
export function shouldFallback(failure: FailureSummary, selected: { provider: LanguageModelRoutingProvider; model: string },
  fallback: { enabled: boolean; model: string }, aborted: boolean, providerSwitch: boolean): boolean {
  return !aborted && selected.provider === 'gemini' && fallback.enabled && Boolean(fallback.model) &&
    fallback.model.replace(/^models\//u, '') !== selected.model.replace(/^models\//u, '') && failure.providerError &&
    (failure.status === 404 || failure.status === 429 || failure.status === 503 || failure.status === 504 || failure.reason === 'structuredOutput') &&
    failure.reason !== 'structuredOutput' && !(providerSwitch && (failure.reason === 'quotaExhausted' || failure.reason === 'overloaded'));
}
export function shouldRetryContent(cause: FailureCause, attempt: number, allowance: number, codes: readonly FindingCode[],
  on: readonly FindingCode[] = ['contentRejected']): boolean {
  return cause === 'contentRejected' && attempt < allowance && codes.some(code => on.includes(code));
}
export function recoveryAfterFailure(state: { mode: ThinkingMode; aborted: boolean; escalated: boolean; escalation: 'once' | 'never'; validationFailure: boolean;
  cause: FailureCause; contentRetries: number; allowance: number; codes: readonly FindingCode[]; on: readonly FindingCode[]; escalationEligible?: boolean }): 'escalation' | 'contentRetry' | 'terminal' {
  if (state.escalation === 'once' && !state.escalated && (state.escalationEligible ?? canEscalateThinking(state.mode, state.aborted, state.validationFailure))) return 'escalation';
  return shouldRetryContent(state.cause, state.contentRetries, state.allowance, state.codes, state.on) ? 'contentRetry' : 'terminal';
}
export function failureActions(cause: FailureCause, retryable = true, terminalRefusal = true): ReaderAction[] {
  return cause === 'authenticationRejected' ? ['setCredential'] : cause === 'quotaExhausted' ? ['checkQuota']
    : cause === 'requestRejected' ? ['configureProvider'] : cause === 'refused' && terminalRefusal ? [] : retryable ? ['retry'] : [];
}
export function compatibilityFailureCause(failure: FailureSummary & { budget: boolean; malformed: boolean; credentialAction: boolean }, provider: LanguageModelRoutingProvider): FailureCause {
  return failure.budget ? 'budget'
    : failure.reason === 'quotaExhausted' || failure.status === 429 && !failure.retryable ? 'quotaExhausted'
    : failure.reason === 'overloaded' ? 'overloaded'
    : failure.reason === 'structuredOutput' || failure.malformed ? 'unreadableOutput'
    : failure.reason === 'refused' ? 'refused'
    : failure.credentialAction && failure.status === undefined ? 'authenticationRejected'
    : failure.status !== undefined ? classifyRequestStatus(provider, failure.status).cause : 'noResponse';
}

/** Events are constructed field by field. Provider text and arbitrary caller fields cannot flow through. */
export type SafeDecisionEvent = { provider: LanguageModelRoutingProvider; model: string; status?: number; attempt: number } &
  ({ type: 'usage'; input: number; output: number; thinking: number } | { type: 'failure'; code: number });
export const FAILURE_EVENT_CODES = {
  noResponse: 0, authenticationRejected: 1, quotaExhausted: 2, rateLimit: 3, overloaded: 4,
  serviceUnavailable: 5, requestRejected: 6, unreadableOutput: 7, contentRejected: 8, refused: 9, budget: 10, deadline: 11
} as const satisfies Record<FailureCause, number>;
const numeric = (value: number): number => Number.isSafeInteger(value) && value >= 0 ? value : 0;
const eventProvider = (value: LanguageModelRoutingProvider): LanguageModelRoutingProvider => isLanguageModelRoutingProvider(value) ? value : 'gemini';
export function decisionUsageEvent(provider: LanguageModelRoutingProvider, model: string, attempt: number,
  counts: { input: number; output: number; thinking: number }): Extract<SafeDecisionEvent, { type: 'usage' }> {
  return { type: 'usage', provider: eventProvider(provider), model: identifier(model), attempt: numeric(attempt),
    input: numeric(counts.input), output: numeric(counts.output), thinking: numeric(counts.thinking) };
}
export function decisionFailureEvent(provider: LanguageModelRoutingProvider, model: string, attempt: number, status: number | undefined, code: FailureCause): Extract<SafeDecisionEvent, { type: 'failure' }> {
  return { type: 'failure', provider: eventProvider(provider), model: identifier(model), attempt: numeric(attempt), ...(status === undefined ? {} : { status: numeric(status) }),
    code: Object.hasOwn(FAILURE_EVENT_CODES, code) ? FAILURE_EVENT_CODES[code] : FAILURE_EVENT_CODES.noResponse };
}
