export interface GeminiModelOption {
  id: string;
  displayName: string;
  /** Set only when Google advertised bidiGenerateContent for this identifier. */
  liveOnly?: true;
}

export const DEFAULT_GEMINI_MODEL = 'gemini-3.6-flash';

/** Resolve the retired identifier at read time; never rewrite a stored setting. */
export function resolveRetiredGeminiModel(model: string): string {
  return model.trim().replace(/^(models\/)?gemini-3\.5-flash$/u, '$1gemini-3.6-flash');
}

export function normalizeModelSetting<T>(key: string, value: T): T {
  return (typeof value === 'string' && /model$/iu.test(key) ? resolveRetiredGeminiModel(value) : value) as T;
}

export const DEFAULT_PRO_MODELS: GeminiModelOption[] = [
  { id: 'gemini-3.1-pro-preview', displayName: 'Gemini 3.1 Pro Preview' },
  { id: 'gemini-3.6-flash', displayName: 'Gemini 3.6 Flash' }
];

export const GEMINI_PROFILES = [
  { id: 'standard', label: 'Free Tier' },
  { id: 'pro', label: 'Paid' }
] as const;

export type GeminiProfile = typeof GEMINI_PROFILES[number]['id'];

export function geminiProfileLabel(profile: GeminiProfile): string {
  return profile === 'pro' ? 'Paid' : 'Free Tier';
}
