/**
 * Every KREN control icon, defined once for every host.
 *
 * This is a table of SVG path data and nothing else, because the two hosts draw differently
 * and neither drawing method belongs in a host-independent package. The Office task pane
 * builds elements with `document.createElementNS`, since it never assigns `innerHTML`
 * anywhere. The VS Code panel builds a string, because a webview is served as HTML.
 *
 * What the hosts must share is the drawing itself, so a control means the same thing in
 * Word as it does in the editor. Two copies of a path table is the condition that lets one
 * host quietly acquire a different eraser.
 *
 * Every path is drawn on a 24 by 24 grid as an unfilled stroke, so a host sets `fill: none`,
 * `stroke: currentColor`, and its own stroke width. Following `currentColor` is what lets
 * one set of paths serve a light theme, a dark theme, and a danger colour with no second
 * set of assets.
 *
 * `FILLED_ICONS` below names the exceptions, which a host paints solid instead. Their paths
 * are closed shapes, so the same data serves either treatment and no icon needs two copies.
 */
export const ICON_PATHS = {
  speaker: ['M4 9h3.2L12 5v14l-4.8-4H4zM15.8 9.6a4 4 0 0 1 0 4.8M18.4 7.2a8 8 0 0 1 0 9.6'],
  // The same cone as speaker, with a cross where its waves were. Read aloud is a toggle,
  // and a toggle whose two states share one drawing tells the reader nothing.
  speakerOff: ['M4 9h3.2L12 5v14l-4.8-4H4z', 'M16 9.6l4.8 4.8M20.8 9.6l-4.8 4.8'],
  // A lamp over a base: Hint offers an idea rather than an answer.
  hint: ['M12 3.5a5.5 5.5 0 0 1 3.3 9.9c-.5.4-.8 1-.8 1.6h-5c0-.6-.3-1.2-.8-1.6A5.5 5.5 0 0 1 12 3.5z', 'M9.8 18h4.4M10.8 20.5h2.4'],
   // A clockwise open circle arrow: a ring broken on its right with the head at the top.
   // Distinct from reset, which uses an anticlockwise arrow.
  replay: ['M19.68 13.35A7.8 7.8 0 1 1 17.01 6.02', 'M16.08 2.96L17.01 6.02L13.84 5.63'],
  // A play triangle meeting a bar: move past this question to the next one.
  skip: ['M6 6l8.5 6L6 18z', 'M17.5 5.5v13'],
  // A paper plane, the one shape every chat interface uses for send.
  send: ['M20.5 3.5 3.5 10.3l7 2.7 2.7 7z', 'M20.5 3.5 10.5 13'],
  stop: ['M8 7.5h8a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5H8a.5.5 0 0 1-.5-.5V8a.5.5 0 0 1 .5-.5z'],
  edit: ['M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3zM14.5 6.5l3 3'],
  delete: ['M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 12.5h9L17.5 7M10 10.5v6M14 10.5v6'],
  regenerate: ['M4 9.5a8 8 0 0 1 13.5-3.2L20 8.5M20 14.5A8 8 0 0 1 6.5 17.7L4 15.5M20 4.5v4h-4M4 19.5v-4h4'],
  save: ['M5 4.5h11L19.5 8v11.5H5zM8.5 4.5v5h7v-5M8.5 19.5V14h7v5.5'],
  /*
   * A capital P, for the control that makes a selected target the primary one. A stem and a
   * bowl, drawn as strokes like every other icon here rather than set as text, so it takes
   * the same size, colour, and stroke width as the icons beside it.
   */
  primary: ['M9 5.5v13', 'M9 5.5h4.2a3.6 3.6 0 0 1 0 7.2H9'],
  /*
   * An S, drawn to sit beside the P above it rather than to be admired on its own.
   *
    * The control sends a Primary target back to Support. A letter mirrors the P and
    * identifies Support without a separate legend.
   *
   * Same 24-unit box, same 5.5 to 18.5 vertical extent and same stroke weight as the P,
   * so the pair line up when they sit in one row.
   */
  support: ['M13.4 7.4a3.2 3.2 0 0 0-4.9.3c-1 1.4-.2 3 1.4 3.5l1.9.6c1.9.6 2.7 2.3 1.6 3.8a3.2 3.2 0 0 1-5-.2'],
  // A magnifier, for the deliberate find. Circle and handle, the conventional glyph.
  search: ['M10.8 4.5a6.3 6.3 0 1 1 0 12.6 6.3 6.3 0 0 1 0-12.6', 'M15.4 15.4 20 20'],
  /*
   * Two four-pointed sparkles, the conventional mark for asking a model rather than
   * searching an index. Deliberately not a robot or a brain: the reader is asking a
   * question, not meeting a character.
   */
  ask: [
    'M9.5 4.2 11 8.2l4 1.5-4 1.5-1.5 4-1.5-4-4-1.5 4-1.5z',
    'M17 13.2l.9 2.4 2.4.9-2.4.9-.9 2.4-.9-2.4-2.4-.9 2.4-.9z'
  ],
  /*
    * A lower-case i inside a circle. Three parts, because the dot has to be a separate
    * stroke from the stem: the ring, the dot, and the stem with its foot.
   */
  information: [
    'M12 3.5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17',
    'M12 7.6v.1',
    'M12 11v6'
  ],
  // A cross inside a circle.
  cancel: ['M12 3.5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17', 'M8.6 8.6l6.8 6.8M15.4 8.6l-6.8 6.8'],
  clear: ['M8.5 19.5 4.6 15.6a2 2 0 0 1 0-2.8l8-8a2 2 0 0 1 2.8 0l4 4a2 2 0 0 1 0 2.8l-7 7zM9.5 19.5H20M9 9l6 6'],
  // Two stacked sheets, the conventional copy glyph: the front sheet is the duplicate.
  copy: ['M9.5 9.5h9.5v9.5H9.5z', 'M14.5 9.5V5H5v9.5h4.5'],
  // A capsule on a stand, the conventional microphone. Distinct from `speaker`, which
  // points sound outward: this one takes it in, and the two sit side by side in practice.
  microphone: ['M12 3.5a2.5 2.5 0 0 1 2.5 2.5v6a2.5 2.5 0 0 1-5 0V6A2.5 2.5 0 0 1 12 3.5z',
    'M6.5 10.5a5.5 5.5 0 0 0 11 0', 'M12 16v4', 'M9 20.5h6'],
  // A page with a turned corner and three ruled lines. Distinct from `copy`, which is two
  // offset rectangles: the reader read the copy glyph as a copy-and-paste control and not
  // as a document to reopen, which is the whole job of the report opener.
  document: ['M6.5 3.5h7L17.5 8v13h-11z', 'M13.5 3.5V8h4', 'M9.5 12h5', 'M9.5 15h5', 'M9.5 18h3'],
  // Two arrows swapping places: Replace exchanges the text in the document for this draft.
  replace: ['M4 8.5h14.5M14.5 4.5l4 4-4 4M20 15.5H5.5M9.5 11.5l-4 4 4 4'],
  // A single anticlockwise arrow, distinct from the two-arrow regenerate cycle.
  // The circle stops short of its own arrowhead: with the two ends touching, the reader saw
  // a closed ring rather than an arrow going round again.
  reset: ['M17.3 6.3A8 8 0 1 1 9.4 4.4', 'M7 6.6 9.4 4.4 11.4 7.1'],
  // A house for the home control.
  home: ['M3 11.5 12 4l9 7.5M5.5 10.5V20h13v-9.5M9.5 20v-6h5v6'],
  // Back to the result still held in the panel, distinct from `reset`, which repeats work.
  back: ['M20 12H4M10 6l-6 6 6 6'],
  menu: ['M4 6h16M4 12h16M4 18h16'],
  /*
    * A closed book with a letter on its cover, distinct from the magnifier for search.
    * Three parts: the cover, the spine's inner edge, and the A on the front.
   */
  dictionary: [
    'M6 4.5h11.5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H6.8A1.8 1.8 0 0 1 5 17.7V5.8a1.3 1.3 0 0 1 1-1.3',
    'M5 16.4a1.8 1.8 0 0 1 1.8-.9h11.7',
    'M9.6 12.6 12 7.4l2.4 5.2M10.4 11.2h3.2'
  ],
  /*
    * Two speech bubbles exchanging, distinct from the swapping arrows for replacing text.
    * Separate glyphs keep translation and replacement controls distinguishable.
   */
  translate: [
    'M3.5 5.2a1 1 0 0 1 1-1h7.4a1 1 0 0 1 1 1v5.1a1 1 0 0 1-1 1H7.2l-2.6 2.3v-2.3h-.1a1 1 0 0 1-1-1z',
    'M11.1 13.7a1 1 0 0 1 1-1h7.4a1 1 0 0 1 1 1v5.1a1 1 0 0 1-1 1h-.1v2.3l-2.6-2.3h-4.7a1 1 0 0 1-1-1z',
    'M6 7.6h4.4M8.2 6.2v1.4M9.3 9.6a4.4 4.4 0 0 1-2.2-2M14.2 17.9l1.9-3.8 1.9 3.8M15 16.5h2.2'
  ],
  // Settings. A six-tooth gear drawn as one outline plus a centre circle, at the same
  // 24 by 24 stroke weight as the rest, so it sits beside Clear without redrawing the eye.
  settings: [
    'M10.3 3.5h3.4l.35 2.3a6.6 6.6 0 0 1 1.72 1l2.14-.9 1.7 2.95-1.79 1.48a6.7 6.7 0 0 1 0 1.98l1.79 1.48-1.7 2.95-2.14-.9a6.6 6.6 0 0 1-1.72 1l-.35 2.3h-3.4l-.35-2.3a6.6 6.6 0 0 1-1.72-1l-2.14.9-1.7-2.95 1.79-1.48a6.7 6.7 0 0 1 0-1.98L4.71 8.85l1.7-2.95 2.14.9a6.6 6.6 0 0 1 1.72-1z',
    'M12 9.4a2.6 2.6 0 1 1 0 5.2 2.6 2.6 0 0 1 0-5.2'
  ]
} as const satisfies Record<string, readonly string[]>;

export type IconName = keyof typeof ICON_PATHS;

/*
 * The icons a host paints solid rather than stroking.
 *
 * Every other icon in this table is an outline, which is what makes a set of controls read
 * as one set. The mark for asking a model is solid because a hollow sparkle can read as
 * decoration beside the other controls.
 *
 * The name is listed here rather than the paths carrying their own fill, so the two hosts
 * cannot disagree about which icons are solid. A host applies its own rule for the class.
 */
const FILLED_ICONS: ReadonlySet<string> = new Set<IconName>(['ask']);

export function isFilledIcon(name: IconName): boolean {
  return FILLED_ICONS.has(name);
}

export const ICON_NAMES = Object.keys(ICON_PATHS) as IconName[];

export function isIconName(value: string): value is IconName {
  return Object.hasOwn(ICON_PATHS, value);
}

/**
 * The icon as an SVG string, for a host that builds markup rather than elements.
 *
 * There is nothing to escape here. The argument is narrowed to a key of the table above, so
 * the only text that reaches the output is path data this file authored. A host that has a
 * plain string must pass it through `isIconName` first, which is what makes that true.
 */
export function iconSvgMarkup(name: IconName): string {
  const filled = isFilledIcon(name) ? ' class="kren-icon-filled"' : '';
  const paths = ICON_PATHS[name].map((definition) => `<path d="${definition}"/>`).join('');
  return `<svg aria-hidden="true" viewBox="0 0 24 24"${filled}>${paths}</svg>`;
}

/*
 * The four glyphs the AI English Tutor panel draws differently from the table above:
 * `information`, `support`, `primary` and `reset`, as KREN VS Code 2.0.1 draws them in its
 * panel. They are a separate export so every other screen keeps `ICON_PATHS` unchanged.
 *
 * `primary` is the same capital P as `ICON_PATHS.primary` at a heavier stroke, so it is
 * listed by reference. `information` is a stroked body plus a filled dot, which is not path
 * data in the table's sense, so the dot is a separate entry. As with the table above, a host
 * draws these: `support` and `primary` inside a group at the heavy stroke width, `information`
 * with its body at 2.4 and the dot filled with the current colour, `reset` at the host's own width.
 */
export const PANEL_ICON_PATHS = {
  information: ['M9.6 10.4l3.6-.6-2.3 8.6c-.35 1.3.75 1.8 1.65 1l1.25-1.1'],
  support: ['M15.5 7.4A4 4 0 0 0 12 5.5h-.6A3.4 3.4 0 0 0 8 8.9c0 1.7 1.2 2.6 2.8 3l2.4.6c1.7.4 2.9 1.4 2.9 3.1a3.4 3.4 0 0 1-3.5 2.9h-.8a4 4 0 0 1-3.6-2'],
  primary: ICON_PATHS.primary,
  reset: ['M4.5 12a7.5 7.5 0 1 0 2.2-5.3L4.5 9', 'M4.5 4.5V9H9']
} as const satisfies Record<string, readonly string[]>;

export type PanelIconName = keyof typeof PANEL_ICON_PATHS;

/** The stroke width a panel glyph is drawn at, where it is not the host's own default. */
export const PANEL_ICON_STROKE_WIDTH = {
  information: '2.4',
  support: '3.4',
  primary: '3.4'
} as const;

/** The filled dot above the body of the `information` glyph. */
export const PANEL_ICON_INFORMATION_DOT = { cx: '14.2', cy: '5.2', r: '1.8' } as const;

export const PANEL_ICON_NAMES = Object.keys(PANEL_ICON_PATHS) as PanelIconName[];

export function isPanelIconName(value: string): value is PanelIconName {
  return Object.hasOwn(PANEL_ICON_PATHS, value);
}
