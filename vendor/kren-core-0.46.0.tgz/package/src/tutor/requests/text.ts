/**
 * Text helpers shared by tutor request builders and answer readers. Moved unchanged from KREN
 * VS Code's `src/tutor/state.ts`, `plainText.ts` and `generation.ts` (V312).
 */

import {
  REWRITE_DOMAINS,
  REWRITE_FORMALITIES,
  REWRITE_FUNCTIONS,
  REWRITE_MODALITIES
} from '../../rewriteAxes.js';
import type { TutorOutputSettings } from '../contract.js';
import type { TutorWritingSettings } from './types.js';

function axisLabels<T extends string>(options: readonly { id: T; label: string }[]): Record<T, string> {
  return Object.fromEntries(options.map(({ id, label }) => [id, label])) as Record<T, string>;
}

/** One label source for the writing constraints in lesson and diagnosis requests. */
export const TUTOR_WRITING_CONSTRAINT_LABELS = {
  domain: axisLabels(REWRITE_DOMAINS),
  function: axisLabels(REWRITE_FUNCTIONS),
  modality: axisLabels(REWRITE_MODALITIES),
  formality: axisLabels(REWRITE_FORMALITIES),
  learnerLevel: {
    A1: 'Beginner', A2: 'Elementary', B1: 'Intermediate',
    B2: 'Upper-intermediate', C1: 'Advanced', C2: 'Proficient'
  } satisfies Record<Exclude<TutorOutputSettings['learnerLevel'], 'auto'>, string>
};

/** Select only the five writing constraints, omitting each no-preference value. */
export function tutorWritingConstraints(settings: TutorWritingSettings) {
  const { axes, learnerLevel } = settings;
  const labels = TUTOR_WRITING_CONSTRAINT_LABELS;
  return {
    ...(axes.domain === 'general' ? {} : { domain: labels.domain[axes.domain] }),
    ...(axes.function === 'general' ? {} : { function: labels.function[axes.function] }),
    modality: labels.modality[axes.modality],
    ...(axes.formality === 'preserve' ? {} : { formality: labels.formality[axes.formality] }),
    ...(learnerLevel === 'auto' ? {} : { learnerLevel: labels.learnerLevel[learnerLevel] })
  };
}

/** Shared by lesson quality checks and the reader's highlighting. */
export const TUTOR_EXCERPT_SENTENCE_LIMIT = 0.9;
export function tutorExcerptShowsPattern(sentence: string, excerpt: string): boolean {
  return excerpt.length > 0 && excerpt.length < sentence.length * TUTOR_EXCERPT_SENTENCE_LIMIT;
}

/** Clean provider dialogue before it becomes shared display, speech, and quote-matching state. */
export function sanitizeTutorConversationText(text: string): string {
  return text
    .replace(/^[ \t]*(?:[*\-_=#~][ \t]*){3,}(?:\r\n|[\r\n]|$)/gmu, '')
    .replace(/(?<![\p{L}\p{N}_*])(\*\*|__|\*|_)([^\s*_](?:[^\r\n]*?[^\s*_])?)\1(?![\p{L}\p{N}_*])/gu, '$2')
    .trim();
}

/** 2026-10-13: Clean model prose and its matching excerpts together before validation/storage. */
export function tutorPlainText(text: string): string {
  return text
    .replace(/\*\*(?=\S)([\s\S]*?\S)\*\*/gu, '$1')
    .replace(/(?<!_)__(?!_)(?=\S)([\s\S]*?\S)__(?!_)/gu, '$1')
    .replace(/(?<![\p{L}\p{N}_*])([*_])(?![*_])(?=\S)([^*_]*?[^\s*_])\1(?![\p{L}\p{N}_*])/gu, '$2');
}

export function cleanTutorModelText(value: unknown, exercises = false): unknown {
  if (typeof value === 'string') return tutorPlainText(value);
  if (Array.isArray(value)) return value.map(item => cleanTutorModelText(item, exercises));
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(([key, item]) => {
    const cleaned = cleanTutorModelText(item, exercises);
    return [key, (exercises || 'targetIds' in value) && key === 'prompt' && typeof cleaned === 'string'
      ? cleaned.replace(/(?<!_)___(?:[ \t]+___)+(?!_)/gu, '___') : cleaned];
  }));
}

/** Preserve dialogue until its parser validates the shape, then accepts the cleaned text. */
export function cleanTutorConversationModelText(value: unknown): unknown {
  const cleaned = cleanTutorModelText(value);
  if (!isRecord(value) || !isRecord(cleaned)) return cleaned;
  for (const field of ['opening', 'reply', 'nextQuestion'] as const) {
    if (typeof value[field] !== 'string') continue;
    // Separator-only prose is structurally valid. Keep it nonempty until the field parser
    // accepts it, because the general emphasis cleaner would shorten asterisks first.
    cleaned[field] = sanitizeTutorConversationText(value[field]) || value[field];
  }
  if (Array.isArray(value.lines) && Array.isArray(cleaned.lines)) {
    cleaned.lines = value.lines.map((line, index) => isRecord(line) && typeof line.text === 'string'
      ? { ...line, text: sanitizeTutorConversationText(line.text) || line.text }
      : (cleaned.lines as unknown[])[index]);
  }
  return cleaned;
}

const TUTOR_FINISH_REASONS: readonly string[] = [
  'FINISH_REASON_UNSPECIFIED', 'STOP', 'MAX_TOKENS', 'SAFETY', 'RECITATION', 'LANGUAGE', 'OTHER',
  'BLOCKLIST', 'PROHIBITED_CONTENT', 'SPII', 'MALFORMED_FUNCTION_CALL', 'IMAGE_SAFETY',
  'stop', 'length', 'tool_calls', 'content_filter', 'function_call',
  'end_turn', 'max_tokens', 'stop_sequence', 'tool_use', 'pause_turn', 'refusal', 'model_context_window_exceeded'
];

/** A provider's own finish reason, limited to known enum members so no free text escapes. */
export function tutorStructuredResponseCause(value: unknown, depth = 0): string | undefined {
  if (depth > 4 || !isRecord(value)) return undefined;
  for (const key of [
    'finishReason', 'finish_reason', 'stop_reason'
  ]) {
    // Changed 2026-10-16: V257, R13 finding 1, diagnostic values must be known enum members.
    if (Object.hasOwn(value, key))
      return typeof value[key] === 'string' && TUTOR_FINISH_REASONS.includes(value[key]) ? value[key] : 'other';
  }
  for (const key of ['error', 'candidate', 'content']) {
    const detail = tutorStructuredResponseCause(value[key], depth + 1);
    if (detail) return detail;
  }
  for (const key of ['candidates', 'output', 'content']) {
    const items = value[key];
    if (!Array.isArray(items)) continue;
    for (const item of items) {
      const detail = tutorStructuredResponseCause(item, depth + 1);
      if (detail) return detail;
    }
  }
  return undefined;
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}
