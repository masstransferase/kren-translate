/**
 * Reading and checking tutor answers. Moved unchanged from KREN VS Code's
 * `src/tutor/generation.ts` (V312).
 *
 * Every error message here is fixed text plus, at most, a field name, a line number or a
 * provider finish reason drawn from a closed list. None quotes the learner or the model.
 */

import { tutorTargetSearchSelection } from '../diagnosis.js';
import type { TutorConversationOpening } from './conversationRequests.js';
import { tutorTargetMarks } from './targetMarks.js';
import { isRecord, sanitizeTutorConversationText, tutorStructuredResponseCause } from './text.js';
import type {
  TutorAskAnswer,
  TutorConversationDemoCast,
  TutorConversationDemoLine,
  TutorConversationDemoSpeaker,
  TutorConversationHandoff,
  TutorConversationTurn,
  TutorHint
} from './types.js';

export function tutorWrittenHint(value: unknown): TutorHint | undefined {
  return isRecord(value) && typeof value.explanation === 'string' && value.explanation.trim() &&
      typeof value.example === 'string' && value.example.trim()
    ? { explanation: value.explanation.trim(), example: value.example.trim() }
    : undefined;
}

export function tutorWrittenPrompt(value: unknown): string | undefined {
  return isRecord(value) && Object.keys(value).length === 1 &&
    typeof value.prompt === 'string' && value.prompt.trim()
    ? value.prompt.trim() : undefined;
}

export function tutorConversationHandoff(value: unknown): TutorConversationHandoff | undefined {
  if (!isRecord(value) || typeof value.role !== 'string' || !value.role.trim() ||
      value.role.trim().length > 120 || /[\r\n<>]/u.test(value.role) ||
      (value.gender !== 'female' && value.gender !== 'male')) return undefined;
  return { role: value.role.trim(), gender: value.gender };
}

export function tutorConversationOpening(
  value: unknown,
  openingRequired = true,
  targetIds: readonly string[] = []
): TutorConversationOpening {
  const cause = tutorStructuredResponseCause(value);
  if (cause) {
    throw new Error(`AI English Tutor received no readable conversation opening. Provider response: ${cause}`);
  }
  if (!isRecord(value) || !Object.hasOwn(value, 'scene') ||
      typeof value.scene !== 'string' || !value.scene.trim()) {
    throw new Error('AI English Tutor received no readable conversation opening. The scene field was missing, empty, or was not text.');
  }
  const expectedKeys = openingRequired ? 4 : 3;
  if (Object.keys(value).filter((key) => key !== 'targetMarks').length !== expectedKeys || (openingRequired &&
      (typeof value.opening !== 'string' || !value.opening.trim()))) {
    throw new Error('AI English Tutor received no readable conversation opening. The opening field was empty or was not text.');
  }
  const role = (text: unknown): text is string => typeof text === 'string' && Boolean(text.trim()) && text.trim().split(/\s+/u).length <= 6;
  if (!role(value.tutorRole) || !role(value.learnerRole) ||
      value.tutorRole.trim().toLocaleLowerCase('en-US').replace(/\s+/gu, ' ') === value.learnerRole.trim().toLocaleLowerCase('en-US').replace(/\s+/gu, ' ')) {
    throw new Error('AI English Tutor received invalid conversation roles. Both roles must be non-empty, different, and at most six words.');
  }
  const opening = typeof value.opening === 'string' ? sanitizeTutorConversationText(value.opening) : '';
  return {
    tutorRole: value.tutorRole.trim(), learnerRole: value.learnerRole.trim(),
    ...(Array.isArray(value.targetMarks) || targetIds.length > 0 ? { targetMarks: tutorTargetMarks(value.targetMarks, { opening }, targetIds) } : {}),
    scene: value.scene.trim(),
    ...(openingRequired ? { opening } : {})
  };
}

function tutorConversationDemoCharacter(
  value: unknown,
  field: TutorConversationDemoSpeaker
): TutorConversationDemoCast['male'] {
  if (!isRecord(value) || Object.keys(value).length !== 3 ||
      typeof value.name !== 'string' || !value.name.trim() ||
      typeof value.role !== 'string' || !value.role.trim() ||
      typeof value.description !== 'string' || !value.description.trim()) {
    throw new Error(`AI English Tutor received no readable demo cast. The ${field} character was invalid.`);
  }
  return {
    name: value.name.trim(), role: value.role.trim(), description: value.description.trim()
  };
}

export function tutorConversationDemoCast(value: unknown): TutorConversationDemoCast {
  const cause = tutorStructuredResponseCause(value);
  if (cause) throw new Error(`AI English Tutor received no readable demo cast. Provider response: ${cause}`);
  if (!isRecord(value) || Object.keys(value).length !== 3 ||
      typeof value.scene !== 'string' || !value.scene.trim()) {
    throw new Error('AI English Tutor received no readable demo cast. The scene was invalid.');
  }
  return {
    scene: value.scene.trim(),
    male: tutorConversationDemoCharacter(value.male, 'male'),
    female: tutorConversationDemoCharacter(value.female, 'female')
  };
}

export function tutorConversationDemoBatch(
  value: unknown,
  expectedExchanges: number
): TutorConversationDemoLine[] {
  const cause = tutorStructuredResponseCause(value);
  if (cause) throw new Error(`AI English Tutor received no readable demo batch. Provider response: ${cause}`);
  if (!isRecord(value) || Object.keys(value).length !== 1 || !Array.isArray(value.lines) ||
      value.lines.length !== expectedExchanges * 2) {
    throw new Error('AI English Tutor received no readable demo batch. The line count was invalid.');
  }
  const lines = value.lines;
  return lines.map((line, index) => {
    if (!isRecord(line) || Object.keys(line).length !== 2 ||
        (line.speaker !== 'male' && line.speaker !== 'female') ||
        typeof line.text !== 'string' || !line.text.trim()) {
      throw new Error(`AI English Tutor received no readable demo batch. Line ${index + 1} was invalid.`);
    }
    if (index > 0 && isRecord(lines[index - 1]) && lines[index - 1].speaker === line.speaker) {
      throw new Error(`AI English Tutor received no readable demo batch. Line ${index + 1} did not alternate speakers.`);
    }
    return { speaker: line.speaker, text: sanitizeTutorConversationText(line.text) };
  });
}

/** Compare punctuation, case, spacing, and Unicode variants without changing displayed text. */
function tutorConversationQuestionText(text: string): string {
  return text.normalize('NFKC').toLowerCase().replace(/['’]/gu, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

function tutorConversationNextQuestion(reply: string, nextQuestion: string | undefined, replyQuote: string): string | undefined {
  if (!nextQuestion) return undefined;
  // A teaching reply can quote the learner's corrected question without asking it back.
  const dialogue = replyQuote ? reply.replace(replyQuote, '') : reply;
  if (/[?？]/u.test(dialogue)) return undefined;
  // A provider may leave the question mark off its repeated last question.
  const lastSentence = dialogue.split(/[.!?。！？]+/u).filter(part => part.trim()).at(-1) ?? '';
  if (tutorConversationQuestionText(lastSentence) === tutorConversationQuestionText(nextQuestion)) return undefined;
  return nextQuestion;
}

export function tutorConversationTurn(value: unknown, learnerNotShown = false, targetIds: readonly string[] = []): Omit<
  TutorConversationTurn,
  'question' | 'learnerAnswer'
> & { spokenPunctuated?: string } {
  const cause = tutorStructuredResponseCause(value);
  if (cause) {
    throw new Error(`AI English Tutor received no readable conversation turn. Provider response: ${cause}`);
  }
  if (!isRecord(value)) {
    throw new Error('AI English Tutor received no readable conversation turn. The response was not a JSON object.');
  }
  for (const field of [
    'replyQuote', 'correction', 'targetId', 'explanation', 'rephrase', 'rephraseWhy'
  ] as const) {
    if (typeof value[field] !== 'string' ||
        (!learnerNotShown && field !== 'targetId' && field !== 'replyQuote' && !value[field].trim())) {
      throw new Error(`AI English Tutor received no readable conversation turn. The ${field} field was empty or was not text.`);
    }
  }
  const move = ['clarification', 'recast', 'reaction', 'silence'].includes(value.move as string)
    ? value.move as TutorConversationTurn['move']
    // 2026-10-14: A missing or unknown move hint must not discard an explicit provider reply.
    : typeof value.reply === 'string' && value.reply.trim()
      ? 'reaction' : undefined;
  if (move && (typeof value.reply !== 'string' || !value.reply.trim())) {
    throw new Error('AI English Tutor received no readable conversation turn. The reply field was empty or was not text.');
  }
  if (Object.hasOwn(value, 'nextQuestion') &&
      (typeof value.nextQuestion !== 'string' || !value.nextQuestion.trim())) {
    throw new Error('AI English Tutor received no readable conversation turn. The nextQuestion field was empty or was not text.');
  }
  const target = tutorTargetSearchSelection({
    targets: [{ targetId: value.targetId, role: 'primary' }]
  })[0];
  const reply = move ? sanitizeTutorConversationText(value.reply as string) : '';
  const nextQuestion = tutorConversationNextQuestion(reply,
    typeof value.nextQuestion === 'string' ? sanitizeTutorConversationText(value.nextQuestion) : undefined, value.replyQuote as string);
  const handoff = tutorConversationHandoff(value.handoff);
  const alternatives = Array.isArray(value.alternatives) ? value.alternatives.filter(
    (entry): entry is { text: string; why: string } => isRecord(entry) &&
      typeof entry.text === 'string' && Boolean(entry.text.trim()) &&
      typeof entry.why === 'string' && Boolean(entry.why.trim())
  ).slice(0, 2).map(({ text, why }) => ({ text: text.trim(), why: why.trim() })) : [];
  return {
    ...(move ? { move, reply } : {}),
    ...(handoff ? { handoff } : {}),
    ...(Array.isArray(value.targetMarks) || targetIds.length > 0 ? { targetMarks: tutorTargetMarks(value.targetMarks, { reply, nextQuestion: nextQuestion ?? '' }, targetIds) } : {}),
    replyQuote: value.replyQuote as string,
    correction: (value.correction as string).trim(),
    ...(typeof value.spokenPunctuated === 'string' ? { spokenPunctuated: value.spokenPunctuated } : {}),
    ...(target ? { targetId: target.nodeId } : {}),
    explanation: (value.explanation as string).trim(),
    rephrase: (value.rephrase as string).trim(),
    rephraseWhy: (value.rephraseWhy as string).trim(),
    ...(alternatives.length >= 1 ? { alternatives } : {}),
    ...(nextQuestion ? { nextQuestion } : {})
  };
}

export function tutorConversationCorrections(
  value: unknown,
  expectedCount: number
): Array<Pick<
  TutorConversationTurn,
  'correction' | 'targetId' | 'explanation' | 'rephrase' | 'rephraseWhy'
> & { spokenPunctuated?: string }> {
  const cause = tutorStructuredResponseCause(value);
  if (cause) {
    throw new Error(`AI English Tutor received no readable conversation corrections. Provider response: ${cause}`);
  }
  if (!isRecord(value) || !Array.isArray(value.corrections) ||
      value.corrections.length !== expectedCount) {
    throw new Error('AI English Tutor received no readable conversation corrections. The correction count did not match the answered turns.');
  }
  return value.corrections.map((entry) => {
    if (!isRecord(entry) || typeof entry.correction !== 'string' || !entry.correction.trim() ||
        typeof entry.targetId !== 'string' || typeof entry.explanation !== 'string' ||
        !entry.explanation.trim() || typeof entry.rephrase !== 'string' ||
        !entry.rephrase.trim() || typeof entry.rephraseWhy !== 'string' ||
        !entry.rephraseWhy.trim()) {
      throw new Error('AI English Tutor received no readable conversation corrections. A correction, explanation, or rephrasing field was empty or was not text.');
    }
    const target = tutorTargetSearchSelection({
      targets: [{ targetId: entry.targetId, role: 'primary' }]
    })[0];
    return {
      correction: entry.correction.trim(),
      ...(typeof entry.spokenPunctuated === 'string' ? { spokenPunctuated: entry.spokenPunctuated } : {}),
      ...(target ? { targetId: target.nodeId } : {}),
      explanation: entry.explanation.trim(),
      rephrase: entry.rephrase.trim(),
      rephraseWhy: entry.rephraseWhy.trim()
    };
  });
}

export function tutorConversationCoaching(value: unknown, learnerAnswer: string): TutorConversationTurn & { spokenPunctuated?: string } {
  const correction = tutorConversationCorrections({ corrections: [value] }, 1)[0]!;
  return { ...correction, question: '', learnerAnswer, move: 'reaction', reply: learnerAnswer, replyQuote: '' };
}

/**
 * The two Ask requests deliberately share one small response contract. The direct answer
 * is the only required field. Explanation and examples are optional because a provider can
 * omit a requested field; a valid shorter answer remains useful and renders by itself.
 * A refusal often arrives as a JSON object with a reason instead, so preserve that reason
 * in the error the drawer shows rather than replacing it with a generic shape failure.
 */
export function tutorProseAnswer(value: unknown): TutorAskAnswer {
  const cause = tutorStructuredResponseCause(value);
  if (cause) {
    throw new Error(`AI English Tutor received no readable answer. Provider response: ${cause}`);
  }
  if (!isRecord(value)) {
    throw new Error('AI English Tutor received no readable answer. The response was not a JSON object.');
  }
  if (!Object.hasOwn(value, 'directAnswer')) {
    throw new Error('AI English Tutor received no readable answer. The response omitted the directAnswer field.');
  }
  if (typeof value.directAnswer !== 'string' || !value.directAnswer.trim()) {
    throw new Error('AI English Tutor received no readable answer. The directAnswer field was empty or was not text.');
  }
  if (Object.hasOwn(value, 'explanation') &&
      (typeof value.explanation !== 'string' || !value.explanation.trim())) {
    throw new Error('AI English Tutor received no readable answer. The explanation field was empty or was not text.');
  }
  if (Object.hasOwn(value, 'examples') &&
      (!Array.isArray(value.examples) || value.examples.some((example) =>
        typeof example !== 'string' || !example.trim()
      ))) {
    throw new Error('AI English Tutor received no readable answer. The examples field was not a list of non-empty text examples.');
  }
  const explanation = typeof value.explanation === 'string'
    ? value.explanation.trim()
    : undefined;
  const examples = Array.isArray(value.examples)
    ? value.examples.map((example) => (example as string).trim())
    : undefined;
  return {
    directAnswer: value.directAnswer.trim(),
    ...(explanation === undefined ? {} : { explanation }),
    ...(examples === undefined ? {} : { examples })
  };
}
