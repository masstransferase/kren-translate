/**
 * The vocabulary of tutor requests and answers, shared by every host (F7 run 4, V312).
 *
 * Moved from KREN VS Code's `src/tutor/generation.ts`, `state.ts`, `lessonConversation.ts`
 * and `takeHome.ts` without changing a field. A host keeps its own settings, transport,
 * credentials, logging and storage; these types describe only what travels in a request and
 * what is read back from an answer.
 */

import type { ThinkingMode } from '../../requestDecisions/thinking.js';
import type { RewriteDomain, RewriteFormality, RewriteFunction, RewriteModality } from '../../rewriteAxes.js';
import type { TrainingExercise, TutorOutputSettings } from '../contract.js';
import type { TutorSituationRegister } from '../situations.js';

export type TutorGenerationKind =
  | 'targetSearch'
  | 'liveSessionCredential'
  | 'conversationOpening'
  | 'conversationDemoCast'
  | 'conversationDemoBatch'
  | 'conversationCorrections'
  | 'conversationDiagnosis'
  | 'passageDiagnosis'
  | 'conversationTakeHome'
  | 'tailoredPrompt'
  | 'practiceHint'
  | 'conversationHint'
  | 'lesson'
  | 'example'
  | 'exercises'
  | 'review'
  | 'reviewBatch'
  | 'conversationStop'
  | 'exampleQuestion'
  | 'practiceQuestion'
  | 'translate'
  | 'conversationTurn';

export interface TutorStructuredGenerationRequest {
  /** Host-only routing signals; none enter the provider payload. */
  thinkingMode?: ThinkingMode;
  retry?: boolean;
  learnerInput?: string;
  transcriptTurns?: number;
  kind: TutorGenerationKind;
  instruction: string;
  input: string;
  schema: Record<string, unknown>;
  schemaName: string;
}

export interface TutorInstructionSource {
  privacy: string;
}

export type TutorConversationReplyLength = 'brief' | 'short' | 'medium' | 'long';
export type TutorConversationCoaching = 'inline' | 'afterwards' | 'teaching';
export type TutorLiveVoiceGender = 'female' | 'male';

export interface TutorAskAnswer {
  directAnswer: string;
  explanation?: string;
  examples?: string[];
}

export interface TutorHint {
  explanation: string;
  example: string;
}

export interface TutorTargetMark {
  field: 'opening' | 'reply' | 'nextQuestion';
  targetId: string;
  quote: string;
  /** Zero-based exact occurrence, resolved locally using JavaScript string indexes. */
  occurrence: number;
}

export interface TutorTargetRange { start: number; end: number }

export interface TutorLessonConversationContext {
  subject: string;
  targets: Array<{ targetId: string; role: 'primary' | 'support'; label: string; description: string }>;
  examples: Array<{ sentence: string; targetIds: string[]; annotations: Array<{ targetId: string; excerpt: string }> }>;
  missedPractice: Array<{ exerciseId: string; prompt: string; targetIds: string[]; learnerText: string }>;
}

export interface TutorConversationTurn {
  /** Display-only punctuation from the structured spoken-turn check. */
  spokenPunctuated?: string;
  handoff?: { role: string; gender: 'female' | 'male' };
  /** Only the cleaned English text is retained when speech contains a misheard segment. */
  partiallyHeard?: true;
  targetMarks?: TutorTargetMark[];
  questionTargetMarks?: TutorTargetMark[];
  /** Retained transcript text whose learner balloon and check are withheld. */
  learnerNotShown?: true;
  /** Session-only owner used to attach late Live coaching after the reader has moved on. */
  generation?: number;
  /** Skipped entries are display history only, never diagnostic evidence. */
  skipped?: boolean;
  /** The Live reply completed, but its separate structured correction request failed. */
  coachingFailed?: true;
  /** The Live turn is waiting for the one whole-conversation check at Stop. */
  coachingPending?: true;
  /** Direct Live microphone input always uses speech-recognition correction tolerance. */
  spoken?: boolean;
  question: string;
  learnerAnswer: string;
  /** Optional in session state for legacy responses and skipped entries. Required in new requests. */
  move?: 'clarification' | 'recast' | 'reaction' | 'silence';
  reply?: string;
  /** Exact model-named span of reply that restates the correction, or empty when none does. */
  replyQuote?: string;
  correction: string;
  targetId?: string;
  explanation: string;
  /** A natural answer fitted to the KREN message in question, whether or not correction was needed. */
  rephrase?: string;
  /** Why the rephrase fits, or a plain statement that the reader's answer was already natural. */
  rephraseWhy?: string;
  /** Other spoken ways to express the same meaning in Speak and rephrase. */
  alternatives?: Array<{ text: string; why: string }>;
  /** The reader chose the rephrasing, which replaces correction feedback without a way back. */
  rephraseShown?: true;
  nextQuestion?: string;
}

export type TutorConversationDemoSpeaker = 'male' | 'female';

export interface TutorConversationDemoCharacter {
  name: string;
  role: string;
  description: string;
}

export interface TutorConversationDemoLine {
  speaker: TutorConversationDemoSpeaker;
  text: string;
}

export interface TutorConversationDemoCast {
  scene: string;
  male: TutorConversationDemoCharacter;
  female: TutorConversationDemoCharacter;
}

/** The five writing constraints a lesson or diagnosis request may carry. */
export type TutorWritingSettings = {
  axes: { domain: RewriteDomain; function: RewriteFunction; modality: RewriteModality; formality: RewriteFormality };
  learnerLevel: TutorOutputSettings['learnerLevel'];
};

/** KREN's optional practice metadata leaves the core exercise contract unchanged. */
export type TutorPracticeExercise = TrainingExercise & { taskLine?: string };

export interface TutorReviewRequestBody {
  learnerAnswer: string;
  exercise: TrainingExercise;
  activeTargets: string[];
}

export interface TutorExampleQuestionRequestBody {
  sentence: string;
  question: string;
}

export interface TutorPracticeQuestionRequestBody {
  exercisePrompt: string;
  learnerAnswer: string;
  question: string;
}

// 2026-10-11: Carry mode choices independently of optional setting text on every request.
export interface TutorConversationControls {
  coach?: boolean;
  tutorRole?: string;
  learnerRole?: string;
  rolesSwapped?: boolean;
  learnerStarts?: boolean;
  replyLength?: TutorConversationReplyLength;
  coaching?: TutorConversationCoaching;
}

export interface TutorConversationTurnRequestBody extends TutorConversationControls {
  lessonContext?: TutorLessonConversationContext;
  register: TutorSituationRegister;
  recipeTargets: {
    primaryTarget?: string;
    supportingTargets: string[];
  };
  transcript: TutorConversationTurn[];
  question: string;
  learnerAnswer: string;
  /** True when KREN should correct the reader inside its spoken reply, not only in writing. */
  teaching?: boolean;
  /** The situation's setting text, when the conversation's source is a situation. */
  setting?: string;
  /** True when KREN plays the side described as "you" in setting. */
  rolesSwapped?: boolean;
  /** True when learnerAnswer came from speech recognition rather than a keyboard. */
  spoken?: boolean;
  /** Gender of the voice that will speak KREN's character, when the roster supplies it. */
  voiceGender?: TutorLiveVoiceGender;
  /** Sentence limit for KREN's reply. Defaults to Short for legacy callers. */
  replyLength?: TutorConversationReplyLength;
}

export interface TutorConversationCorrectionsRequestBody extends TutorConversationControls {
  lessonContext?: TutorLessonConversationContext;
  register: TutorSituationRegister;
  recipeTargets: TutorConversationTurnRequestBody['recipeTargets'];
  turns: Array<Pick<TutorConversationTurn, 'question' | 'learnerAnswer' | 'spoken'> & {
    previousTurn?: Pick<TutorConversationTurn, 'question' | 'learnerAnswer' | 'reply'>;
  }>;
  setting?: string;
  rolesSwapped?: boolean;
}

export interface TutorConversationHintRequestBody extends TutorConversationControls {
  lessonContext?: TutorLessonConversationContext;
  question: string;
  setting: string;
  register: TutorSituationRegister;
  recentTurns: Array<Pick<TutorConversationTurn, 'question' | 'learnerAnswer'>>;
  /** There is no KREN question because the learner chose to open the conversation. */
  opening?: boolean;
  rolesSwapped?: boolean;
}

export interface TutorConversationHandoff { role: string; gender: 'female' | 'male' }

/** What the learner and KREN said before a Stop, for a Live session reopened by Back to chat. */
export interface TutorConversationLiveHistoryLine {
  speaker: 'KREN' | 'learner';
  text: string;
}

export interface TutorTakeHome {
  naturally: Array<{ turnIndex: number; quote: string; alternatives: string[]; why: string }>;
  learningTargets?: Array<{ targetId: string; why: string }>;
  pattern?: { name: string; examples: [string, string] };
  doneWell: Array<{ turnIndex: number; quote: string; note: string }>;
  tryNext: string;
}

export interface TutorTakeHomeInput extends TutorConversationControls {
  source: 'lesson' | 'situation' | 'anything' | 'speakAndRephrase';
  demo: boolean;
  register: string;
  turns: Array<{ turnIndex: number; question?: string; learnerAnswer: string; reply?: string; spoken?: boolean;
    correction?: string; rephrase?: string; rephraseWhy?: string }>;
  demoLines: Array<{ speaker: string; text: string }>;
  lessonContext?: TutorLessonConversationContext;
}
