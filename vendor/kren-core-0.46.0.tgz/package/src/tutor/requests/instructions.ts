/** Instruction pieces shared by several tutor requests, moved unchanged from KREN VS Code's `src/tutor/generation.ts` (V312). */

import { tutorWritingConstraints } from './text.js';
import type { TutorInstructionSource, TutorWritingSettings } from './types.js';

export const TUTOR_PRIVACY_INSTRUCTION =
  'Do not ask for or infer document text, workspace content, prior lessons, learner history, or User Dictionary content.';

export const TUTOR_PLAIN_TEXT_INSTRUCTION = 'Return all text fields as plain text without Markdown, including emphasis markers. ';

export function createTutorInstructionSource(
  privacy: string = TUTOR_PRIVACY_INSTRUCTION
): TutorInstructionSource {
  return { privacy };
}

export const DEFAULT_TUTOR_INSTRUCTION_SOURCE = createTutorInstructionSource();

export function tutorOutputInstruction(source: TutorInstructionSource): string {
  return TUTOR_PLAIN_TEXT_INSTRUCTION + source.privacy;
}

export function tutorWritingConstraintInstruction(settings: TutorWritingSettings): string {
  return 'The writingConstraints JSON object names the supplied writing constraints: ' +
    '"domain" is the subject area, "function" is the communicative purpose, "modality" is ' +
    'written or spoken delivery, "formality" is the requested register, and "learnerLevel" ' +
    'is the reader\'s chosen proficiency. Values are reader-facing labels. Respect these ' +
    'constraints when judging or generating English, and pitch suggestions to learnerLevel ' +
    'when supplied. An omitted field expresses no preference: judge only what the material ' +
    'itself settles and do not assume a value. Lesson presentation settings are not writing ' +
    'constraints.\n' + JSON.stringify({ writingConstraints: tutorWritingConstraints(settings) });
}
