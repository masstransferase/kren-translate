/**
 * Tutor request builders, answer readers and validators, added in core 0.42.0 (F7 run 4, V312).
 *
 * These build the request a host sends and read the answer it gets back. They take learner
 * text only as arguments and return it only inside the request. They never log, store, read
 * settings or make network calls: the host keeps its transport, credentials, logging,
 * storage and settings, and passes in what it has already read.
 */

export type * from './types.js';
export {
  TUTOR_WRITING_CONSTRAINT_LABELS,
  TUTOR_EXCERPT_SENTENCE_LIMIT,
  tutorWritingConstraints,
  tutorExcerptShowsPattern,
  sanitizeTutorConversationText,
  tutorPlainText,
  cleanTutorModelText,
  cleanTutorConversationModelText,
  tutorStructuredResponseCause
} from './text.js';
export {
  TUTOR_TARGET_SEARCH_SCHEMA,
  TUTOR_DIAGNOSTIC_REPORT_SCHEMA,
  TUTOR_LESSON_SCHEMA,
  TUTOR_EXAMPLE_SCHEMA,
  TUTOR_EXERCISE_SCHEMA,
  TUTOR_REVIEW_SCHEMA,
  TUTOR_PROSE_ANSWER_SCHEMA,
  TUTOR_CONVERSATION_HANDOFF_SCHEMA,
  TUTOR_CONVERSATION_TURN_SCHEMA,
  TUTOR_CONVERSATION_CORRECTIONS_SCHEMA,
  TUTOR_CONVERSATION_OPENING_SCHEMA,
  TUTOR_CONVERSATION_SCENE_SCHEMA,
  TUTOR_CONVERSATION_DEMO_CAST_SCHEMA,
  TUTOR_CONVERSATION_DEMO_BATCH_SCHEMA
} from './schemas.js';
export { TUTOR_LESSON_TARGET_INSTRUCTION, tutorTargetRanges, tutorTargetMarks } from './targetMarks.js';
export { TUTOR_PRIVACY_INSTRUCTION, TUTOR_PLAIN_TEXT_INSTRUCTION, createTutorInstructionSource } from './instructions.js';
export {
  TUTOR_WEAKNESS_ANALYSIS_INSTRUCTION,
  TUTOR_TEXT_ANALYSIS_INSTRUCTION,
  tutorTargetSearchRequest,
  tutorConversationDiagnosisRequest,
  tutorPracticeHintRequest,
  tutorPassageDiagnosisRequest,
  tutorTailoredPromptRequest,
  serializeTutorRecipe,
  tutorLessonExcerptFindings,
  tutorLessonGenerationRequest,
  validateTutorExamplePracticeSet,
  tutorExerciseGenerationRequest,
  tutorReviewGenerationRequest,
  tutorReviewBatchGenerationRequest,
  tutorExampleQuestionRequest,
  tutorPracticeQuestionRequest,
  buildTutorReviewInstruction
} from './lessonRequests.js';
export type { TutorExamplePracticeRequest, TutorExamplePracticeSet } from './lessonRequests.js';
export {
  tutorConversationRoleInstruction,
  TUTOR_CONVERSATION_SCENE_SLANT_WEIGHTS,
  TUTOR_CONVERSATION_SCENE_SLANTS,
  tutorConversationSceneSlant,
  TUTOR_DEMO_BATCH_EXCHANGES,
  TUTOR_DEMO_MAX_EXCHANGES,
  tutorConversationHintRequest,
  TUTOR_TARGET_MARK_INSTRUCTION,
  TUTOR_HANDOFF_REQUEST_PATTERNS,
  tutorConversationHandoffInstruction,
  TUTOR_SPOKEN_PUNCTUATION_INSTRUCTION,
  tutorConversationTurnRequest,
  tutorConversationLiveReplyQuote,
  tutorConversationCorrectionsRequest,
  tutorConversationCoachingRequest,
  tutorConversationTeachingInstruction,
  TUTOR_CONVERSATION_MEANING_INSTRUCTION,
  TUTOR_CONVERSATION_REPHRASE_INSTRUCTION,
  TUTOR_CONVERSATION_COACH_INSTRUCTION,
  tutorConversationCoachOpening,
  tutorConversationReplyLengthInstruction,
  TUTOR_LIVE_TEACHING_INSTRUCTION,
  TUTOR_CONVERSATION_ENGLISH_ONLY_INSTRUCTION,
  TUTOR_CONVERSATION_LIVE_ENGLISH_ONLY_INSTRUCTION,
  tutorConversationLiveTeachingInstruction,
  TUTOR_SITUATION_ROLES,
  TUTOR_SITUATION_ROLES_SWAPPED,
  tutorConversationLiveSystemInstruction,
  tutorConversationLiveResumeInstruction,
  tutorConversationHandoffGreetingTurn,
  TUTOR_CONVERSATION_LIVE_SKIP_NOTE,
  tutorConversationOpeningRequest,
  tutorConversationDemoCastRequest,
  tutorConversationDemoBatchRequest
} from './conversationRequests.js';
export type {
  TutorConversationSceneSlant,
  TutorConversationOpeningRequestBody,
  TutorConversationOpening,
  TutorConversationDemoCastRequestBody,
  TutorConversationDemoBatchRequestBody
} from './conversationRequests.js';
export {
  tutorWrittenHint,
  tutorWrittenPrompt,
  tutorConversationHandoff,
  tutorConversationOpening,
  tutorConversationDemoCast,
  tutorConversationDemoBatch,
  tutorConversationTurn,
  tutorConversationCorrections,
  tutorConversationCoaching,
  tutorProseAnswer
} from './readers.js';
export { tutorConversationTakeHomeRequest, tutorConversationStopRequest, tutorConversationTakeHome } from './takeHome.js';
export { tutorFastEffort, tutorFallbackRoute } from './fallback.js';
export type { TutorFallbackInput } from './fallback.js';
