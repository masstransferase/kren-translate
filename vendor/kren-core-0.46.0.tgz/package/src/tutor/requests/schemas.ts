/** Response schemas for tutor requests, moved unchanged from KREN VS Code's `src/tutor/generation.ts` (V312). */

export const stringSchema = { type: 'string' } as const;
const stringArraySchema = { type: 'array', items: stringSchema } as const;
export const TUTOR_TARGET_SEARCH_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    targets: {
      type: 'array',
      maxItems: 4,
      items: {
        type: 'object',
        properties: { targetId: stringSchema, role: stringSchema },
        required: ['targetId', 'role']
      }
    }
  },
  required: ['targets'],
  additionalProperties: false
};
export const TUTOR_DIAGNOSTIC_REPORT_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    ...(TUTOR_TARGET_SEARCH_SCHEMA.properties as Record<string, unknown>),
    summary: stringSchema,
    findings: {
      type: 'array', minItems: 0, maxItems: 5,
      items: {
        type: 'object',
        properties: {
          level: { type: 'integer', minimum: 1, maximum: 4 },
          observation: stringSchema, evidence: stringSchema, correction: stringSchema, targetId: stringSchema,
          turnCount: { type: 'integer', minimum: 1 }
        },
        required: ['level', 'observation', 'evidence'],
        additionalProperties: false
      }
    },
    focus: stringSchema
  },
  required: ['targets', 'summary', 'findings', 'focus'],
  additionalProperties: false
};

const claimStatusSchema = {
  type: 'string',
  enum: ['rule', 'strongTendency', 'stylePreference']
} as const;
const targetSchema = {
  type: 'object',
  properties: {
    nodeId: stringSchema,
    label: stringSchema,
    kind: { type: 'string', enum: ['hub', 'cluster', 'skill', 'microTarget'] },
    role: { type: 'string', enum: ['primary', 'support'] },
    description: stringSchema,
    /*
     * Explore, blueprint 2.1. Optional and deliberately outside `required`: an exact
     * selection must not carry one, and core rejects a lesson that claims a choice it was
     * never offered.
     */
    chosenUnder: stringSchema
  },
  required: ['nodeId', 'label', 'kind', 'role', 'description'],
  additionalProperties: false
} as const;
const annotationSchema = {
  type: 'object',
  properties: {
    targetId: stringSchema,
    excerpt: stringSchema,
    explanation: stringSchema
  },
  required: ['targetId', 'excerpt', 'explanation'],
  additionalProperties: false
} as const;
const trainingExampleSchema = {
  type: 'object',
  properties: {
    id: stringSchema,
    sentence: stringSchema,
    targetIds: stringArraySchema,
    annotations: { type: 'array', items: annotationSchema }
  },
  required: ['id', 'sentence', 'targetIds', 'annotations'],
  additionalProperties: false
} as const;
const exerciseSchema = {
  type: 'object',
  properties: {
    id: stringSchema,
    channel: {
      type: 'string',
      enum: ['written', 'spokenScripted', 'spokenTyped', 'spokenVoice']
    },
    prompt: stringSchema,
    targetIds: stringArraySchema
  },
  required: ['id', 'channel', 'prompt', 'targetIds'],
  additionalProperties: false
} as const;

export const TUTOR_LESSON_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    schemaVersion: { type: 'number', const: 1 },
    mapVersion: stringSchema,
    lessonTitle: stringSchema,
    level: { type: 'string', enum: ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'] },
    primaryTarget: targetSchema,
    supportingTargets: { type: 'array', items: targetSchema },
    conceptExplanation: stringSchema,
    patternStatement: stringSchema,
    interactionExplanation: stringSchema,
    rules: {
      type: 'array',
      items: {
        type: 'object',
        properties: { statement: stringSchema, status: claimStatusSchema },
        required: ['statement', 'status'],
        additionalProperties: false
      }
    },
    examples: {
      type: 'array',
      items: trainingExampleSchema
    },
    commonErrors: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: stringSchema,
          incorrect: stringSchema,
          corrected: stringSchema,
          explanation: stringSchema,
          status: claimStatusSchema
        },
        required: ['id', 'incorrect', 'corrected', 'explanation', 'status'],
        additionalProperties: false
      }
    },
    practice: { type: 'array', items: exerciseSchema },
    answerKey: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: stringSchema,
          exerciseId: stringSchema,
          answer: stringSchema,
          explanation: stringSchema
        },
        required: ['id', 'exerciseId', 'answer', 'explanation'],
        additionalProperties: false
      }
    },
    generationNotes: stringArraySchema
  },
  required: [
    'schemaVersion', 'mapVersion', 'lessonTitle', 'level', 'primaryTarget',
    'supportingTargets', 'conceptExplanation', 'patternStatement', 'interactionExplanation', 'rules',
    'examples', 'commonErrors', 'practice', 'answerKey', 'generationNotes'
  ],
  additionalProperties: false
};

export const TUTOR_EXAMPLE_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: { example: trainingExampleSchema },
  required: ['example'],
  additionalProperties: false
};

export const TUTOR_EXERCISE_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    schemaVersion: { type: 'number', const: 1 },
    mapVersion: stringSchema,
    channel: {
      type: 'string',
      enum: ['written', 'spokenScripted', 'spokenTyped', 'spokenVoice']
    },
    exercises: { type: 'array', items: {
      ...exerciseSchema,
      properties: { ...exerciseSchema.properties, exampleIndex: { type: 'integer', minimum: 0 }, expectedAnswer: stringSchema, taskLine: stringSchema },
      required: [...exerciseSchema.required, 'exampleIndex', 'expectedAnswer']
    } }
  },
  required: ['schemaVersion', 'mapVersion', 'channel', 'exercises'],
  additionalProperties: false
};

const reviewSpanSchema = {
  type: 'object',
  properties: { excerpt: stringSchema, reason: stringSchema },
  required: ['excerpt', 'reason'],
  additionalProperties: false
} as const;

export const TUTOR_REVIEW_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    schemaVersion: { type: 'number', const: 1 },
    exerciseId: stringSchema,
    learnerText: stringSchema,
    correctedText: stringSchema,
    focusPhrase: stringSchema,
    correct: { type: 'array', items: reviewSpanSchema },
    incorrect: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          excerpt: stringSchema,
          reason: stringSchema,
          corrected: stringSchema,
          status: claimStatusSchema
        },
        required: ['excerpt', 'reason', 'corrected', 'status'],
        additionalProperties: false
      }
    }
  },
  required: ['schemaVersion', 'exerciseId', 'learnerText', 'correct', 'incorrect'],
  additionalProperties: false
};

export const TUTOR_PROSE_ANSWER_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    directAnswer: stringSchema,
    explanation: stringSchema,
    examples: stringArraySchema
  },
  required: ['directAnswer'],
  additionalProperties: false
};

export const TUTOR_CONVERSATION_HANDOFF_SCHEMA = {
  type: 'object', properties: { role: { type: 'string' }, gender: { type: 'string', enum: ['female', 'male'] } },
  required: ['role', 'gender'], additionalProperties: false
};

const TUTOR_TARGET_MARKS_SCHEMA = {
  type: 'array', items: { type: 'object', properties: {
    field: { type: 'string', enum: ['opening', 'reply', 'nextQuestion'] },
    targetId: stringSchema, quote: stringSchema, occurrence: { type: 'integer', minimum: 0 }
  }, required: ['field', 'targetId', 'quote', 'occurrence'], additionalProperties: false }
};

export const TUTOR_CONVERSATION_TURN_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    move: { type: 'string', enum: ['clarification', 'recast', 'reaction', 'silence'] },
    reply: stringSchema,
    targetMarks: TUTOR_TARGET_MARKS_SCHEMA,
    replyQuote: stringSchema,
    correction: stringSchema,
    spokenPunctuated: stringSchema,
    targetId: stringSchema,
    explanation: stringSchema,
    rephrase: stringSchema,
    rephraseWhy: stringSchema,
    nextQuestion: stringSchema,
    handoff: TUTOR_CONVERSATION_HANDOFF_SCHEMA
  },
  // 2026-10-16: spokenPunctuated is optional (nullable on the wire for strict providers); a missing form falls back to the local display, never fails the turn.
  required: [
    'move', 'reply', 'replyQuote', 'correction', 'targetId', 'explanation',
    'rephrase', 'rephraseWhy'
  ],
  additionalProperties: false
};

export const TUTOR_CONVERSATION_CORRECTIONS_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    corrections: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          correction: stringSchema,
          spokenPunctuated: stringSchema,
          targetId: stringSchema,
          explanation: stringSchema,
          rephrase: stringSchema,
          rephraseWhy: stringSchema
        },
        required: ['correction', 'targetId', 'explanation', 'rephrase', 'rephraseWhy'],
        additionalProperties: false
      }
    }
  },
  required: ['corrections'],
  additionalProperties: false
};

export const TUTOR_CONVERSATION_OPENING_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: { scene: stringSchema, opening: stringSchema, tutorRole: stringSchema, learnerRole: stringSchema, targetMarks: TUTOR_TARGET_MARKS_SCHEMA },
  required: ['scene', 'opening', 'tutorRole', 'learnerRole'],
  additionalProperties: false
};

export const TUTOR_CONVERSATION_SCENE_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: { scene: stringSchema, tutorRole: stringSchema, learnerRole: stringSchema },
  required: ['scene', 'tutorRole', 'learnerRole'],
  additionalProperties: false
};

const TUTOR_DEMO_CHARACTER_SCHEMA = {
  type: 'object',
  properties: { name: stringSchema, role: stringSchema, description: stringSchema },
  required: ['name', 'role', 'description'],
  additionalProperties: false
};

export const TUTOR_CONVERSATION_DEMO_CAST_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    scene: stringSchema,
    male: TUTOR_DEMO_CHARACTER_SCHEMA,
    female: TUTOR_DEMO_CHARACTER_SCHEMA
  },
  required: ['scene', 'male', 'female'],
  additionalProperties: false
};

export const TUTOR_CONVERSATION_DEMO_BATCH_SCHEMA: Record<string, unknown> = {
  type: 'object',
  properties: {
    lines: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          speaker: { type: 'string', enum: ['male', 'female'] },
          text: stringSchema
        },
        required: ['speaker', 'text'],
        additionalProperties: false
      }
    }
  },
  required: ['lines'],
  additionalProperties: false
};
