/**
 * The tutor fallback rule (V298, V300; port-list B9).
 *
 * A tutor request that fails on Thorough may fall back once, and only to the Fast model with
 * the Fast thinking setting. A Fast request never falls back, because it already runs on the
 * cheapest route and a second model would only add a request. Whether a failure permits a
 * fallback at all is `shouldFallback` in `requestDecisions/recovery.ts`; this module only
 * decides where a permitted tutor fallback goes.
 */

import type { LanguageModelRoutingEffort, LanguageModelRoutingProvider } from '../../languageModelRouting.js';
import { modeEffort, tutorFastModel, type ThinkingMode } from '../../requestDecisions/thinking.js';

/** Auto preserves the lowest supported Fast level; an explicit choice uses normal model normalization. */
export function tutorFastEffort(provider: LanguageModelRoutingProvider, model: string,
  configured: LanguageModelRoutingEffort = 'auto'): LanguageModelRoutingEffort {
  return modeEffort(provider, model, configured === 'auto' ? 'fast' : 'thorough', configured);
}

export interface TutorFallbackInput {
  /** The thinking mode of the request that failed. */
  mode: ThinkingMode;
  provider: LanguageModelRoutingProvider;
  /** The configured Thorough model of the route. */
  model: string;
  /** The configured Fast model, already read from the host's settings. */
  fastModel: string | undefined;
  /** The configured Fast thinking setting, already read from the host's settings. */
  fastThinkingOrEffort?: LanguageModelRoutingEffort;
}

/** The route a permitted tutor fallback uses, or undefined when the failed request was Fast. */
export function tutorFallbackRoute(input: TutorFallbackInput): { model: string; thinkingOrEffort: LanguageModelRoutingEffort } | undefined {
  if (input.mode !== 'thorough') return undefined;
  const model = tutorFastModel(input.provider, input.fastModel, input.model).trim();
  return { model, thinkingOrEffort: tutorFastEffort(input.provider, model, input.fastThinkingOrEffort ?? 'auto') };
}
