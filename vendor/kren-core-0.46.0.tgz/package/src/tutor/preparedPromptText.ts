/**
 * The fixed sentence appended to a lesson or practice instruction when the reader has reviewed a
 * prepared prompt. The sentence is the same in every host, so it lives here and nowhere else.
 */
export const PREPARED_PROMPT_SENTENCE =
  "The reader reviewed and may have edited the prepared prompt below. The prepared prompt states what to teach about; the current recipe states which targets to teach it through. Generate lesson examples and practice to meet the prompt's objective subject to the selected targets and settings. A changed selection changes the constraints, never the objective. Keep the structured-output and privacy requirements above.";

/** The instruction with the sentence and the reader's prepared prompt appended; unchanged without a prompt. */
export function instructionWithPreparedPrompt(instruction: string, preparedPrompt: string | undefined): string {
  if (preparedPrompt === undefined) return instruction;
  return `${instruction}\n\n${PREPARED_PROMPT_SENTENCE}\n\n${preparedPrompt}`;
}
