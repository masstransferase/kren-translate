import { EDGE_SPEECH_LOCALES } from '../edgeSpeech.js';
import { normalizedTutorLiveVoice, TUTOR_LIVE_VOICES } from '../speechRules/chirpVoices.js';

/**
 * Exact copies of the conversation voice plan KREN 2.0.1 keeps inside the VS Code extension
 * (speech/voiceSelection.ts, plus the two Edge helpers from windowsEdgeReadAloud.ts), so the Office
 * tutor can speak each character with its own voice. A test compares each body with the VS Code
 * source; change both together.
 */

// VS Code reads these five values from TUTOR_DEFAULTS.configuration. A test checks each against defaults.ts.
export const TUTOR_DEFAULT_LIVE_MALE_VOICE = 'Enceladus';
export const TUTOR_DEFAULT_LIVE_FEMALE_VOICE = 'Callirrhoe';
export const TUTOR_DEFAULT_READ_ALOUD_PROVIDER = 'googleChirp';
export const TUTOR_DEFAULT_READ_ALOUD_EDGE_VOICE = 'en-US-ChristopherNeural';
export const TUTOR_DEFAULT_READ_ALOUD_VOICE = 'Microsoft David Desktop';

export type SpeechVoiceGender = 'female' | 'male';

/** Reads the catalog's own `(Female)` or `(Male)` label instead of guessing from a name. */
export function edgeSpeechVoiceGender(voiceId: string): SpeechVoiceGender | undefined {
  const voice = EDGE_SPEECH_LOCALES.flatMap((locale) => locale.voices)
    .find((candidate) => candidate.id === voiceId);
  if (/\(Female\)$/u.test(voice?.label ?? '')) return 'female';
  if (/\(Male\)$/u.test(voice?.label ?? '')) return 'male';
  return undefined;
}

// Ava, not Ana: en-US-AnaNeural is Microsoft's child voice, although the catalog labels it only
// "(Female)", and it read a learner's answers in a four-year-old's voice (2026-09-19).
export function otherGenderEdgeVoice(
  gender: SpeechVoiceGender | undefined,
  defaults: { female: string; male: string }
): string {
  return gender === 'male' ? defaults.female : defaults.male;
}

type Gender = 'female' | 'male';
const livePresets = {
  female: TUTOR_LIVE_VOICES.filter((voice) => voice[2] === 'female').map(([name]) => name),
  male: TUTOR_LIVE_VOICES.filter((voice) => voice[2] === 'male').map(([name]) => name)
};

/** All newcomer choices live here. Windows has only one voice for each gender. */
export const TUTOR_CONVERSATION_VOICE_PRESETS = {
  edgeOnline: {
    female: ['en-US-AvaNeural', 'en-US-JennyNeural', 'en-US-AriaNeural', 'en-US-EmmaNeural'],
    male: ['en-US-ChristopherNeural', 'en-US-AndrewNeural', 'en-US-GuyNeural', 'en-US-BrianNeural']
  },
  googleChirp: livePresets,
  liveGemini: livePresets,
  windowsLocal: { female: ['Microsoft Zira Desktop'], male: ['Microsoft David Desktop'] }
} as const;

export interface TutorCharacterVoices { edgeVoice: string; liveVoice: string; windowsVoice: string }
export interface TutorConversationVoicePlan {
  tutorGender: Gender;
  learnerGender: Gender;
  initial: TutorCharacterVoices;
  current: TutorCharacterVoices;
  learner: TutorCharacterVoices;
  handoffs: Array<{ turn: number; voices: TutorCharacterVoices }>;
  /** The Live voice the session started with (V17); a newcomer never takes it, even when it is not the gender's default. */
  firstLiveVoice?: string;
}
const conversationVoices = new WeakMap<object, TutorConversationVoicePlan>();

/** Only the conversation data needed to plan voices crosses the speech boundary. */
export interface TutorVoiceContext {
  tutorSpeechConversation?: unknown;
  actions: { settings(): TutorVoiceSettings };
  tutorState: { conversation: { replies: string; liveVoice: string; transcript: readonly unknown[] } };
}

function conversationVoiceIdentity(identity: unknown): object | undefined {
  return identity !== null && (typeof identity === 'object' || typeof identity === 'function') ? identity : undefined;
}

function defaultVoices(settings: TutorVoiceSettings, gender: Gender): TutorCharacterVoices {
  return {
    liveVoice: normalizedTutorLiveVoice(gender === 'male'
      ? settings.tutorLiveMaleVoice ?? TUTOR_DEFAULT_LIVE_MALE_VOICE
      : settings.tutorLiveFemaleVoice ?? TUTOR_DEFAULT_LIVE_FEMALE_VOICE),
    edgeVoice: gender === 'male' ? settings.tutorEdgeReadAloudMaleVoice ?? 'en-US-ChristopherNeural'
      : settings.tutorEdgeReadAloudFemaleVoice ?? 'en-US-AvaNeural',
    windowsVoice: TUTOR_CONVERSATION_VOICE_PRESETS.windowsLocal[gender][0]
  };
}

/** The session identity is replaced at Start, so no preferences or archived text are mutated. */
export function tutorConversationVoicePlan(view: TutorVoiceContext, initialize = false): TutorConversationVoicePlan {
  const identity = conversationVoiceIdentity(view.tutorSpeechConversation);
  const saved = identity ? conversationVoices.get(identity) : undefined;
  if (saved && !initialize) return saved;
  const settings = view.actions.settings();
  const conversation = view.tutorState.conversation;
  const provider = settings.tutorReadAloudProvider ?? TUTOR_DEFAULT_READ_ALOUD_PROVIDER;
  const selectedEdgeVoice = settings.tutorEdgeReadAloudVoice ?? TUTOR_DEFAULT_READ_ALOUD_EDGE_VOICE;
  const tutorGender: Gender = conversation.replies === 'liveGemini' || provider === 'googleChirp'
    ? TUTOR_LIVE_VOICES.find(([name]) => name === normalizedTutorLiveVoice(conversation.liveVoice))?.[2] ?? 'female'
    : provider === 'windowsLocal'
      ? (/Zira/iu.test(settings.tutorReadAloudVoice ?? '') ? 'female' : 'male')
      : edgeSpeechVoiceGender(selectedEdgeVoice) ?? 'female';
  const learnerGender = tutorGender === 'female' ? 'male' : 'female';
  const initial = defaultVoices(settings, tutorGender);
  const learner = defaultVoices(settings, learnerGender);
  // A failed Live session still uses the Speech Source's original voice until a handoff.
  if (conversation.replies === 'liveGemini') {
    initial.edgeVoice = selectedEdgeVoice;
    initial.windowsVoice = settings.tutorReadAloudVoice ?? TUTOR_DEFAULT_READ_ALOUD_VOICE;
  }
  // Existing or demo conversations have no Start plan. Preserve their selected voices,
  // including the legacy Replay defaults, instead of freezing a plan during a read.
  if (!initialize) {
    initial.edgeVoice = selectedEdgeVoice;
    initial.liveVoice = tutorConversationSpeechVoice({ ...settings, tutorReadAloudProvider: 'googleChirp' }, conversation.liveVoice)!;
    initial.windowsVoice = settings.tutorReadAloudVoice ?? TUTOR_DEFAULT_READ_ALOUD_VOICE;
    learner.edgeVoice = tutorLearnerEdgeVoice({ ...settings, tutorReadAloudProvider: 'edgeOnline' }, conversation) ?? learner.edgeVoice;
    learner.liveVoice = tutorLearnerLiveVoice(settings, conversation.liveVoice);
  }
  const plan: TutorConversationVoicePlan = { tutorGender, learnerGender, initial, current: initial,
    learner, handoffs: [], firstLiveVoice: knownLiveVoice(conversation.liveVoice) };
  if (identity && initialize) conversationVoices.set(identity, plan);
  return plan;
}

/** The name when it is a Live voice in the table, otherwise undefined (an empty or unknown value names no voice in use). */
function knownLiveVoice(name: string | undefined): string | undefined {
  return TUTOR_LIVE_VOICES.some(([voice]) => voice === name) ? name : undefined;
}

/**
 * V17: a newcomer never sounds like the voice in use, the session's first voice or the learner's, so a
 * same-gender newcomer is a different voice even when the session started on a voice that is not the gender's default.
 */
export function handoffTutorConversationVoices(view: TutorVoiceContext, gender: Gender): TutorCharacterVoices {
  const plan = tutorConversationVoicePlan(view);
  const used = [knownLiveVoice(view.tutorState.conversation.liveVoice), plan.firstLiveVoice]
    .filter((voice): voice is string => voice !== undefined)
    .map((liveVoice): TutorCharacterVoices => ({ ...plan.initial, liveVoice }));
  const voices = tutorHandoffVoices(view.actions.settings(), gender, [plan.current, plan.learner, plan.initial, ...used]);
  plan.current = voices;
  plan.tutorGender = gender;
  plan.handoffs.push({ turn: view.tutorState.conversation.transcript.length - 1, voices });
  const identity = conversationVoiceIdentity(view.tutorSpeechConversation);
  if (identity) conversationVoices.set(identity, plan);
  return voices;
}

export function tutorCharacterVoicesAt(view: TutorVoiceContext, turn: number): TutorCharacterVoices {
  const plan = tutorConversationVoicePlan(view);
  return [...plan.handoffs].reverse().find((handoff) => handoff.turn <= turn)?.voices ?? plan.initial;
}

export function tutorVoiceForSource(settings: TutorVoiceSettings, voices: TutorCharacterVoices): string {
  return settings.tutorReadAloudProvider === 'windowsLocal' ? voices.windowsVoice
    : settings.tutorReadAloudProvider === 'googleChirp' ? voices.liveVoice : voices.edgeVoice;
}

export function tutorWindowsVoice(speakerVoice: string | undefined): string | undefined {
  return Object.values(TUTOR_CONVERSATION_VOICE_PRESETS.windowsLocal).some((voices) => voices[0] === speakerVoice)
    ? speakerVoice : undefined;
}

// Explicit Chirp presets keep their identity; other speech sources supply gender only.
export function tutorChirpVoices(speakerVoice: string | undefined, choices: {
  female: string; male: string; edgeFemale: string; edgeMale: string;
}): { voice: string; edgeVoice: string } {
  const preset = TUTOR_LIVE_VOICES.find(([name]) => name === speakerVoice);
  const gender = preset?.[2] ?? (tutorWindowsVoice(speakerVoice)
    ? (speakerVoice === TUTOR_CONVERSATION_VOICE_PRESETS.windowsLocal.male[0] ? 'male' : 'female')
    : edgeSpeechVoiceGender(speakerVoice ?? '') ?? 'female');
  return { voice: preset?.[0] ?? normalizedTutorLiveVoice(gender === 'male' ? choices.male : choices.female),
    edgeVoice: gender === 'male' ? choices.edgeMale : choices.edgeFemale };
}

/** VS Code names these fields on KrenPanelSettings; core names the types it reads from them. */
export type TutorVoiceSettings = Partial<{
  tutorReadAloudProvider: 'windowsLocal' | 'edgeOnline' | 'googleChirp';
  tutorReadAloudVoice: string;
  tutorEdgeReadAloudVoice: string;
  tutorEdgeReadAloudFemaleVoice: string;
  tutorEdgeReadAloudMaleVoice: string;
  tutorLiveFemaleVoice: string;
  tutorLiveMaleVoice: string;
}>;

export function tutorHandoffVoices(_settings: TutorVoiceSettings, gender: Gender, excluded: readonly TutorCharacterVoices[] = []): TutorCharacterVoices {
  const choose = (presets: readonly string[], key: keyof TutorCharacterVoices) =>
    presets.find((voice) => !excluded.some((other) => other[key] === voice)) ?? presets[0]!;
  return {
    liveVoice: choose(TUTOR_CONVERSATION_VOICE_PRESETS.liveGemini[gender], 'liveVoice'),
    edgeVoice: choose(TUTOR_CONVERSATION_VOICE_PRESETS.edgeOnline[gender], 'edgeVoice'),
    windowsVoice: TUTOR_CONVERSATION_VOICE_PRESETS.windowsLocal[gender][0]
  };
}

// 2026-10-14: Replay passes speaker identity to the center's choices without changing settings.
export function tutorLearnerEdgeVoice(settings: TutorVoiceSettings, conversation: { replies: string; liveVoice: string }): string | undefined {
  if (settings.tutorReadAloudProvider !== 'edgeOnline') return undefined;
  const edgeDefaults = {
    female: settings.tutorEdgeReadAloudFemaleVoice ?? 'en-US-AvaNeural',
    male: settings.tutorEdgeReadAloudMaleVoice ?? 'en-US-ChristopherNeural'
  };
  if (conversation.replies === 'liveGemini') {
    const voice = TUTOR_LIVE_VOICES.find(([name]) => name === normalizedTutorLiveVoice(conversation.liveVoice));
    return otherGenderEdgeVoice(voice?.[2], edgeDefaults);
  }
  return otherGenderEdgeVoice(edgeSpeechVoiceGender(settings.tutorEdgeReadAloudVoice ?? ''), edgeDefaults);
}

export function tutorLearnerLiveVoice(settings: TutorVoiceSettings, liveVoice: string): string {
  const conversationVoice = normalizedTutorLiveVoice(liveVoice);
  const gender = TUTOR_LIVE_VOICES.find(([name]) => name === conversationVoice)?.[2];
  return normalizedTutorLiveVoice(gender === 'male'
    ? settings.tutorLiveFemaleVoice ?? TUTOR_DEFAULT_LIVE_FEMALE_VOICE
    : settings.tutorLiveMaleVoice ?? TUTOR_DEFAULT_LIVE_MALE_VOICE);
}

export function tutorConversationSpeechVoice(settings: TutorVoiceSettings, liveVoice: string, edgeVoice?: string): string | undefined {
  return settings.tutorReadAloudProvider === 'googleChirp'
    ? edgeVoice ?? (TUTOR_LIVE_VOICES.find(([name]) => name === normalizedTutorLiveVoice(liveVoice))?.[2] === 'male'
      ? settings.tutorLiveMaleVoice ?? 'Enceladus' : settings.tutorLiveFemaleVoice ?? 'Callirrhoe')
    : edgeVoice;
}
