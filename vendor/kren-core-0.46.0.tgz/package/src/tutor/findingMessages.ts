import type { TutorFinding } from './contract.js';
import { TUTOR_EXERCISE_CODES } from './exercise.js';
import { TUTOR_SELECTION_CODES } from './selection.js';
import { TUTOR_LESSON_CODES } from './validation.js';

/**
 * The sentences a reader is told for a tutor finding. Core owns the codes; this module owns the
 * wording, so every host shows the same sentence for the same finding.
 */
export interface TutorFindingMessageContext {
  minimumWords?: number;
  maximumWords?: number;
  log?: (line: string) => void;
}

export function tutorFindingMessage(finding: TutorFinding | undefined, context: TutorFindingMessageContext = {}): string {
  if (finding?.code === 'lesson.wordCountWarning' && typeof finding.detail?.message === 'string') return finding.detail.message;
  if (finding?.code === TUTOR_LESSON_CODES.wordCountBelowMinimum || finding?.code === TUTOR_LESSON_CODES.wordCountAboveMaximum) {
    const minimum = context.minimumWords ?? finding.detail?.minimumWords;
    const maximum = context.maximumWords ?? finding.detail?.maximumWords;
    const band = minimum !== undefined && maximum !== undefined ? ` (${minimum} to ${maximum} words)` : '';
    return `Some examples were ${finding.code === TUTOR_LESSON_CODES.wordCountBelowMinimum ? 'shorter' : 'longer'} than your setting${band}.`;
  }
  const message = knownTutorFindingMessage(finding);
  if (message) return finding && /^(lesson|exercise|review)\./u.test(finding.code) && !/[.!?]$/u.test(message) ? `${message}.` : message;
  (context.log ?? console.warn)(`[tutor finding] unknown code: ${finding?.code}`);
  const subject = finding?.code.startsWith('exercise.') ? 'practice set' : finding?.code.startsWith('review.') ? 'review' : 'lesson';
  return `The ${subject} did not meet KREN's checks.`;
}

export function knownTutorFindingMessage(finding: TutorFinding | undefined): string | undefined {
  if (finding?.code === 'lesson.excerptsTooLong') return 'The provider returned whole-sentence excerpts again. This example has no short span to highlight.';
  if (!finding) return 'Selection incomplete';
  if (finding.code === TUTOR_SELECTION_CODES.missingPrimary) return 'Choose one Primary target';
  if (finding.code === TUTOR_SELECTION_CODES.tooManyPrimaries) return 'Choose no more than three Primary targets';
  if (finding.code === TUTOR_SELECTION_CODES.tooManySupports) return 'Choose no more than three Support targets';
  if (finding.code === TUTOR_SELECTION_CODES.duplicateTarget) return 'A target can be selected only once';
  if (finding.code === TUTOR_SELECTION_CODES.ancestorDescendant) return 'Choose an exact target, not both it and an ancestor';
  if (finding.code === TUTOR_SELECTION_CODES.unknownTarget) return 'KREN could not find that target in the learning map';
  if (finding.code.startsWith('compatibility.')) return 'The selected targets have a compatibility conflict';
  if (finding.code.startsWith('recipe.')) return 'A lesson setting is outside Core\'s allowed range';
  if (finding.code === TUTOR_LESSON_CODES.requiredFieldMissing) {
    return `The lesson omitted ${String(finding.detail?.field ?? 'a required field').replace(/[._]/gu, ' ')}`;
  }
  if (finding.code === TUTOR_LESSON_CODES.schemaVersionMismatch) {
    return 'The lesson used an unsupported schema version';
  }
  if (finding.code === TUTOR_LESSON_CODES.mapVersionMismatch) {
    return 'The lesson used a different learning-map version';
  }
  if (finding.code === TUTOR_LESSON_CODES.rulesMissing) {
    return 'The lesson omitted its rules and tendencies';
  }
  if (finding.code === TUTOR_LESSON_CODES.exampleCountMismatch) {
    return `The lesson returned ${String(finding.detail?.actual)} example${finding.detail?.actual === 1 ? '' : 's'} instead of ${String(finding.detail?.requested)}`;
  }
  if (finding.code === TUTOR_LESSON_CODES.examplePhraseRepeated) return 'Several examples repeated the same phrase instead of teaching the pattern';
  if (finding.code === TUTOR_LESSON_CODES.patternStatementMissing) return 'The lesson did not explain the pattern its examples teach';
  if (finding.code === TUTOR_LESSON_CODES.primaryTargetMissing) {
    return 'A lesson example did not contain the Primary target it claimed to teach';
  }
  if (finding.code === TUTOR_LESSON_CODES.supportTargetUnderused) {
    return 'The lesson did not use a Support target in two examples';
  }
  if (finding.code === TUTOR_LESSON_CODES.annotationExcerptMissing) {
    return 'A lesson annotation named text that was not in its example';
  }
  if (finding.code === TUTOR_LESSON_CODES.answerKeyMissing) {
    return 'The lesson omitted the requested answer key';
  }
  if (finding.code === TUTOR_LESSON_CODES.exploreChoiceMissing) {
    return 'The lesson did not name the target it chose for Explore';
  }
  if (finding.code === TUTOR_LESSON_CODES.exploreChoiceOutsideParent) {
    return 'The lesson chose an Explore target outside the selected branch';
  }
  if (finding.code === TUTOR_LESSON_CODES.exploreChoiceUnexpected) {
    return 'The lesson claimed an Explore choice for an exact target';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.schemaVersionMismatch) {
    return 'The practice set used an unsupported schema version';
  }
  if (finding.code === 'exercise.exampleIndexInvalid') {
    return 'A practice item omitted its lesson example index or named an example outside the lesson';
  }
  if (finding.code === 'exercise.expectedAnswerInvalid') {
    return 'A practice item omitted its expected answer or returned an unreadable answer';
  }
  if (finding.code === 'exercise.taskLineInvalid') {
    return 'A practice item did not explain what to write';
  }
  if (finding.code === 'exercise.exampleCopied') {
    return 'A practice prompt or expected answer copied five consecutive words from a lesson example';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.mapVersionMismatch) {
    return 'The practice set used a different learning-map version';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.countMismatch) {
    return `The practice set returned ${String(finding.detail?.actual)} items instead of ${String(finding.detail?.requested)}`;
  }
  if (finding.code === TUTOR_EXERCISE_CODES.setChannelMismatch ||
      finding.code === TUTOR_EXERCISE_CODES.exerciseChannelMismatch) {
    return 'The practice set used a different exercise channel';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.duplicateIdentifier) {
    return 'The practice set reused an exercise identifier';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.unknownAnswerExercise) {
    return 'The practice answer key named an exercise that was not returned';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.spokenTurnsMissing) {
    return 'A spoken exercise omitted its dialogue turns';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.writtenTurnsPresent) {
    return 'A written exercise unexpectedly included spoken dialogue turns';
  }
  if (finding.code === TUTOR_EXERCISE_CODES.answerKeyMissing) {
    return 'The practice set omitted the requested answer key';
  }
  if (finding.code === 'review.excerptMissing') return 'The review did not mark an exact span of the answer';
  if (finding.code === 'review.noSpans') return 'The review did not include any marked answer spans';
  if (finding.code === 'review.invalidCorrectedText') return 'The review included unreadable corrected text';
  if (finding.code === 'review.invalidCategory') return 'The review used an unsupported correction category';
  return undefined;
}
