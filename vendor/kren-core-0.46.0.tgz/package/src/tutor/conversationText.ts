import { detectedLanguage } from '../languages.js';
import type { TutorConversationTurn } from './requests/types.js';

/**
 * Exact copies of the conversation text helpers KREN 2.0.1 keeps inside the VS Code extension
 * (learnerLanguage.ts, resultViewHtml.ts, resultsViewLive.ts and tutor/state.ts), so the Office
 * tutor can share them. A test compares each body with the VS Code source; change both together.
 */

/** The fields the copied helpers read from a transcript turn. */
export type TutorConversationTextTurn = Pick<TutorConversationTurn,
  'question' | 'learnerAnswer' | 'correction' | 'move' | 'reply' | 'skipped' | 'learnerNotShown' | 'spoken'>;

/** Format recognized words for display only. Do not infer sentence boundaries from word order. */
export function tutorSpokenAnswerForDisplay(rawTranscript: string): string {
  let answer = rawTranscript.trim();
  if (!answer) return answer;
  answer = answer.replace(/\bi\b/gu, 'I')
    .replace(/(^|[.!?]\s+)([\s"'\u201c\u2018(]*)(\p{L})/gu,
      (_match, boundary: string, quote: string, letter: string) => boundary + quote + letter.toLocaleUpperCase('en-US'));
  if (/[.!?]["'\u201d\u2019)]*$/u.test(answer)) return answer;
  const sentence = answer.split(/[.!?]\s+/u).at(-1) ?? answer;
  const question = /^[\s"'\u201c\u2018(]*(?:what|where|when|why|who|whom|whose|which|how|do|does|did|is|are|am|was|were|can|could|will|would|shall|should|may|might|must|have|has|had)\b/iu.test(sentence) ||
    /\b(?:can|could|would|will|do|does|did|is|are|am|was|were|should|shall|may|might|must|have|has|had)\s+(?:I|you|we|they|he|she|it)\b/iu.test(sentence);
  return answer.replace(/(["'\u201d\u2019)]*)$/u, `${question ? '?' : '.'}$1`);
}

/** English requests may quote words in any language. Extend this list for new forms. */
export const TUTOR_ENGLISH_REQUEST_PATTERNS: readonly RegExp[] = [
  /\bhow\s+(?:do\s+(?:i|you)|can\s+i)\s+say\b[\s\S]+\bin\s+english\b/iu,
  /\bhow\s+do\s+(?:i|you)\s+translate\b[\s\S]+/iu,
  /\btranslate\b[\s\S]+\binto\s+english\b/iu,
  /\bhow\s+do\s+i\s+express\b[\s\S]+\bin\s+english\b/iu,
  /\bwhat\s+is\b[\s\S]+\bin\s+english\b/iu,
  /\bwhat\s+does\b[\s\S]+\bmean\b/iu
];

export const TUTOR_COMMON_ENGLISH_WORDS = [
  'i', 'you', 'he', 'she', 'it', 'we', 'they', 'the', 'a', 'an', 'is', 'are', 'was', 'were',
  'be', 'do', 'does', 'did', 'can', 'could', 'will', 'would', 'what', 'how', 'why', 'where',
  'when', 'who', 'this', 'that', 'to', 'of', 'and', 'in', 'on', 'for', 'with', 'not',
  'yes', 'no', 'my', 'your', 'me'
] as const;

export const TUTOR_COMMON_SPANISH_WORDS = [
  'cómo', 'como', 'qué', 'que', 'dónde', 'donde', 'se', 'llama', 'tu', 'es', 'el', 'la',
  'los', 'las', 'de', 'por', 'para', 'gracias', 'hola', 'está', 'estás', 'eres', 'soy', 'muy', 'bien'
] as const;

export function tutorLearnerTurnNotShown(text: string): boolean {
  if (TUTOR_ENGLISH_REQUEST_PATTERNS.some((pattern) => pattern.test(text))) return false;
  const letters = text.match(/\p{L}/gu) ?? [];
  const nonLatin = letters.filter((letter) => !/\p{Script=Latin}/u.test(letter)).length;
  if (nonLatin > letters.length / 2) return true;
  const latinText = nonLatin > 0
    ? text.replace(/\p{L}/gu, (letter) => /\p{Script=Latin}/u.test(letter) ? letter : ' ')
    : text;
  const englishWords = (latinText.toLowerCase().match(/\p{L}+/gu) ?? [])
    .filter((word) => (TUTOR_COMMON_ENGLISH_WORDS as readonly string[]).includes(word)).length;
  if (englishWords > 1) return false;
  const language = detectedLanguage(latinText);
  // 2026-10-02: Inverted punctuation needs a Spanish word, not just an accented name.
  const spanishWords: readonly string[] = latinText.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase().match(/\p{L}+/gu) ?? [];
  if (language === undefined && /[¿¡]/u.test(latinText) && TUTOR_COMMON_SPANISH_WORDS.some(
    (word) => spanishWords.includes(word.normalize('NFD').replace(/\p{M}/gu, ''))
  )) return true;
  return language !== undefined && !/^en(?:-|$)/iu.test(language);
}

/** Drop misrecognized non-Latin segments wherever they occur, preserving English requests. */
export function tutorLearnerTurnText(text: string, segments: 'all' | 'tail' = 'all'): string {
  if (!/[^\p{Script=Latin}\P{L}]/u.test(text) ||
      TUTOR_ENGLISH_REQUEST_PATTERNS.some((pattern) => pattern.test(text))) return text;
  // Typed text keeps its existing policy because a quoted name is not misrecognized speech.
  if (segments === 'tail') {
    if (tutorLearnerTurnNotShown(text)) return text;
    const tail = /[^\p{Script=Latin}]*$/u.exec(text);
    if (!tail) return text;
    const firstLetter = tail[0].search(/\p{L}/u);
    if (firstLetter < 0) return text;
    let start = tail.index + firstLetter;
    while (start > tail.index && /\p{N}/u.test(text[start - 1]!)) start--;
    return /[\s\p{P}]/u.test(text[start - 1] ?? '') ? text.slice(0, start).trimEnd() : text;
  }
  const cleaned = text.replace(/[^\p{Script=Latin}]*[^\p{Script=Latin}\P{L}][^\p{Script=Latin}]*/gu,
    (segment, offset: number) => {
      // Preserve the punctuation and numbers belonging to the preceding English clause.
      const first = segment.search(/[^\p{Script=Latin}\P{L}]/u);
      let start = first;
      while (start > 0 && /\p{N}/u.test(segment[start - 1]!)) start--;
      const prefix = segment.slice(0, start).trimEnd();
      return (offset > 0 ? prefix : '') + ' ';
    }).replace(/\s+/gu, ' ').trim();
  // Entirely unrecognized turns keep the existing hidden-turn path.
  return cleaned && !tutorLearnerTurnNotShown(cleaned) ? cleaned : text;
}

/** Offsets always refer to the shown paragraph, never to appended structured text. */
export function tutorConversationCoachHighlights(text: string): { ranges: Array<{ start: number; end: number }> } {
  const ranges: Array<{ start: number; end: number }> = [];
  for (const match of text.matchAll(/["\u201c]([^"\u201c\u201d]+)["\u201d]/gu)) {
    const words = match[1]!.match(/[\p{L}\p{N}][\p{L}\p{M}\p{N}]*(?:['\u2019-][\p{L}\p{M}\p{N}]+)*/gu) ?? [];
    if (words.length < 2) continue;
    const start = match.index! + 1;
    ranges.push({ start, end: start + match[1]!.length });
  }
  return { ranges };
}

export function tutorRephraseMatches(rephrase: string, learnerWords: string): boolean {
  const comparable = (value: string): string => value.trim().replace(/\s+/gu, ' ')
    .replace(/[.?!]$/u, '').trim().toLocaleLowerCase('en-US');
  return comparable(rephrase) === comparable(learnerWords);
}

/** Unknown or legacy moves keep their assessment as a readable fallback. */
export function tutorConversationReply(turn: Pick<TutorConversationTurn, 'move' | 'reply' | 'correction'>): string {
  return turn.move && ['clarification', 'recast', 'reaction', 'silence'].includes(turn.move) && typeof turn.reply === 'string'
    ? turn.reply : turn.correction;
}

/** Shared by the transcript renderer and picture references. Feedback is never dialogue. */
export function tutorConversationVisibleReply(turn: TutorConversationTextTurn, explicitDialogue = false): string {
  if (turn.learnerNotShown || tutorLearnerTurnNotShown(turn.learnerAnswer)) return '';
  // 2026-10-14: Held turns retain replies without a valid move, except correction text.
  const reply = explicitDialogue && turn.reply?.trim() ? turn.reply : tutorConversationReply(turn);
  return turn.skipped || tutorConversationAnswersMatch(reply, turn.correction, turn.spoken ? 'spoken' : 'typed')
    ? '' : reply;
}

export function tutorConversationQuestionRepeatsReply(
  question: string, previous: TutorConversationTextTurn | undefined,
  explicitDialogue = false
): boolean {
  return Boolean(previous && !previous.skipped &&
    ((explicitDialogue && question === previous.reply) || question === tutorConversationReply(previous) ||
      (previous.learnerNotShown && question === previous.question)));
}

export function tutorConversationAnswersMatch(
  left: string,
  right: string,
  answers: 'typed' | 'spoken' = 'typed'
): boolean {
  const normalise = (value: string): string => value
    .trim()
    .replace(/[\u2018\u2019]/gu, "'")
    .replace(/[\u201c\u201d]/gu, '"');
  const comparable = (value: string): string => answers === 'spoken'
    ? normalise(value).toLocaleLowerCase('en-US').replace(/\p{P}+/gu, ' ')
      .replace(/\s+/gu, ' ').trim()
    : normalise(value);
  return comparable(left) === comparable(right);
}

export const TUTOR_LIVE_FILLER_SOUNDS = ['uh', 'um', 'hm', 'hmm', 'mm', 'er', 'ah'] as const;

export function tutorLiveDiscardableInput(text: string): boolean {
    if (tutorLearnerTurnNotShown(text)) return false;
    const token = text.trim().replace(/^\p{P}+|\p{P}+$/gu, '').toLowerCase();
    return /^[a-z]$/u.test(token) || TUTOR_LIVE_FILLER_SOUNDS.some((filler) => filler === token);
  }

/**
 * Gemini Live transcribes speech in pieces, and a piece that starts a new sentence can arrive
 * without the space before it: 1.64.0 showed "today?Is it a slow drip". Adds that space when
 * the text so far ends a sentence or clause and the piece starts a word.
 */
export function liveTranscriptFragment(previous: string, fragment: string): string {
  return /[.?!,;:]$/u.test(previous) && /^[\p{L}"'(]/u.test(fragment)
    ? ` ${fragment}`
    : fragment;
}
