import type { TutorConversationTurn } from './requests/types.js';

/**
 * Exact copies of the speech-input route, the lesson readiness check and the review progress KREN 2.0.1
 * keeps inside the VS Code extension (tutor/state.ts and tutor/lessonConversation.ts), so the Office
 * tutor can share them. A test compares each body with the VS Code source; change both together.
 *
 * Two differences, both in signatures only. VS Code reads its view state; core names the fields it reads.
 * And `resolveTutorSpeechRoute` calls `missingCredentialDetails` and `missingCredentialMessage` from
 * VS Code's requestCenter.ts, which hold credential descriptors core does not own, so the caller passes
 * them in as the last two parameters. Their descriptor type is the caller's own.
 */

/** The fields the copied progress helper reads from the conversation. */
export interface TutorConversationProgressState {
  transcript: ReadonlyArray<Pick<TutorConversationTurn, 'skipped' | 'learnerNotShown'>>;
}

export const TUTOR_CONVERSATION_DIAGNOSTIC_MIN_ANSWERS = 5;

export function tutorConversationReviewProgress(conversation: TutorConversationProgressState) {
  const answered = conversation.transcript.filter(turn => !turn.skipped && !turn.learnerNotShown).length;
  return { answered, remaining: Math.max(0, TUTOR_CONVERSATION_DIAGNOSTIC_MIN_ANSWERS - answered) };
}

export type TutorSpeechProvider = 'auto' | 'handy' | 'gemini' | 'cloudflare' | 'groq' | 'off';

export type ActiveTutorSpeechProvider = 'handy' | 'gemini' | 'cloudflare' | 'groq';

/** The latest local detection result for Handy, as VS Code keeps it in its speech state. */
export type TutorHandyStatus = 'checking' | 'available' | 'notFound';

export interface TutorSpeechRoute<Missing = unknown> {
  missingCredentials?: Missing;
  provider?: ActiveTutorSpeechProvider;
  reason?: string;
}

/** Resolves the reader's setting without ever treating an unavailable route as available. */
export function resolveTutorSpeechRoute<Missing>(
  configured: TutorSpeechProvider,
  handyStatus: TutorHandyStatus,
  geminiKeyConfigured: boolean,
  cloudflareConfigured = false,
  groqConfigured = false,
  missingCredentialDetails: (provider: 'gemini' | 'groq' | 'cloudflare') => Missing,
  missingCredentialMessage: (details: Missing) => string
): TutorSpeechRoute<Missing> {
  const missing = (provider: 'gemini' | 'groq' | 'cloudflare'): TutorSpeechRoute<Missing> => {
    const missingCredentials = missingCredentialDetails(provider);
    return { reason: missingCredentialMessage(missingCredentials), missingCredentials };
  };
  if (configured === 'off') return { reason: 'Speech input is turned off in Settings.' };
  if (configured === 'groq') return groqConfigured ? { provider: 'groq' } : missing('groq');
  if (configured === 'cloudflare') return cloudflareConfigured
    ? { provider: 'cloudflare' }
    : missing('cloudflare');
  if (configured === 'gemini') {
    return geminiKeyConfigured
      ? { provider: 'gemini' }
      : missing('gemini');
  }
  if (configured === 'handy') {
    if (handyStatus === 'checking') return { reason: 'Looking for Handy.' };
    return handyStatus === 'available'
      ? { provider: 'handy' }
      : { reason: 'Handy was not found on PATH or in Local AppData.' };
  }
  if (handyStatus === 'checking') {
    return { reason: 'Looking for Handy before choosing a speech input route.' };
  }
  if (handyStatus === 'available') return { provider: 'handy' };
  if (cloudflareConfigured) return { provider: 'cloudflare' };
  if (groqConfigured) return { provider: 'groq' };
  return geminiKeyConfigured
    ? { provider: 'gemini' }
    : { ...missing('cloudflare'), reason: `Handy was not found. ${['cloudflare', 'groq', 'gemini'].map(provider => missingCredentialMessage(missingCredentialDetails(provider as 'cloudflare' | 'groq' | 'gemini'))).join(' ')}` };
}

/** An exercise as the copied practice helpers read it. */
export interface TutorReadinessExercise {
  id: string;
  targetIds: readonly string[];
}

/** The fields the copied readiness and practice helpers read from VS Code's tutor view state. */
export interface TutorLessonReadinessState {
  lesson?: { lesson: { examples: ReadonlyArray<{ id: string }> } };
  lessonRevision?: number;
  practiceLessonRevision?: number;
  viewedExampleIds: readonly string[];
  lessonBusy: boolean;
  exampleBusyIds: readonly string[];
  exerciseSet?: { exercises: readonly TutorReadinessExercise[] };
  exerciseBusy: boolean;
  reviews: Record<string, { correct: readonly unknown[]; incorrect: readonly unknown[] }>;
  reviewBusyIds: readonly string[];
  practiceReviewBatch?: unknown;
}

export const TUTOR_LESSON_UNAVAILABLE = 'Finish the lesson and its practice first.';

export function tutorPracticeResults(state: TutorLessonReadinessState) {
  const exercises = state.exerciseSet?.exercises;
  if (!exercises?.length || !exercises.every((exercise) => state.reviews[exercise.id])) return undefined;
  const isRight = (exercise: TutorReadinessExercise) => {
    const review = state.reviews[exercise.id]!;
    return review.correct.length > 0 && review.incorrect.length === 0;
  };
  const targets = [...new Set(exercises.flatMap((exercise) => exercise.targetIds))].map((targetId) => {
    const covered = exercises.filter((exercise) => exercise.targetIds.includes(targetId));
    return { targetId, right: covered.filter(isRight).length, attempted: covered.length };
  });
  return {
    right: exercises.filter(isRight).length,
    attempted: exercises.length,
    targets,
    missed: exercises.filter((exercise) => !isRight(exercise))
  };
}

export function tutorAllExamplesViewed(state: TutorLessonReadinessState): boolean {
  const examples = state.lesson?.lesson.examples ?? [];
  return examples.length > 0 && examples.every((example) => state.viewedExampleIds.includes(example.id));
}

/** A stale set remains readable, but cannot block practice for the current lesson. */
export function tutorPracticeBelongsToLesson(state: TutorLessonReadinessState): boolean {
  return Boolean(state.exerciseSet && state.practiceLessonRevision === state.lessonRevision);
}

export function tutorLessonConversationReadiness(state: TutorLessonReadinessState): { ready: boolean; reason?: string } {
  const ready = Boolean(state.lesson && state.lessonRevision !== undefined &&
    state.practiceLessonRevision === state.lessonRevision && !state.lessonBusy && !state.exerciseBusy &&
    !state.exampleBusyIds.length && !state.reviewBusyIds.length && !state.practiceReviewBatch &&
    tutorAllExamplesViewed(state) && tutorPracticeResults(state));
  return ready ? { ready } : { ready, reason: TUTOR_LESSON_UNAVAILABLE };
}
