export type SpeechSourceId = 'googleChirp' | 'edgeOnline' | 'windowsLocal';
export type SpeechSettingsSource = 'shared' | 'tutor';

// 2026-10-14: This is the only provider order, shared by the two features.
const FALLBACK_ORDER: readonly SpeechSourceId[] = ['edgeOnline', 'windowsLocal'];

/** A tutor voice named for Edge speaks through Edge Online unless Chirp is the selected source. */
export function speechStartingSource(configured: SpeechSourceId, edgeVoice?: string): SpeechSourceId {
  return edgeVoice && configured !== 'googleChirp' ? 'edgeOnline' : configured;
}

/** The sources to try, in order, starting from the selected one. */
export function speechSourceOrder(provider: SpeechSourceId, settingsSource: SpeechSettingsSource): SpeechSourceId[] {
  const order = [provider, ...FALLBACK_ORDER.filter(candidate => candidate !== provider)];
  // A selected Windows voice only falls through for the tutor, as before V234.
  if (provider === 'windowsLocal' && settingsSource === 'shared') order.splice(1);
  return order;
}

/** After a failure only the text that was not spoken is offered to the next source. */
export function remainingSpeechText(outcome: { remainingText?: string }, remaining: string): string {
  return outcome.remainingText ?? remaining;
}