// 2026-10-13: Read Aloud owns this catalog and default independently of tutor voices.
export const READ_ALOUD_CHIRP_VOICES = [
  ['Achernar', 'female'], ['Achird', 'male'], ['Algenib', 'male'], ['Algieba', 'male'],
  ['Alnilam', 'male'], ['Aoede', 'female'], ['Autonoe', 'female'], ['Callirrhoe', 'female'],
  ['Charon', 'male'], ['Despina', 'female'], ['Enceladus', 'male'], ['Erinome', 'female'],
  ['Fenrir', 'male'], ['Gacrux', 'female'], ['Iapetus', 'male'], ['Kore', 'female'],
  ['Laomedeia', 'female'], ['Leda', 'female'], ['Orus', 'male'], ['Puck', 'male'],
  ['Pulcherrima', 'female'], ['Rasalgethi', 'male'], ['Sadachbia', 'male'], ['Sadaltager', 'male'],
  ['Schedar', 'male'], ['Sulafat', 'female'], ['Umbriel', 'male'], ['Vindemiatrix', 'female'],
  ['Zephyr', 'female'], ['Zubenelgenubi', 'male']
] as const;
export const READ_ALOUD_CHIRP_DEFAULT = 'Callirrhoe';
export function isReadAloudChirpVoice(value: unknown): value is string {
  return READ_ALOUD_CHIRP_VOICES.some(([voice]) => voice === value);
}
export function normalizedReadAloudChirpVoice(value: unknown): string {
  return isReadAloudChirpVoice(value) ? value : READ_ALOUD_CHIRP_DEFAULT;
}
export const READ_ALOUD_CHIRP_LOCALES = [
  'ar-XA', 'bn-IN', 'bg-BG', 'yue-HK', 'hr-HR', 'cs-CZ', 'da-DK', 'nl-BE', 'nl-NL',
  'en-AU', 'en-IN', 'en-GB', 'en-US', 'et-EE', 'fi-FI', 'fr-CA', 'fr-FR', 'de-DE',
  'el-GR', 'gu-IN', 'he-IL', 'hi-IN', 'hu-HU', 'id-ID', 'it-IT', 'ja-JP', 'kn-IN',
  'ko-KR', 'lv-LV', 'lt-LT', 'ml-IN', 'cmn-CN', 'mr-IN', 'nb-NO', 'pl-PL', 'pt-BR',
  'pa-IN', 'ro-RO', 'ru-RU', 'sr-RS', 'sk-SK', 'sl-SI', 'es-ES', 'es-US', 'sw-KE',
  'sv-SE', 'ta-IN', 'te-IN', 'th-TH', 'tr-TR', 'uk-UA', 'ur-IN', 'vi-VN'
] as const;
export function resolveReadAloudChirpLocale(locale: string): string | undefined {
  if (READ_ALOUD_CHIRP_LOCALES.some(value => value === locale)) return locale;
  if (['zh-CN', 'zh-SG', 'zh'].includes(locale)) return 'cmn-CN';
  if (locale === 'zh-HK') return 'yue-HK';
  const language = locale.split('-')[0]!;
  const primary: Record<string, string> = { en: 'en-US', es: 'es-ES', fr: 'fr-FR', pt: 'pt-BR', nl: 'nl-NL' };
  if (primary[language]) return primary[language];
  const matches = READ_ALOUD_CHIRP_LOCALES.filter(value => value.split('-')[0] === language);
  return matches.length === 1 ? matches[0] : undefined;
}

/**
 * Gemini Live's prebuilt voices with the one-word style Google gives each. The gender
 * classification matches https://docs.cloud.google.com/text-to-speech/docs/chirp3-hd, checked 2026-09-19. Kore is explicit
 * rather than leaving the voice to an unknown server default, so replay can choose the other
 * gender deterministically.
 */
export const TUTOR_LIVE_VOICES = [
  ['Zephyr', 'Bright', 'female'], ['Puck', 'Upbeat', 'male'],
  ['Charon', 'Informative', 'male'], ['Kore', 'Firm', 'female'],
  ['Fenrir', 'Excitable', 'male'], ['Leda', 'Youthful', 'female'],
  ['Orus', 'Firm', 'male'], ['Aoede', 'Breezy', 'female'],
  ['Callirrhoe', 'Easy-going', 'female'], ['Autonoe', 'Bright', 'female'],
  ['Enceladus', 'Breathy', 'male'], ['Iapetus', 'Clear', 'male'],
  ['Umbriel', 'Easy-going', 'male'], ['Algieba', 'Smooth', 'male'],
  ['Despina', 'Smooth', 'female'], ['Erinome', 'Clear', 'female'],
  ['Algenib', 'Gravelly', 'male'], ['Rasalgethi', 'Informative', 'male'],
  ['Laomedeia', 'Upbeat', 'female'], ['Achernar', 'Soft', 'female'],
  ['Alnilam', 'Firm', 'male'], ['Schedar', 'Even', 'male'],
  ['Gacrux', 'Mature', 'female'], ['Pulcherrima', 'Forward', 'female'],
  ['Achird', 'Friendly', 'male'], ['Zubenelgenubi', 'Casual', 'male'],
  ['Vindemiatrix', 'Gentle', 'female'], ['Sadachbia', 'Lively', 'male'],
  ['Sadaltager', 'Knowledgeable', 'male'], ['Sulafat', 'Warm', 'female']
] as const;
export function isTutorLiveVoice(value: string): boolean {
  return value === '' || TUTOR_LIVE_VOICES.some(([name]) => name === value);
}
export function normalizedTutorLiveVoice(value: string): string {
  return TUTOR_LIVE_VOICES.some(([name]) => name === value) ? value : 'Kore';
}
