import { parseStructuredJson } from '../structuredJson.js';
import { schemaInstruction } from '../structuredJsonShape.js';
import { ProviderResponseError, type CompatibleBodyCall, type CompatibleProvider } from './contracts.js';
const STRICT_GROQ_MODELS = ['openai/gpt-oss-120b', 'qwen/qwen3.8-27b'];
const compatibleProviderName = (provider: CompatibleProvider): string => provider === 'groq' ? 'Groq' : 'Cloudflare';
export function buildCompatibleRequestBody(call: CompatibleBodyCall, instruction: string, input: string): Record<string, unknown> {
    const strict = call.provider === 'groq' && STRICT_GROQ_MODELS.includes(call.model);
    const responseFormat = call.provider === 'cloudflare'
        ? { type: 'json_schema', json_schema: call.schema }
        : strict ? { type: 'json_schema', json_schema: { name: call.schemaName, strict: true, schema: strictSchema(call.schema) } }
            : { type: 'json_object' };
    const effort = call.thinkingOrEffort === 'none' || call.thinkingOrEffort === 'minimal' ? 'low' : call.thinkingOrEffort;
    return {
        model: call.model,
        messages: [{ role: 'system', content: `${instruction}\n\n${schemaInstruction(call.schema)}` }, { role: 'user', content: input }],
        max_tokens: 4096, stream: false, response_format: responseFormat,
        ...(call.provider === 'groq' && call.model === 'openai/gpt-oss-120b' && effort !== 'auto'
            ? { reasoning_effort: effort } : {})
    };
}
export function strictSchema(schema: Record<string, unknown>): Record<string, unknown> {
    const result = { ...schema };
    if (schema.type === 'object' || Array.isArray(schema.type) && schema.type.includes('object')) {
        result.additionalProperties = false;
        result.required = [];
    }
    if (schema.properties && typeof schema.properties === 'object') {
        const required = Array.isArray(schema.required) ? schema.required : [];
        result.properties = Object.fromEntries(Object.entries(schema.properties).map(([key, value]) => {
            const child = strictSchema(value as Record<string, unknown>);
            return [key, required.includes(key) ? child : child.type
                    ? { ...child, type: [...(Array.isArray(child.type) ? child.type : [child.type]), 'null'],
                        ...(Array.isArray(child.enum) ? { enum: [...child.enum, null] } : {}) }
                    : { anyOf: [child, { type: 'null' }] }];
        }));
        result.required = Object.keys(schema.properties);
        result.additionalProperties = false;
    }
    if (schema.items && typeof schema.items === 'object')
        result.items = strictSchema(schema.items as Record<string, unknown>);
    for (const key of ['anyOf', 'oneOf', 'allOf'])
        if (Array.isArray(schema[key]))
            result[key] = schema[key].map(item => strictSchema(item));
    return result;
}
export function compatibleFailure(provider: CompatibleProvider, reason: 'structuredOutput' | 'refused' = 'structuredOutput'): ProviderResponseError {
    return new ProviderResponseError(`${compatibleProviderName(provider)} returned invalid structured output. Try again.`, undefined, false, undefined, reason);
}
export function validatedCompatibleText(call: Pick<CompatibleBodyCall, 'provider' | 'schema' | 'model'> & {
    batchEnvelope?: boolean;
}, envelope: unknown): string {
    const refusal = (envelope as {
        choices?: Array<{
            message?: {
                refusal?: unknown;
            };
        }>;
    } | undefined)?.choices?.[0]?.message?.refusal;
    if (refusal)
        throw compatibleFailure(call.provider, 'refused');
    try {
        const payload = envelope as {
            choices?: Array<{
                message?: {
                    content?: unknown;
                    refusal?: unknown;
                };
            }>;
        };
        const message = payload?.choices?.[0]?.message;
        if (message?.refusal || typeof message?.content !== 'string')
            throw new Error();
        const parsed = parseStructuredJson(message.content);
        const value = call.provider === 'groq' && STRICT_GROQ_MODELS.includes(call.model)
            ? removeOptionalNulls(parsed, call.schema) : parsed;
        const validationSchema = call.batchEnvelope ? { ...call.schema, properties: {
                ...(call.schema.properties as Record<string, unknown>), reviews: {
                    ...((call.schema.properties as Record<string, unknown>)?.reviews as Record<string, unknown>), items: {}
                }
            } } : call.schema;
        if (!matchesSchema(value, validationSchema))
            throw new Error();
        return JSON.stringify(value);
    }
    catch {
        throw compatibleFailure(call.provider);
    }
}
function removeOptionalNulls(value: unknown, schema: Record<string, unknown>): unknown {
    if (Array.isArray(value))
        return value.map(item => removeOptionalNulls(item, schema.items as Record<string, unknown> ?? {}));
    if (value && typeof value === 'object' && schema.properties) {
        const properties = schema.properties as Record<string, Record<string, unknown>>;
        const required = schema.required as string[] ?? [];
        return Object.fromEntries(Object.entries(value).filter(([key, item]) => item !== null || required.includes(key) || !Object.hasOwn(properties, key))
            .map(([key, item]) => [key, removeOptionalNulls(item, properties[key] ?? {})]));
    }
    return value;
}
function matchesSchema(value: unknown, schema: Record<string, unknown>): boolean {
    if (Array.isArray(schema.anyOf) && !schema.anyOf.some(item => matchesSchema(value, item)))
        return false;
    if (Array.isArray(schema.oneOf) && schema.oneOf.filter(item => matchesSchema(value, item)).length !== 1)
        return false;
    if (Array.isArray(schema.allOf) && !schema.allOf.every(item => matchesSchema(value, item)))
        return false;
    if (schema.const !== undefined && value !== schema.const)
        return false;
    if (Array.isArray(schema.enum) && !schema.enum.includes(value))
        return false;
    const type = value === null ? 'null' : Array.isArray(value) ? 'array' : typeof value;
    if (schema.type && !(Array.isArray(schema.type) ? schema.type : [schema.type]).some(t => t === type || t === 'integer' && typeof value === 'number' && Number.isInteger(value)))
        return false;
    if (Array.isArray(value)) {
        if (typeof schema.minItems === 'number' && value.length < schema.minItems || typeof schema.maxItems === 'number' && value.length > schema.maxItems)
            return false;
        if (schema.items && !value.every(item => matchesSchema(item, schema.items as Record<string, unknown>)))
            return false;
    }
    else if (type === 'object') {
        const record = value as Record<string, unknown>;
        const properties = schema.properties as Record<string, Record<string, unknown>> ?? {};
        if (Array.isArray(schema.required) && !schema.required.every(key => Object.hasOwn(record, key)))
            return false;
        if (schema.additionalProperties === false && Object.keys(record).some(key => !Object.hasOwn(properties, key)))
            return false;
        if (!Object.entries(properties).every(([key, child]) => !Object.hasOwn(record, key) || matchesSchema(record[key], child)))
            return false;
    }
    if (typeof value === 'string' && (typeof schema.minLength === 'number' && value.length < schema.minLength || typeof schema.maxLength === 'number' && value.length > schema.maxLength))
        return false;
    if (typeof value === 'number' && (!Number.isFinite(value) || typeof schema.minimum === 'number' && value < schema.minimum || typeof schema.maximum === 'number' && value > schema.maximum))
        return false;
    return true;
}
