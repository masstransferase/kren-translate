import type { FeatureTranslationRequest as TranslationRequest, FeatureTranslationResult as TranslationResult, FeatureRewriteRequest as RewriteRequest, FeatureRewriteResult as RewriteResult, FeatureRewriteVariant as RewriteVariant } from './contracts.js';
import { ProviderResponseError } from './contracts.js';
import type { RewriteVariantId } from '../contracts.js';
import { localeLanguageName as languageName, isSameLanguage, isEnglishLanguageCode } from '../languages.js';
import { normalizeLanguageCode } from '../validation.js';
import { parseStructuredJson } from '../structuredJson.js';
import { providerIdentifier } from './httpError.js';
import { REWRITE_OUTPUT_RULES, REWRITE_PRIORITY_RULE, REWRITE_WORKED_EXAMPLE, REWRITE_VARIANT_IDS, REWRITE_VARIANTS, rewriteVariantLabel } from '../rewriteVariants.js';
import { REWRITE_DOMAINS, REWRITE_ENGLISH_VARIETIES, rewriteOutputLanguageCode, REWRITE_FORMALITIES, REWRITE_FUNCTIONS, REWRITE_LENGTHS, REWRITE_MODALITIES, REWRITE_PERSPECTIVES, REWRITE_RHETORICAL_MODES, REWRITE_STANCES, REWRITE_VOICES, rewriteAxisInstruction } from '../rewriteAxes.js';
const EXPLANATION_SAME_AS_SOURCE = 'sameAsSource';
export const REWRITE_VARIANT_OPERATIONS = { minimal: 'rewriteMinimal', full: 'rewriteFull' } as const;
function isRewriteVariantId(value: unknown): value is RewriteVariantId { return typeof value === 'string' && (REWRITE_VARIANT_IDS as readonly string[]).includes(value); }
const SPOKEN_ABBREVIATIONS = ['e.g.', 'i.e.', 'Fig.', 'vs.', 'etc.', 'et al.', 'cf.'] as const;
const SPOKEN_VISUAL_DEIXIS = [
    'shown above',
    'shown below',
    'see above',
    'see below',
    'described above',
    'described below',
    'listed above',
    'listed below',
    'the figure above',
    'the table below',
    'as above',
    'the latter'
] as const;
function domainInstruction(request: TranslationRequest): string | undefined {
    if (!request.domain || request.domain === REWRITE_DOMAINS[0].id)
        return undefined;
    return rewriteAxisInstruction(REWRITE_DOMAINS, request.domain);
}
export function systemInstruction(request: TranslationRequest): string {
    const source = request.sourceLanguage === 'auto'
        ? 'automatically detected source language'
        : languageName(request.sourceLanguage);
    const target = languageName(request.targetLanguage);
    if (request.operation === 'explain') {
        const explanationLanguage = request.explanationLanguage === EXPLANATION_SAME_AS_SOURCE ||
            request.explanationLanguage === undefined
            ? 'the same language as the selected text, and that language only'
            : `${languageName(request.explanationLanguage)} only`;
        const sameLanguage = isSameLanguage(request.sourceLanguage, request.targetLanguage);
        const equivalent = sameLanguage
            ? `restate it plainly in ${target}`
            : `give a natural ${target} equivalent`;
        return [
            `Explain the selected ${source} text and ${equivalent}.`,
            ...(domainInstruction(request) ? [domainInstruction(request)!] : []),
            'Return JSON only with this shape:',
            '{"kind":"translation","translatedText":"natural equivalent","alternatives":["optional alternative"],"note":"meaning and nuance explanation"}',
            `Write the note in ${explanationLanguage}.`,
            'Explain contextual meaning, nuance, register, connotation, ambiguity, and relevant technical usage.',
            'Do not infer or mention any document context because none is provided.'
        ].join('\n');
    }
    return [
        `Translate the selected ${source} text into natural ${target}.`,
        ...(domainInstruction(request) ? [domainInstruction(request)!] : []),
        'Preserve Markdown, code identifiers, placeholders, citations, filenames, and technical terminology.',
        'Return JSON only with this shape:',
        '{"kind":"translation","translatedText":"string","alternatives":["optional string"],"note":"optional concise nuance explanation"}',
        'Include a note only when needed to prevent misunderstanding.'
    ].join('\n');
}
export function rewriteSystemInstruction(request: RewriteRequest): string {
    const outputLanguage = rewriteOutputLanguageCode(request.englishVariety, request.otherOutputLanguage);
    const detect = request.sourceLanguage === 'auto'
        ? 'Detect the dominant natural language of the supplied text and return its BCP-47 language code in detectedLanguage.'
        : `The source language is ${languageName(request.sourceLanguage)} (${request.sourceLanguage}). Return "${request.sourceLanguage}" in detectedLanguage.`;
    const write = outputLanguage === undefined
        ? 'Write every variant in that same language and never translate it.'
        : `Write every variant in ${languageName(outputLanguage)}, translating the text when it is written in another language. detectedLanguage still reports the language of the supplied text, not the language you wrote in.`;
    const languageInstruction = `${detect} ${write}`;
    const commonInstructions = [
        REWRITE_PRIORITY_RULE,
        'Rewrite only the exact text supplied by the user.',
        languageInstruction,
        'Preserve its factual meaning, claims, qualifications, numbers, and citations.',
        'Preserve intentional mixed-language terms, names, quotations, code, and necessary domain terminology.',
        'These preservation rules govern meaning, not wording. Choosing different words to carry the same meaning is expected of every variant and is never a violation of them.',
        'Correct grammar and unnatural phrasing. Do not add facts, evidence, promises, certainty, examples, or document context.',
        'Never intensify a claim beyond the evidence or qualifications present in the supplied text.',
        'Return JSON only. Every variant must be complete and usable on its own.'
    ];
    const fullRewriteInstructions: string[] = [];
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_FUNCTIONS, request.function));
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_DOMAINS, request.domain));
    const englishVarietyInstruction = rewriteAxisInstruction(REWRITE_ENGLISH_VARIETIES, request.englishVariety);
    if (englishVarietyInstruction) {
        fullRewriteInstructions.push(englishVarietyInstruction);
    }
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_FORMALITIES, request.formality));
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_VOICES, request.voice));
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_STANCES, request.stance));
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_PERSPECTIVES, request.perspective));
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_RHETORICAL_MODES, request.rhetoricalMode));
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_MODALITIES, request.modality));
    pushInstruction(fullRewriteInstructions, rewriteAxisInstruction(REWRITE_LENGTHS, request.length));
    const formattingInstruction = 'Preserve Markdown, LaTeX commands, citations, links, placeholders, code identifiers, filenames, inline code, and fenced code blocks exactly unless grammar inside ordinary prose requires a change.';
    const outputRulesInstruction = `The following output rules apply to every requested variant: ${REWRITE_OUTPUT_RULES.join(' ')}`;
    const changeNoteField = request.includeChangeNotes
        ? ',"changeNote":"one concise sentence describing the important edits"'
        : '';
    const changeNoteInstruction = request.includeChangeNotes
        ? 'For each variant, include a concise changeNote describing only the important edits.'
        : 'Do not include commentary or change notes.';
    const singleVariant = rewriteOperationVariant(request.operation);
    const requestedVariants = singleVariant
        ? REWRITE_VARIANTS.filter((variant) => variant.id === singleVariant)
        : REWRITE_VARIANTS;
    const variantInstructions: string[] = [];
    for (const [index, variant] of requestedVariants.entries()) {
        variantInstructions.push(`${index + 1}. ${variant.instruction}`);
        if (variant.id === 'minimal' && request.preserveFormatting !== false) {
            variantInstructions.push(`Minimal Rewrite formatting requirement: ${formattingInstruction}`);
        }
        if (variant.id === 'full') {
            variantInstructions.push('Style settings for Full Rewrite only:');
            variantInstructions.push(...fullRewriteInstructions);
            if (request.preserveFormatting !== false && request.modality === REWRITE_MODALITIES[0].id) {
                variantInstructions.push(`Full Rewrite formatting requirement: ${formattingInstruction}`);
            }
        }
    }
    const schemaVariants = requestedVariants.map((variant) => `{"id":"${variant.id}","label":"${variant.label}","text":"rewritten text"${changeNoteField}}`).join(',');
    return [
        ...commonInstructions,
        outputRulesInstruction,
        `Produce exactly ${requestedVariants.length === 1 ? 'one' : 'two'} variant${requestedVariants.length === 1 ? '' : 's'}:`,
        ...variantInstructions,
        changeNoteInstruction,
        REWRITE_WORKED_EXAMPLE,
        `Return exactly this JSON shape${requestedVariants.length > 1 ? ' and order' : ''}:`,
        `{"kind":"rewrite","detectedLanguage":"BCP-47 code","variants":[${schemaVariants}]}`
    ].join('\n');
}
export function parseJson(raw: string, providerName = 'Provider'): unknown {
    try {
        const value = parseStructuredJson(raw);
        if (!isRecord(value))
            throw new Error();
        return value;
    }
    catch {
        throw new ProviderResponseError(`${providerName} returned malformed structured output. Try again.`, undefined, true, undefined, 'structuredOutput');
    }
}
export function normalizeTranslationResult(value: unknown, request: TranslationRequest, providerId: string, createdAt: string): TranslationResult {
    const providerName = languageModelProviderName(providerId);
    if (!isRecord(value)) {
        throw new ProviderResponseError(`${providerName} returned an unsupported result.`, undefined, true, undefined, 'structuredOutput');
    }
    const base = {
        providerId,
        operation: request.operation,
        sourceText: request.text,
        sourceLanguage: request.sourceLanguage,
        targetLanguage: request.targetLanguage,
        createdAt
    };
    const translatedText = stringValue(value.translatedText);
    if (!translatedText) {
        throw new ProviderResponseError(`${providerName} returned no translation.`, undefined, true, undefined, 'structuredOutput');
    }
    const result: TranslationResult = {
        ...base,
        kind: 'translation',
        translatedText
    };
    const alternatives = Array.isArray(value.alternatives)
        ? value.alternatives.map(stringValue).filter((item): item is string => Boolean(item)).slice(0, 3)
        : [];
    const note = stringValue(value.note);
    if (alternatives.length > 0)
        result.alternatives = alternatives;
    if (note)
        result.note = note;
    return result;
}
export function normalizeRewriteResult(value: unknown, request: RewriteRequest, providerId: string, createdAt: string): RewriteResult {
    const providerName = languageModelProviderName(providerId);
    if (!isRecord(value) || !Array.isArray(value.variants)) {
        throw new ProviderResponseError(`${providerName} returned an unsupported rewrite result.`, undefined, true, undefined, 'structuredOutput');
    }
    const sourceLanguage = request.sourceLanguage === 'auto'
        ? normalizeLanguageCode(providerIdentifier(value.detectedLanguage))
        : normalizeLanguageCode(request.sourceLanguage);
    if (!sourceLanguage) {
        throw new ProviderResponseError(`${providerName} did not return a valid detected language. Try again or select the source language in KREN Settings.`, undefined, true, undefined, 'structuredOutput');
    }
    const requestedVariant = rewriteOperationVariant(request.operation);
    const targetLanguage = rewriteOutputLanguageCode(request.englishVariety, request.otherOutputLanguage) ?? sourceLanguage;
    const expectedIds: readonly RewriteVariantId[] = requestedVariant
        ? [requestedVariant]
        : REWRITE_VARIANT_IDS;
    if (value.variants.length !== expectedIds.length) {
        throw new ProviderResponseError(`${providerName} did not return all requested rewrite variants. Try again.`, undefined, true, undefined, 'structuredOutput');
    }
    const byId = new Map<RewriteVariantId, RewriteVariant>();
    for (const item of value.variants) {
        if (!isRecord(item))
            continue;
        const id = rewriteVariantId(item.id);
        const text = stringValue(item.text);
        if (!id || !text || !expectedIds.includes(id))
            continue;
        const variant: RewriteVariant = { id, label: rewriteVariantLabel(id), text, targetLanguage };
        const changeNote = stringValue(item.changeNote);
        if (changeNote)
            variant.changeNote = changeNote;
        byId.set(id, variant);
    }
    const variants = expectedIds.map((id) => byId.get(id));
    if (variants.some((variant) => !variant)) {
        throw new ProviderResponseError(`${providerName} did not return all requested rewrite variants. Try again.`, undefined, true, undefined, 'structuredOutput');
    }
    for (const variant of variants as RewriteVariant[]) {
        if (variant.id !== 'full')
            continue;
        const violation = rewriteOutputViolation(variant.text, request, sourceLanguage);
        if (violation) {
            throw new ProviderResponseError(`${providerName} returned a rewrite that did not satisfy the requested ${violation}. Try again.`, undefined, true, undefined, 'structuredOutput');
        }
    }
    return {
        kind: 'rewrite',
        providerId,
        sourceText: request.text,
        sourceLanguage,
        targetLanguage,
        createdAt,
        englishVariety: request.englishVariety,
        modality: request.modality,
        function: request.function,
        domain: request.domain,
        formality: request.formality,
        voice: request.voice,
        stance: request.stance,
        length: request.length,
        perspective: request.perspective,
        rhetoricalMode: request.rhetoricalMode,
        variants: variants as RewriteVariant[]
    };
}
export function rewriteOutputViolation(text: string, request: RewriteRequest, sourceLanguage = request.sourceLanguage): 'spoken modality' | 'length' | 'perspective' | undefined {
    if (request.modality === REWRITE_MODALITIES[1].id) {
        if (/[();\u2013\u2014]/u.test(text))
            return 'spoken modality';
        if (SPOKEN_ABBREVIATIONS.some((abbreviation) => text.includes(abbreviation))) {
            return 'spoken modality';
        }
        if (/\d[%&]/u.test(text))
            return 'spoken modality';
        const lower = text.toLocaleLowerCase('en-US');
        if (SPOKEN_VISUAL_DEIXIS.some((phrase) => lower.includes(phrase))) {
            return 'spoken modality';
        }
    }
    if (request.length === REWRITE_LENGTHS[1].id && text.length >= request.text.length) {
        return 'length';
    }
    if (request.length === REWRITE_LENGTHS[2].id && text.length <= request.text.length) {
        return 'length';
    }
    if (isEnglishLanguageCode(sourceLanguage)) {
        const firstPerson = /\b(?:I|me|my|mine|myself|we|us|our|ours|ourselves)\b/iu;
        if (request.perspective === REWRITE_PERSPECTIVES[1].id && !firstPerson.test(text)) {
            return 'perspective';
        }
        if (request.perspective === REWRITE_PERSPECTIVES[2].id && firstPerson.test(text)) {
            return 'perspective';
        }
    }
    return undefined;
}
function pushInstruction(instructions: string[], instruction: string | undefined): void {
    if (instruction)
        instructions.push(instruction);
}
function languageModelProviderName(providerId: string): string {
    if (providerId === 'openai')
        return 'OpenAI';
    if (providerId === 'groq')
        return 'Groq';
    if (providerId === 'cloudflare')
        return 'Cloudflare';
    if (providerId === 'anthropic')
        return 'Anthropic';
    return 'Gemini';
}
function rewriteOperationVariant(operation: RewriteRequest['operation']): RewriteVariantId | undefined {
    return REWRITE_VARIANTS.find((variant) => REWRITE_VARIANT_OPERATIONS[variant.id] === operation)?.id;
}
function rewriteVariantId(value: unknown): RewriteVariantId | undefined {
    return isRewriteVariantId(value) ? value : undefined;
}
function isRecord(value: unknown): value is Record<string, unknown> {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function stringValue(value: unknown): string | undefined {
    return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
