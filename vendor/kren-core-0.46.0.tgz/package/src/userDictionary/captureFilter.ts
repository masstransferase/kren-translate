import { USER_DICTIONARY_CAPTURE_MODES, type UserDictionaryCaptureMode } from './contract.js';

/** The capture-mode filter labels the User Dictionary screen offers, in the order of the closed list of modes. */
export function userDictionaryCaptureFilterOptions(): Array<[
  UserDictionaryCaptureMode,
  string
]> {
  return USER_DICTIONARY_CAPTURE_MODES.map((id) => [
    id,
    id === 'llmOnly'
      ? 'LLM Only'
      : id === 'merriamWebsterAndLlm' ? 'Merriam-Webster + LLM' : 'Manual or imported'
  ]);
}
