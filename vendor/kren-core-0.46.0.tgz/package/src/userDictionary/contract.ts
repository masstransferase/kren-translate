export const USER_DICTIONARY_MANUAL_CAPTURE_MODE = 'manual' as const;

export const USER_DICTIONARY_CAPTURE_MODES = [
  'llmOnly',
  'merriamWebsterAndLlm',
  USER_DICTIONARY_MANUAL_CAPTURE_MODE
] as const;

export type UserDictionaryCaptureMode = typeof USER_DICTIONARY_CAPTURE_MODES[number];

export type UserDictionaryProviderCaptureMode = Exclude<
  UserDictionaryCaptureMode,
  typeof USER_DICTIONARY_MANUAL_CAPTURE_MODE
>;

export const USER_DICTIONARY_PROVIDERS = [
  'gemini',
  'openai',
  'anthropic',
  'groq',
  'cloudflare'
] as const;

export type UserDictionaryProvider = typeof USER_DICTIONARY_PROVIDERS[number];

interface UserDictionaryCaptureBaseV1 {
  generatedAt: string;
  userEdited: boolean;
}

export type UserDictionaryCaptureV1 =
  | UserDictionaryCaptureBaseV1 & {
    mode: typeof USER_DICTIONARY_MANUAL_CAPTURE_MODE;
    provider?: never;
    model?: never;
  }
  | UserDictionaryCaptureBaseV1 & {
    mode: UserDictionaryProviderCaptureMode;
    provider: UserDictionaryProvider;
    model: string;
  };

export const MERRIAM_WEBSTER_REFERENCE_WORKS = ['collegiate'] as const;

export type MerriamWebsterReferenceWork = typeof MERRIAM_WEBSTER_REFERENCE_WORKS[number];

export const MERRIAM_WEBSTER_MATCH_STATUSES = [
  'matched',
  'noMatch',
  'notQueried'
] as const;

export type MerriamWebsterMatchStatus = typeof MERRIAM_WEBSTER_MATCH_STATUSES[number];

export const USER_DICTIONARY_ENTRY_V1_FIELDS = [
  'schemaVersion',
  'id',
  'term',
  'normalizedTerm',
  'language',
  'entryType',
  'collection',
  'domains',
  'tags',
  'pronunciation',
  'senses',
  'aliases',
  'capture',
  'merriamWebsterReference',
  'capturedContext',
  'createdAt',
  'updatedAt'
] as const;

/**
 * The longest sentence KREN will send as capture context or store on an entry. A sentence
 * this long is pathological rather than useful, and the cap is stated once here because the
 * host that extracts the sentence and the validator that accepts the entry have to agree:
 * a host clipping at a different number would write entries its own store then rejects.
 */
export const USER_DICTIONARY_CONTEXT_MAX_CHARACTERS = 500;

export interface UserDictionaryEntryV1 {
  schemaVersion: 1;
  id: string;
  term: string;
  normalizedTerm: string;
  language: string;
  entryType: string;
  collection: string;
  domains: string[];
  tags: string[];
  pronunciation?: {
    display?: string;
    audioAvailable?: boolean;
  };
  senses: Array<{
    id: string;
    partOfSpeech?: string;
    // Set only for a heteronym, where the spelling is pronounced differently depending on
    // which sense is meant: the noun "record" against the verb, or "lead" the metal against
    // "lead" the verb. The entry-level pronunciation is the one the word usually takes, and
    // for the overwhelming majority of entries it is the only one there is, so this stays
    // absent rather than repeating it on every sense.
    pronunciation?: string;
    definition: string;
    usageNote?: string;
    synonyms: string[];
    antonyms: string[];
    relatedTerms: string[];
    examples: string[];
  }>;
  aliases: string[];
  capture: UserDictionaryCaptureV1;
  merriamWebsterReference?: {
    referenceWork: MerriamWebsterReferenceWork;
    lookupTerm: string;
    entryId?: string;
    matchStatus: MerriamWebsterMatchStatus;
  };
  /**
   * Set only when the expression was captured with surrounding context enabled. The sentence
   * is the one the expression was selected in, kept because it is the reason this entry
   * exists and because "the current context" stops being current the moment the entry is
   * saved. senseId names the sense that sentence uses, and is absent when the sentence did
   * not settle which meaning applied, which is the honest outcome for a sentence that does
   * not distinguish them rather than a reason to pick one.
   */
  capturedContext?: {
    sentence: string;
    senseId?: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface UserDictionaryStoreV1 {
  schemaVersion: 1;
  entries: UserDictionaryEntryV1[];
}

function isClosedValue<T extends readonly string[]>(
  values: T,
  value: unknown
): value is T[number] {
  return typeof value === 'string' && values.some((candidate) => candidate === value);
}

export const isUserDictionaryCaptureMode = (
  value: unknown
): value is UserDictionaryCaptureMode => isClosedValue(USER_DICTIONARY_CAPTURE_MODES, value);

export const isUserDictionaryProvider = (
  value: unknown
): value is UserDictionaryProvider => isClosedValue(USER_DICTIONARY_PROVIDERS, value);

export const isMerriamWebsterReferenceWork = (
  value: unknown
): value is MerriamWebsterReferenceWork => isClosedValue(MERRIAM_WEBSTER_REFERENCE_WORKS, value);

export const isMerriamWebsterMatchStatus = (
  value: unknown
): value is MerriamWebsterMatchStatus => isClosedValue(MERRIAM_WEBSTER_MATCH_STATUSES, value);
