import type { LanguageModelRoutingProvider } from './languageModelRouting.js';

/**
 * The missing-credential sentence: it names the provider, the Gemini profile and the missing
 * slots, and when only the other Gemini profile has a key it says which one to choose. The text is
 * the shared wording for every host; a descriptor carries presence information only, never a
 * credential value.
 */
export type CredentialProvider = LanguageModelRoutingProvider | 'googleCloudTranslation' | 'googleCloudTextToSpeech' |
  'merriamWebsterCollegiate' | 'merriamWebsterMedical' | 'merriamWebsterThesaurus' | 'koreanDictionary';
export interface MissingCredentials {
  provider: CredentialProvider;
  geminiProfile?: 'standard' | 'pro';
  slots: readonly string[];
}
export function credentialProviderName(provider: CredentialProvider, profile: 'standard' | 'pro' = 'standard'): string {
  const credentialNames: Record<CredentialProvider, string> = {
    gemini: 'Gemini', groq: 'Groq', cloudflare: 'Cloudflare', openai: 'OpenAI', anthropic: 'Anthropic',
    googleCloudTranslation: 'Google Cloud Translation', googleCloudTextToSpeech: 'Google Cloud Text-to-Speech',
    merriamWebsterCollegiate: 'Merriam-Webster Collegiate', merriamWebsterMedical: 'Merriam-Webster Medical',
    merriamWebsterThesaurus: 'Merriam-Webster Collegiate Thesaurus', koreanDictionary: 'Korean Basic Dictionary'
  };
  return credentialNames[provider] + (provider === 'gemini' ? profile === 'pro' ? ' Paid' : ' Free Tier' : '');
}
export interface GeminiCredentialPresence { geminiDefault?: boolean; geminiAlternate?: boolean }
/** Uses presence only so initial rendering and mounted setting updates share one rule. */
export function otherGeminiProfileMessage(provider: string, profile: string, presence: GeminiCredentialPresence = {}): string {
  if (provider !== 'gemini') return '';
  const selected = profile === 'pro' ? presence.geminiAlternate : presence.geminiDefault;
  const other = profile === 'pro' ? presence.geminiDefault : presence.geminiAlternate;
  if (selected || !other) return '';
  const name = profile === 'pro' ? 'Free Tier' : 'Paid';
  return ` Gemini ${name} has a key: choose ${name} in this feature's settings to use it.`;
}
export function missingCredentialMessage(details: MissingCredentials, presence?: GeminiCredentialPresence): string {
  const name = credentialProviderName(details.provider, details.geminiProfile);
  const message = details.provider === 'googleCloudTextToSpeech'
    ? 'Set your Google Cloud Text-to-Speech API key or Google Cloud Translation API key in KREN menu, Credentials.'
    : `Set ${details.provider === 'cloudflare' ? 'the' : 'your'} ${name} ${details.slots.join(' and ')} in KREN menu, Credentials.`;
  return message + otherGeminiProfileMessage(details.provider, details.geminiProfile ?? 'standard', presence);
}
