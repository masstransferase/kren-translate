/** Plain-data request bodies for dictation. The host makes the call and owns keys and errors. */
export const GROQ_DICTATION_MODEL = 'whisper-large-v3-turbo';
export const CLOUDFLARE_DICTATION_MODEL = '@cf/openai/whisper-large-v3-turbo';

export interface GroqDictationRequest {
  model: string;
  /** The recording as the first multipart part. */
  file: { fieldName: 'file'; fileName: string; type: string; bytes: Uint8Array<ArrayBuffer> };
  /** Text fields appended after the file, in order. */
  fields: ReadonlyArray<readonly [string, string]>;
}

export function buildGroqDictationRequest(audio: Uint8Array): GroqDictationRequest {
  return {
    model: GROQ_DICTATION_MODEL,
    file: { fieldName: 'file', fileName: 'dictation.wav', type: 'audio/wav', bytes: new Uint8Array(audio) },
    fields: [['model', GROQ_DICTATION_MODEL], ['response_format', 'json']]
  };
}

function base64(bytes: Uint8Array): string {
  let binary = '';
  for (let start = 0; start < bytes.length; start += 0x8000) binary += String.fromCharCode(...bytes.subarray(start, start + 0x8000));
  return btoa(binary);
}

export function buildCloudflareDictationRequest(audio: Uint8Array): { model: string; body: { audio: string } } {
  return { model: CLOUDFLARE_DICTATION_MODEL, body: { audio: base64(audio) } };
}
