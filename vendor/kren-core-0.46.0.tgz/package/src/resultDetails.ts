import type {
  DictionaryEntry,
  DictionarySection,
  GrammarDialect,
  GrammarIssue,
  RewriteVariant,
  ThesaurusSection,
  ThesaurusWord
} from './contracts.js';
import { isEnglishLanguageCode, localeLanguageName } from './languages.js';
import { GRAMMAR_HARPER_SKIPPED_NOTICE, grammarNothingChecked } from './grammarInputLanguage.js';
import {
  REWRITE_DOMAINS,
  REWRITE_ENGLISH_VARIETIES,
  REWRITE_FORMALITIES,
  REWRITE_FUNCTIONS,
  REWRITE_LENGTHS,
  REWRITE_MODALITIES,
  REWRITE_PERSPECTIVES,
  REWRITE_RHETORICAL_MODES,
  REWRITE_STANCES,
  REWRITE_VOICES,
  rewriteAxisLabel,
  type RewriteAxes
} from './rewriteAxes.js';

/**
 * The plain text Open full details shows for each result kind. The input types below are plain
 * shapes with no host dependency: a host's own result objects are accepted where they carry these
 * fields, so nothing here imports an editor or document API.
 */

const languageName = localeLanguageName;

interface BaseResult {
  providerId: string;
  sourceText: string;
  sourceLanguage: string;
  targetLanguage: string;
}

export interface TranslationResult extends BaseResult {
  kind: 'translation';
  translatedText: string;
  alternatives?: string[];
  note?: string;
  modelId?: string;
  fallbackFromModel?: string;
}

export interface RewriteResult extends BaseResult, RewriteAxes {
  kind: 'rewrite';
  variants: Array<Pick<RewriteVariant, 'label' | 'text' | 'changeNote'>>;
  modelId?: string;
  fallbackFromModel?: string;
}

export interface GrammarResult extends BaseResult {
  harperSkipped?: boolean;
  kind: 'grammar';
  dialect: GrammarDialect;
  issues: Array<Pick<GrammarIssue, 'category' | 'original' | 'message'> & {
    suggestions: Array<{ label: string }>;
  }>;
}

export interface DictionaryResult extends BaseResult {
  kind: 'dictionary';
  headword: string;
  pronunciation?: string;
  entries: DictionaryEntry[];
  sections?: DictionarySection[];
  note?: string;
}

export interface ThesaurusResult extends BaseResult {
  kind: 'thesaurus';
  headword: string;
  sections: ThesaurusSection[];
  note?: string;
}

export type KrenResult =
  | TranslationResult
  | DictionaryResult
  | ThesaurusResult
  | RewriteResult
  | GrammarResult;

export type ResultDetailsInput = KrenResult;

const providerNames: Record<string, string> = {
  harper: 'Harper (offline)',
  gemini: 'Gemini',
  googleCloudTranslation: 'Google Cloud Translation',
  koreanBasicDictionary: 'Korean Basic Dictionary',
  merriamWebsterCollegiate: "Merriam-Webster's Collegiate® Dictionary",
  merriamWebsterMedical: "Merriam-Webster's Medical Dictionary",
  merriamWebsterThesaurus: "Merriam-Webster's Collegiate® Thesaurus"
};

export function resultDetails(result: KrenResult): string {
  const lines: string[] = [];

  if (result.kind === 'translation') {
    lines.push('Translation', '-----------', result.translatedText);
    if (result.modelId) lines.push('', `Model: ${result.modelId}`);
    if (result.fallbackFromModel) {
      lines.push(`Fallback: ${result.modelId} used after ${result.fallbackFromModel} could not produce a usable result.`);
    }
    if (result.alternatives?.length) {
      lines.push('', 'Alternatives', '------------', ...result.alternatives.map((item) => `- ${item}`));
    }
    if (result.note) lines.push('', 'Note', '----', result.note);
  } else if (result.kind === 'grammar') {
    lines.push(
      'Grammar Check',
      '-------------',
      `Dialect: ${grammarDialectLabel(result.dialect)}`,
      `Issues: ${result.issues.length}`
    );
    if (!result.issues.length) {
      lines.push('', grammarNothingChecked(result)
        ? GRAMMAR_HARPER_SKIPPED_NOTICE
        : 'No spelling or grammar issues found by Harper.');
    } else {
      result.issues.forEach((issue, index) => {
        lines.push('', `${index + 1}. ${issue.category}: ${issue.original || '(insertion point)'}`);
        lines.push(`   ${issue.message}`);
        issue.suggestions.forEach((suggestion) => lines.push(`   - ${suggestion.label}`));
      });
    }
  } else if (result.kind === 'dictionary') {
    lines.push(formatHeadword(result), '');
    if (result.sections?.length) {
      result.sections.forEach((section, sectionIndex) => {
        const position = result.sections!.length > 1
          ? ` (${sectionIndex + 1} of ${result.sections!.length})`
          : '';
        const partOfSpeech = section.partOfSpeech ? ` — ${section.partOfSpeech}` : '';
        lines.push(`${section.headword}${position}${partOfSpeech}`);
        if (section.pronunciation) lines.push(`Pronunciation: ${section.pronunciation}`);
        if (section.inflections?.length) lines.push(`Forms: ${section.inflections.join('; ')}`);
        section.entries.forEach((entry, entryIndex) => {
          const label = entry.grammaticalLabel ? ` [${entry.grammaticalLabel}]` : '';
          lines.push(`${entry.senseNumber ?? entryIndex + 1}. ${entry.meaning}${label}`);
          entry.examples?.forEach((example) => lines.push(`   Example: ${example}`));
        });
        section.synonymDiscussions?.forEach((discussion) => {
          lines.push('', synonymDiscussionTitle(section.headword, discussion.label));
          lines.push('Merriam-Webster editorial comparison for this sense; not a translation.');
          if (discussion.blocks?.length) {
            discussion.blocks.forEach((block) => lines.push(
              block.kind === 'example' ? `   Example: ${block.text}` : block.text
            ));
          } else {
            lines.push(discussion.text);
            discussion.examples?.forEach((example) => lines.push(`   Example: ${example}`));
          }
          if (discussion.seeAlso?.length) {
            lines.push(`   See also: ${discussion.seeAlso.join(', ')}`);
          }
        });
        lines.push('');
      });
    } else {
      result.entries.forEach((entry, index) => {
        const pos = entry.partOfSpeech ? ` (${entry.partOfSpeech})` : '';
        lines.push(`${index + 1}. ${entry.meaning}${pos}`);
        if (entry.definition) lines.push(`   ${entry.definition}`);
        entry.examples?.forEach((example) => lines.push(`   Example: ${example}`));
      });
    }
    if (result.note) lines.push('', 'Note', '----', result.note);
  } else if (result.kind === 'thesaurus') {
    lines.push(result.headword, '');
    result.sections.forEach((section, sectionIndex) => {
      const partOfSpeech = section.partOfSpeech ? ` — ${section.partOfSpeech}` : '';
      lines.push(`${section.headword}${partOfSpeech}`);
      if (section.pronunciation) lines.push(`Pronunciation: ${section.pronunciation}`);
      section.senses.forEach((sense, senseIndex) => {
        const number = sense.senseNumber ?? String(senseIndex + 1);
        if (sense.definition) lines.push(`${number}. ${sense.definition}`);
        appendThesaurusLine(lines, 'Synonyms', sense.synonyms);
        appendThesaurusLine(lines, 'Near synonyms', sense.nearSynonyms);
        appendThesaurusLine(lines, 'Related words', sense.relatedWords);
        appendThesaurusLine(lines, 'Synonymous phrases', sense.synonymousPhrases);
        appendThesaurusLine(lines, 'Antonyms', sense.antonyms);
        appendThesaurusLine(lines, 'Near antonyms', sense.nearAntonyms);
      });
      if (sectionIndex < result.sections.length - 1) lines.push('');
    });
    if (result.note) lines.push('', 'Note', '----', result.note);
  } else {
    if (result.modelId) lines.push(`Model: ${result.modelId}`);
    if (result.fallbackFromModel) {
      lines.push(`Fallback: ${result.modelId} used after ${result.fallbackFromModel} could not produce a usable result.`);
    }
    if (result.modelId || result.fallbackFromModel) lines.push('');
    lines.push(`Language: ${languageName(result.sourceLanguage)}`);
    if (isEnglishLanguageCode(result.sourceLanguage)) {
      lines.push(`English: ${rewriteEnglishVarietyLabel(result.englishVariety)}`);
    }
    lines.push(`Modality: ${rewriteAxisLabel(REWRITE_MODALITIES, result.modality)}`);
    lines.push(`Function: ${rewriteAxisLabel(REWRITE_FUNCTIONS, result.function)}`);
    lines.push(`Domain: ${rewriteDomainLabel(result.domain)}`);
    lines.push(`Formality: ${rewriteAxisLabel(REWRITE_FORMALITIES, result.formality)}`);
    lines.push(`Voice: ${rewriteAxisLabel(REWRITE_VOICES, result.voice)}`);
    lines.push(`Stance: ${rewriteAxisLabel(REWRITE_STANCES, result.stance)}`);
    lines.push(`Length: ${rewriteAxisLabel(REWRITE_LENGTHS, result.length)}`);
    lines.push(`Perspective: ${rewriteAxisLabel(REWRITE_PERSPECTIVES, result.perspective)}`);
    lines.push(`Intent: ${rewriteRhetoricalModeLabel(result.rhetoricalMode)}`, '');
    result.variants.forEach((variant, index) => {
      if (index > 0) lines.push('');
      lines.push(variant.label, '-'.repeat(variant.label.length), variant.text);
      if (variant.changeNote) lines.push('', `What changed: ${variant.changeNote}`);
    });
  }
  lines.push(
    '',
    '==============',
    `Direction: ${languageName(result.sourceLanguage)} -> ${languageName(result.targetLanguage)}`,
    `Provider: ${providerName(result.providerId)}`
  );
  if (result.providerId === 'googleCloudTranslation') {
    lines.push(
      'Powered by Google Translate: https://translate.google.com',
      'This service may contain translations powered by Google. Google disclaims warranties related to the translations, including accuracy and reliability.'
    );
  } else if (result.providerId === 'koreanBasicDictionary') {
    lines.push(
      'Source: Basic Korean Dictionary, National Institute of Korean Language (https://krdict.korean.go.kr/eng/). Text is provided under CC BY-SA.'
    );
  }
  lines.push('----------');
  return lines.join('\n');
}

export function grammarDialectLabel(dialect: GrammarResult['dialect']): string {
  if (dialect === 'british') return 'British English';
  if (dialect === 'australian') return 'Australian English';
  if (dialect === 'canadian') return 'Canadian English';
  if (dialect === 'indian') return 'Indian English';
  return 'American English';
}

function rewriteDomainLabel(value: RewriteResult['domain']): string {
  return rewriteAxisLabel(REWRITE_DOMAINS, value);
}

function rewriteEnglishVarietyLabel(value: RewriteResult['englishVariety']): string {
  return rewriteAxisLabel(REWRITE_ENGLISH_VARIETIES, value);
}

function rewriteRhetoricalModeLabel(value: RewriteResult['rhetoricalMode']): string {
  return rewriteAxisLabel(REWRITE_RHETORICAL_MODES, value);
}

function appendThesaurusLine(
  lines: string[],
  label: string,
  words: ThesaurusWord[] | undefined
): void {
  if (!words?.length) return;
  lines.push(`   ${label}: ${words.map(formatThesaurusWordText).join(', ')}`);
}

function formatThesaurusWordText(word: ThesaurusWord): string {
  return word.labels?.length ? `${word.word} (${word.labels.join(', ')})` : word.word;
}

function synonymDiscussionTitle(headword: string, label: string | undefined): string {
  return !label || /^synonyms?$/iu.test(label.trim())
    ? `Choose the Right Synonym for ${headword}`
    : label;
}

function formatHeadword(result: DictionaryResult): string {
  return result.pronunciation
    ? `${result.headword} [${result.pronunciation}]`
    : result.headword;
}

function providerName(providerId: string): string {
  return providerNames[providerId] ?? providerId;
}
