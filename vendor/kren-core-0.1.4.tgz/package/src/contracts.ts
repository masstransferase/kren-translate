export type LanguageCode = string;
export type LanguageModelProviderId = 'gemini' | 'openai' | 'anthropic';
export type LanguageModelEffort = 'auto' | 'low' | 'medium' | 'high';

export type RewriteDomain = 'general' | 'academic' | 'technical' | 'business' | 'email';
export type RewriteEnglishVariety =
  | 'american'
  | 'british'
  | 'australian'
  | 'canadian'
  | 'indian'
  | 'international';
export type RewriteTone =
  | 'preserveVoice'
  | 'neutral'
  | 'professional'
  | 'warm'
  | 'assertive'
  | 'cautious'
  | 'diplomatic'
  | 'formal'
  | 'direct'
  | 'plainLanguage';
export type RewriteRhetoricalMode =
  | 'preserveOriginal'
  | 'explain'
  | 'persuade'
  | 'recommend'
  | 'constructivelyChallenge';
export type RewriteVariantId = 'natural' | 'concise' | 'jargonFree';

export interface RewriteVariant {
  id: RewriteVariantId;
  label: string;
  text: string;
  changeNote?: string;
}

export type GrammarDialect = 'american' | 'british' | 'australian' | 'canadian' | 'indian';
export type GrammarSuggestionKind = 'replace' | 'remove' | 'insertAfter';

export interface GrammarSuggestion {
  kind: GrammarSuggestionKind;
  replacement: string;
  label: string;
}

export interface GrammarIssue {
  id: string;
  start: number;
  end: number;
  original: string;
  category: string;
  message: string;
  suggestions: GrammarSuggestion[];
  ignoreHash?: string;
}

export interface GrammarChoice {
  issueId: string;
  suggestionIndex: number;
}

export interface GrammarSource {
  sourceText: string;
  issues: GrammarIssue[];
}

export interface DictionaryEntry {
  senseNumber?: string;
  grammaticalLabel?: string;
  partOfSpeech?: string;
  meaning: string;
  definition?: string;
  examples?: string[];
}

export interface DictionaryDiscussionBlock {
  kind: 'text' | 'example';
  text: string;
}

export interface DictionaryDiscussion {
  label?: string;
  text: string;
  examples?: string[];
  seeAlso?: string[];
  blocks?: DictionaryDiscussionBlock[];
}

export interface DictionarySection {
  headword: string;
  homograph?: number;
  partOfSpeech?: string;
  pronunciation?: string;
  audioUrl?: string;
  inflections?: string[];
  entries: DictionaryEntry[];
  synonymDiscussions?: DictionaryDiscussion[];
}

export interface ThesaurusWord {
  word: string;
  labels?: string[];
}

export interface ThesaurusSense {
  senseNumber?: string;
  definition?: string;
  synonyms: ThesaurusWord[];
  nearSynonyms?: ThesaurusWord[];
  relatedWords?: ThesaurusWord[];
  synonymousPhrases?: ThesaurusWord[];
  antonyms?: ThesaurusWord[];
  nearAntonyms?: ThesaurusWord[];
}

export interface ThesaurusSection {
  headword: string;
  partOfSpeech?: string;
  pronunciation?: string;
  audioUrl?: string;
  senses: ThesaurusSense[];
}
