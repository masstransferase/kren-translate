const ENGLISH_EXPRESSION_TOKEN =
  "[\\p{Script=Latin}\\p{M}][\\p{Script=Latin}\\p{M}'\u2019.-]*";
const ENGLISH_EXPRESSION_PATTERN = new RegExp(
  `^${ENGLISH_EXPRESSION_TOKEN}(?:\\s+${ENGLISH_EXPRESSION_TOKEN}){0,7}$`,
  'u'
);

export function isPlausibleLanguageCode(value: string): boolean {
  return /^[a-z]{2,3}(?:-[A-Za-z]{2,8})?$/u.test(value.trim());
}

export function isEnglishDictionaryQuery(text: string): boolean {
  return ENGLISH_EXPRESSION_PATTERN.test(text.trim());
}

export function isMultiWordEnglishQuery(text: string): boolean {
  return isEnglishDictionaryQuery(text) && text.trim().split(/\s+/u).length > 1;
}

export function containsLatinScript(text: string): boolean {
  return /\p{Script=Latin}/u.test(text);
}
