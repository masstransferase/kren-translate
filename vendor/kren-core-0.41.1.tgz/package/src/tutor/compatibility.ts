import { CEFR_LEVELS, type TrainingTargetSelection, type TutorFinding } from './contract.js';
import { TUTOR_MAP, type TrainingMapNode } from './map.js';

export const TUTOR_COMPATIBILITY_CODES = {
  recordedConflict: 'compatibility.recordedConflict',
  levelRangeMismatch: 'compatibility.levelRangeMismatch',
  modalityMismatch: 'compatibility.modalityMismatch'
} as const;

export const TUTOR_COMPATIBILITY_STATUSES = ['compatible', 'warning', 'conflict'] as const;
export const isTutorCompatibilityStatus = (
  value: unknown
): value is TutorCompatibilityResult['status'] =>
  typeof value === 'string' &&
  TUTOR_COMPATIBILITY_STATUSES.some((candidate) => candidate === value);

export interface TutorCompatibilityResult {
  status: typeof TUTOR_COMPATIBILITY_STATUSES[number];
  subjects: string[];
  findings: TutorFinding[];
}

export function assessTutorCompatibility(
  selection: readonly TrainingTargetSelection[],
  map: readonly TrainingMapNode[] = TUTOR_MAP
): TutorCompatibilityResult {
  const nodesById = new Map(map.map((candidate) => [candidate.id, candidate]));
  const nodes = selection
    .map((target) => nodesById.get(target.nodeId))
    .filter((target): target is TrainingMapNode => target !== undefined);
  const findings: TutorFinding[] = [];

  for (let firstIndex = 0; firstIndex < nodes.length; firstIndex += 1) {
    const first = nodes[firstIndex]!;
    for (let secondIndex = firstIndex + 1; secondIndex < nodes.length; secondIndex += 1) {
      const second = nodes[secondIndex]!;
      const subjects = [first.id, second.id];
      if (first.conflicts.includes(second.id) || second.conflicts.includes(first.id)) {
        findings.push({
          code: TUTOR_COMPATIBILITY_CODES.recordedConflict,
          severity: 'error',
          subjects
        });
        continue;
      }
      if (!levelRangesOverlap(first, second)) {
        findings.push({
          code: TUTOR_COMPATIBILITY_CODES.levelRangeMismatch,
          severity: 'warning',
          subjects
        });
      }
      if (!first.modalities.some((modality) => second.modalities.includes(modality))) {
        findings.push({
          code: TUTOR_COMPATIBILITY_CODES.modalityMismatch,
          severity: 'warning',
          subjects
        });
      }
    }
  }

  const status = findings.some((finding) => finding.code === TUTOR_COMPATIBILITY_CODES.recordedConflict)
    ? 'conflict'
    : findings.length > 0 ? 'warning' : 'compatible';
  return {
    status,
    subjects: [...new Set(findings.flatMap((finding) => finding.subjects))],
    findings
  };
}

function levelRangesOverlap(first: TrainingMapNode, second: TrainingMapNode): boolean {
  const firstMinimum = CEFR_LEVELS.indexOf(first.levelRange.minimum);
  const firstMaximum = CEFR_LEVELS.indexOf(first.levelRange.maximum);
  const secondMinimum = CEFR_LEVELS.indexOf(second.levelRange.minimum);
  const secondMaximum = CEFR_LEVELS.indexOf(second.levelRange.maximum);
  return firstMinimum <= secondMaximum && secondMinimum <= firstMaximum;
}
