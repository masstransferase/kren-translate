import type {
  ResolvedTrainingTarget, TrainingExample, TutorFinding, TutorLesson, TutorRecipe
} from './contract.js';
import { TUTOR_MAP, type TrainingMapNode } from './map.js';

/** How many of a lesson's examples may annotate one phrase before it stops teaching a pattern. */
export const EXAMPLE_PHRASE_LIMIT = 2;

export const TUTOR_LESSON_CODES = {
  requiredFieldMissing: 'lesson.requiredFieldMissing',
  schemaVersionMismatch: 'lesson.schemaVersionMismatch',
  mapVersionMismatch: 'lesson.mapVersionMismatch',
  rulesMissing: 'lesson.rulesMissing',
  exampleCountMismatch: 'lesson.exampleCountMismatch',
  primaryTargetMissing: 'lesson.primaryTargetMissing',
  supportTargetUnderused: 'lesson.supportTargetUnderused',
  examplePhraseRepeated: 'lesson.examplePhraseRepeated',
  patternStatementMissing: 'lesson.patternStatementMissing',
  annotationExcerptMissing: 'lesson.annotationExcerptMissing',
  answerKeyMissing: 'lesson.answerKeyMissing',
  wordCountBelowMinimum: 'lesson.wordCountBelowMinimum',
  wordCountAboveMaximum: 'lesson.wordCountAboveMaximum',
  /*
   * Explore, from blueprint section 2.1: selecting a Hub or a Cluster means KREN chooses
   * an eligible child beneath it and teaches that child. These three codes separate the
   * three ways a returned lesson can fail to honour that, because they need different
   * fixes: the model ignored the choice, made one outside the parent, or claimed one it
   * was never offered.
   */
  exploreChoiceMissing: 'lesson.exploreChoiceMissing',
  exploreChoiceOutsideParent: 'lesson.exploreChoiceOutsideParent',
  exploreChoiceUnexpected: 'lesson.exploreChoiceUnexpected'
} as const;

export function validateTutorLesson(
  lesson: TutorLesson,
  recipe: TutorRecipe,
  map: readonly TrainingMapNode[] = TUTOR_MAP
): TutorFinding[] {
  const findings: TutorFinding[] = [];
  const value = lesson as unknown as Record<string, unknown>;
  const requiredFields = [
    'lessonTitle', 'level', 'primaryTarget', 'supportingTargets', 'conceptExplanation',
    'interactionExplanation', 'rules', 'examples', 'commonErrors', 'generationNotes'
  ];
  for (const field of requiredFields) {
    if (!Object.hasOwn(value, field)) {
      findings.push({
        ...error(TUTOR_LESSON_CODES.requiredFieldMissing, []),
        detail: { field }
      });
    }
  }
  if (lesson.schemaVersion !== 1) {
    findings.push(error(TUTOR_LESSON_CODES.schemaVersionMismatch, []));
  }
  if (lesson.mapVersion !== recipe.mapVersion) {
    findings.push(error(TUTOR_LESSON_CODES.mapVersionMismatch, []));
  }
  if (!Array.isArray(lesson.rules) || lesson.rules.length === 0) {
    findings.push(error(TUTOR_LESSON_CODES.rulesMissing, []));
  }

  const examples = Array.isArray(lesson.examples) ? lesson.examples : [];
  if (examples.length !== recipe.output.exampleCount) {
    findings.push({
      ...error(TUTOR_LESSON_CODES.exampleCountMismatch, examples.map((example) => example.id)),
      detail: { actual: examples.length, requested: recipe.output.exampleCount }
    });
  }

  /*
   * Under Explore the recipe names a parent and the lesson teaches a child, so the identifier
   * an example has to carry is the child's. Requiring the parent here is what made an Explore
   * lesson unvalidatable, and accepting either would let a model return the parent and teach
   * nothing in particular, which is the behaviour this exists to prevent.
   */
  /*
   * A question-only recipe names no target, so there is nothing to check the lesson's own
   * choice against. What the model returned becomes the taught target, and the checks that
   * compare it to a requested identifier are skipped rather than made to pass: a recipe with
   * no request cannot have its request violated.
   */
  /*
   * Every requested primary obliges every example, so this is a list rather than a value.
   *
   * The model names one subject in `lesson.primaryTarget`, and the first requested primary
   * is the one that answer is checked against, because Explore lets it return a child of a
   * hub and only the identifier it was asked about can decide whether it did. The rest are
   * taken as requested: nothing in the response names them individually, and inventing an
   * answer to check would be checking KREN's own guess.
   */
  const requestedPrimaries = recipe.primaryTargets ?? [];
  const leading = requestedPrimaries[0];
  const taughtTargets = leading === undefined
    ? [lesson.primaryTarget.nodeId]
    : exploreChoice(lesson.primaryTarget, leading, map)
      ? [lesson.primaryTarget.nodeId, ...requestedPrimaries.slice(1)]
      : requestedPrimaries;
  if (leading !== undefined) {
    findings.push(...validateChoice(lesson.primaryTarget, leading, map));
  }
  for (const [index, supportTarget] of (lesson.supportingTargets ?? []).entries()) {
    const requested = recipe.supportingTargets[index];
    if (requested !== undefined) {
      findings.push(...validateChoice(supportTarget, requested, map));
    }
  }

  /*
   * Every field an example is read for is checked before it is read.
   *
   * This function judges a language model's output, so its input is untrusted by
   * construction and a missing field is an ordinary result rather than an exceptional one.
   * It used to assume each example carried `sentence`, `targetIds`, and `annotations`, and
   * a model that omitted `annotations` on one example threw `example.annotations is not
   * iterable` from inside here. The one consumer wrapped the call in a try and reported
   * "received a malformed lesson", discarding the error, so the reader saw a message with
   * no cause and the same message however the response was wrong.
   *
   * A finding says which example and which field. An exception says nothing and loses the
   * other findings that would have been collected.
   */
  for (const example of examples) {
    const malformed = malformedExampleFields(example);
    if (malformed.length > 0) {
      for (const field of malformed) {
        findings.push({
          ...error(TUTOR_LESSON_CODES.requiredFieldMissing, [exampleId(example)]),
          detail: { field: `examples.${field}` }
        });
      }
      continue;
    }
    validateWordCount(example, recipe, findings);
    if (recipe.output.lessonMode !== 'contrast') {
      for (const taughtTarget of taughtTargets) {
        if (!example.targetIds.includes(taughtTarget)) {
          findings.push(error(
            TUTOR_LESSON_CODES.primaryTargetMissing, [example.id, taughtTarget]
          ));
        }
      }
    }
    for (const annotation of example.annotations) {
      if (typeof annotation?.excerpt !== 'string' ||
          annotation.excerpt.length === 0 ||
          !example.sentence.includes(annotation.excerpt)) {
        findings.push(error(
          TUTOR_LESSON_CODES.annotationExcerptMissing,
          [example.id, annotation?.targetId ?? '']
        ));
      }
    }
  }

  for (const supportId of recipe.supportingTargets) {
    const appearances = examples.filter(
      (example) => Array.isArray(example?.targetIds) && example.targetIds.includes(supportId)
    ).length;
    if (appearances < 2) {
      findings.push({
        ...error(TUTOR_LESSON_CODES.supportTargetUnderused, [supportId]),
        detail: { actual: appearances, required: 2 }
      });
    }
  }
  /*
   * Six examples must show the target's range, not one instance of it six times.
   *
   * A reader wrote `native tongues` once. The lesson KREN drafted for "False friends and
   * commonly confused words" annotated `native speakers` in four of its six examples, and
   * every check here passed, because each example did carry the Primary target and each
   * excerpt did occur in its sentence. The lesson taught one correction the reader already
   * had from the report, and none of the rest of the target.
   *
   * The excerpt is what the annotation points the reader at, so it is what repeats. Two is
   * deliberate rather than one: the reader's own mistake is worth teaching, and a pattern
   * shown twice is a pattern. Three is a lesson that has stopped covering its target.
   */
  const excerptExamples = new Map<string, Set<string>>();
  for (const example of lesson.examples) {
    if (!example || typeof example !== 'object') continue;
    for (const annotation of example.annotations ?? []) {
      if (!annotation || typeof annotation.excerpt !== 'string') continue;
      const phrase = annotation.excerpt.trim().toLowerCase();
      if (!phrase) continue;
      const seen = excerptExamples.get(phrase) ?? new Set<string>();
      seen.add(example.id);
      excerptExamples.set(phrase, seen);
    }
  }
  for (const [phrase, examples] of excerptExamples) {
    if (examples.size > EXAMPLE_PHRASE_LIMIT) {
      findings.push({
        ...error(TUTOR_LESSON_CODES.examplePhraseRepeated, [phrase]),
        detail: { phrase, actual: examples.size, allowed: EXAMPLE_PHRASE_LIMIT,
          total: lesson.examples.length }
      });
    }
  }
  /*
   * A warning, not an error. The reader sees one example at a time, so this sentence is what
   * carries the pattern. Its absence loses that line without invalidating the whole lesson.
   */
  if (typeof lesson.patternStatement !== 'string' || !lesson.patternStatement.trim()) {
    findings.push({ ...error(TUTOR_LESSON_CODES.patternStatementMissing, []), severity: 'warning' });
  }
  if (recipe.output.includeAnswerKey && lesson.answerKey === undefined) {
    findings.push(error(TUTOR_LESSON_CODES.answerKeyMissing, []));
  }
  return findings;
}

export function tutorLessonIsValid(findings: readonly TutorFinding[]): boolean {
  return findings.every((finding) => finding.severity !== 'error');
}

export function countTutorSentenceWords(sentence: string): number {
  const trimmed = sentence.trim();
  return trimmed === '' ? 0 : trimmed.split(/\s+/u).length;
}

function validateWordCount(
  example: TrainingExample,
  recipe: TutorRecipe,
  findings: TutorFinding[]
): void {
  const actualWordCount = countTutorSentenceWords(example.sentence);
  const { minimumWords, maximumWords, tolerance } = recipe.output.sentenceLength;
  if (actualWordCount >= minimumWords && actualWordCount <= maximumWords) return;

  const missedBound = actualWordCount < minimumWords ? 'minimum' : 'maximum';
  const requestedBound = missedBound === 'minimum' ? minimumWords : maximumWords;
  const insideWidened = actualWordCount >= minimumWords - tolerance &&
    actualWordCount <= maximumWords + tolerance;
  findings.push({
    code: missedBound === 'minimum'
      ? TUTOR_LESSON_CODES.wordCountBelowMinimum
      : TUTOR_LESSON_CODES.wordCountAboveMaximum,
    severity: insideWidened ? 'warning' : 'error',
    subjects: [example.id],
    detail: { actualWordCount, missedBound, requestedBound }
  });
}

/*
 * Explore is decided by kind, not by whether a node happens to have children. Blueprint
 * section 2.1: a Hub or a Cluster means Explore, a Skill or a Micro-target means Exact.
 *
 * Reading it as "has children" is wrong and was caught here by an existing fixture: the
 * skill `mechanics.time-reality.tense-aspect` carries micro-targets beneath it, so every
 * lesson already generated for it would have been rejected for not choosing one.
 */
function isExploreLevel(nodeId: string, map: readonly TrainingMapNode[]): boolean {
  const kind = map.find((node) => node.id === nodeId)?.kind;
  return kind === 'hub' || kind === 'cluster';
}

function isDescendant(
  nodeId: string,
  ancestorId: string,
  map: readonly TrainingMapNode[]
): boolean {
  const byId = new Map(map.map((node) => [node.id, node]));
  const seen = new Set<string>();
  let current = byId.get(nodeId)?.parentId;
  while (current !== undefined && !seen.has(current)) {
    if (current === ancestorId) return true;
    seen.add(current);
    current = byId.get(current)?.parentId;
  }
  return false;
}

// True only for a well-formed Explore choice, which is what decides the identifier an
// example must carry. A malformed one is reported by validateChoice and is not honoured here.
function exploreChoice(
  resolved: ResolvedTrainingTarget | undefined,
  requestedId: string,
  map: readonly TrainingMapNode[]
): boolean {
  return isExploreLevel(requestedId, map) &&
    resolved?.chosenUnder === requestedId &&
    isDescendant(resolved.nodeId, requestedId, map);
}

function validateChoice(
  resolved: ResolvedTrainingTarget | undefined,
  requestedId: string,
  map: readonly TrainingMapNode[]
): TutorFinding[] {
  if (!resolved) return [];
  if (!isExploreLevel(requestedId, map)) {
    return resolved.chosenUnder === undefined
      ? []
      : [error(TUTOR_LESSON_CODES.exploreChoiceUnexpected, [resolved.nodeId, requestedId])];
  }
  if (resolved.chosenUnder !== requestedId) {
    return [error(TUTOR_LESSON_CODES.exploreChoiceMissing, [requestedId])];
  }
  return isDescendant(resolved.nodeId, requestedId, map)
    ? []
    : [error(TUTOR_LESSON_CODES.exploreChoiceOutsideParent, [resolved.nodeId, requestedId])];
}

// Named so a finding can say which example, even when the example has no usable id.
function exampleId(example: TrainingExample | undefined): string {
  return typeof example?.id === 'string' && example.id.length > 0 ? example.id : 'unknown';
}

function malformedExampleFields(example: TrainingExample | undefined): string[] {
  if (example === null || typeof example !== 'object') return ['example'];
  const missing: string[] = [];
  if (typeof example.sentence !== 'string') missing.push('sentence');
  if (!Array.isArray(example.targetIds)) missing.push('targetIds');
  if (!Array.isArray(example.annotations)) missing.push('annotations');
  return missing;
}

function error(code: string, subjects: string[]): TutorFinding {
  return { code, severity: 'error', subjects };
}
