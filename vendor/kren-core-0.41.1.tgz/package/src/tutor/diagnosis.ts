/**
 * Diagnosing a reader's English, shared by every host.
 *
 * This module holds the parts of a diagnosis that are the same wherever it runs: the
 * protocol a model is told to follow, the shape a report comes back in, and the validation
 * that decides what of that report a reader is allowed to see. What differs per host is how
 * a report is displayed and what the reader does next, and none of that is here.
 *
 * Hosts read `TUTOR_DIAGNOSTIC_PROTOCOL` from this module rather than maintaining separate
 * copies, so a protocol change applies consistently.
 *
 * `tutorDiagnosticReport` is the guarantee behind the protocol's requests. An instruction
 * asking a model to quote the reader exactly is a request; dropping any finding whose
 * evidence is not in the source is what makes it true. An invented quotation is worse than a
 * missing finding, because the reader reads it as something they wrote.
 */

import { findTrainingMapNode } from './map.js';
import type { TrainingTargetSelection } from './contract.js';

export const TUTOR_PASSAGE_ANALYSIS_CHOICES = [
  'Weakness analysis',
  'Text analysis'
] as const;

export type TutorPassageAnalysis = typeof TUTOR_PASSAGE_ANALYSIS_CHOICES[number];

export interface TutorDiagnosticFinding {
  level: number;
  observation: string;
  evidence: string;
  correction?: string;
  targetId?: string;
  turnCount?: number;
}

/** Feedback from reader-authored words, independent of the activity that supplied them. */
/**
 * English that is already correct, and a more natural way to say it.
 *
 * Separate from `findings` because accuracy and naturalness have independent caps, so
 * corrections cannot consume the slots available for naturalness suggestions.
 *
 * `evidence` is verified against the reader's own words exactly as a finding's is, so a
 * suggestion about a phrase nobody wrote is dropped rather than shown.
 */
export interface TutorPolishSuggestion {
  evidence: string;
  suggestion: string;
  reason: string;
  targetId?: string;
}

export interface TutorDiagnosticReport {
  protocolVersion?: 1;
  summary?: string;
  findings: TutorDiagnosticFinding[];
  /*
   * Optional in the type and always set by the validator, exactly as `protocolVersion`
   * is. Requiring it would oblige every existing report fixture in both hosts to carry
   * an empty array, and a field a consumer must remember to add is a worse guarantee
   * than one the producer always writes.
   */
  polish?: TutorPolishSuggestion[];
  focus?: string;
  targets: TrainingTargetSelection[];
}

export const TUTOR_DIAGNOSTIC_PROTOCOL = `Diagnostic protocol v1.

Sweep the material one learning-map hub at a time, in this order, and report nothing
outside them: Mechanics, Lexical, Formulaic, Pragmatics, Auditory. Skip Auditory for
written material; saying nothing about it is correct.

File each finding at the most specific map node covering it, copying the identifier
exactly from the map below. A finding with no honest target keeps none.

A spelling or typing slip is corrected and listed like any other finding, and it never
carries a targetId. It is a keystroke, not a gap in the reader's English, so it never
proposes a target and never becomes the primary. When more findings qualify than fit,
report slips last and drop them first.

Report a finding only at these levels, most severe first: 1, blocks meaning; 2, wrong
but understandable. A finding is always an error. English that is already correct is
never a finding, however unidiomatic or clumsy it sounds; it is a polish suggestion.
Never report a difference that is only preference.

Return separately zero to three polish suggestions about English that is already
correct, which includes wording that is grammatical but unidiomatic, clumsy, or not
what a native speaker would choose. Each carries evidence, a phrase copied exactly from the reader's own words as a
finding's evidence is; suggestion, a more natural way to say that phrase; reason, one
sentence saying why it is more natural; and optionally a targetId. Omit a suggestion
rather than inventing one, and never suggest a rewrite that changes nothing. Polish is
not a finding and never takes a finding's place, and it does not compete for a finding's
slot. A polish suggestion's targetId may be proposed as the primary target, including
when no finding qualifies. What a lesson teaches next is chosen from the largest gap
between the reader's English and what a native writer would have chosen here, and that
gap is often naturalness rather than error.

Each finding carries an observation, one sentence addressed to the reader naming the
pattern rather than the instance; evidence, a phrase copied exactly from the reader's own
words, never paraphrased, corrected or tidied; and optionally a targetId.

An optional correction rewrites the quoted evidence as it should be. Include it only
when that evidence needs correcting. Omit it for correct Text analysis demonstrations.
Never invent a correction to fill the field.

Return zero to five findings. An empty list is correct when nothing qualifies. Do not
fill the list.

The writing has a stated situation and purpose: its domain, its function, the modality it
is written or spoken in, the formality it calls for, and the reader's level. Judge naturalness
against those and not against English in general. There is no single natural English, so a
suggestion that would improve a note to a colleague can spoil a paper abstract, and one that
suits neither is preference rather than naturalness. Say in each suggestion's reason which of
those it answers to. Where a constraint is absent, judge only what the material itself
settles, and do not assume one.

The summary is two or three plain sentences addressed to the reader. The focus paragraph
names one thing a lesson should work on next.`;

/*
 * Correcting in a conversation is a conversational move, not a verdict printed beside a turn.
 *
 * A recast may be silent, so an answer that works does not have to be marked as working.
 * A reply uses ordinary reactions, including fillers, rather than an assessment.
 *
 * The four moves below are ordinary second-language teaching practice. A clarification
 * request is used when meaning failed, because asking what someone meant is what a listener
 * genuinely does and it makes the learner repair their own sentence. A recast is used when
 * meaning arrived, because reflecting the sentence back correctly teaches without stopping
 * the exchange. Neither announces itself as teaching.
 */
export const TUTOR_CORRECTION_CLAUSE = `When the answer is natural and grammatical, copy it into correction exactly. Stylistic
preference is not a correction.

Reply as a person would, teaching inside the reply. One move only.

Meaning failed: ask what they meant, about the part that failed, without supplying it.

Meaning clear, English wrong: answer them, using the right wording naturally. Do not label
it or quote theirs back.

Nothing wrong: react as a person does. A filler or a follow-up is a complete reply, and
marking a working answer as working is not.

Say nothing about the language when saying something would interrupt more than it teaches.`;

/** Naturalness is capped separately from accuracy, which is the whole point of it. */
const POLISH_LIMIT = 3;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

/**
 * The roles a model chose, keeping only identifiers that are really in the map.
 *
 * A model will invent a plausible identifier, and an invented one that reaches a recipe
 * fails much later inside lesson validation as an error about a target nobody chose. So the
 * map is the authority on what exists and this function is where that is enforced.
 *
 * The limits are the selection's own: one primary and at most three supports. A response
 * naming two primaries keeps the first and demotes the rest, because refusing the whole
 * answer over an ordering mistake would send the reader back to an empty panel.
 */
export function tutorTargetSearchSelection(value: unknown): TrainingTargetSelection[] {
  if (!isRecord(value) || !Array.isArray(value.targets)) return [];
  const selection: TrainingTargetSelection[] = [];
  const seen = new Set<string>();
  let hasPrimary = false;
  for (const candidate of value.targets) {
    if (!isRecord(candidate) || typeof candidate.targetId !== 'string') continue;
    const nodeId = candidate.targetId.trim();
    if (!nodeId || seen.has(nodeId) || !findTrainingMapNode(nodeId)) continue;
    const wantsPrimary = candidate.role === 'primary' && !hasPrimary;
    if (!wantsPrimary && selection.filter((target) => target.role === 'support').length >= 3) {
      continue;
    }
    seen.add(nodeId);
    if (wantsPrimary) hasPrimary = true;
    selection.push({ nodeId, role: wantsPrimary ? 'primary' : 'support' });
  }
  return selection;
}

/** Keep valid report parts independently; evidence must occur verbatim in reader-authored words. */
export function tutorDiagnosticReport(
  value: unknown,
  readerWords: string | readonly string[],
  learnerLevel: string = 'Auto',
  analysis: TutorPassageAnalysis = 'Weakness analysis'
): TutorDiagnosticReport {
  const report: TutorDiagnosticReport = { targets: tutorTargetSearchSelection(value), findings: [], polish: [], protocolVersion: 1 };
  const normalise = (text: string): string => text.trim().replace(/\s+/gu, ' ')
    .replace(/[\u2018\u2019]/gu, "'").replace(/[\u201c\u201d]/gu, '"');
  // Keep answers separate so a quotation cannot cross a turn boundary.
  const sourceWords = (typeof readerWords === 'string' ? [readerWords] : readerWords).map(normalise);
  if (!isRecord(value)) return report;
  for (const field of ['summary', 'focus'] as const) {
    const text = value[field];
    if (typeof text === 'string' && text.trim()) report[field] = text.trim();
  }
  if (!Array.isArray(value.findings)) return report;
  for (const candidate of value.findings) {
    if (!isRecord(candidate)) continue;
    const targetId = typeof candidate.targetId === 'string' ? candidate.targetId.trim() : '';
    /*
     * Findings represent errors at levels 1 and 2. Higher levels belong to an older protocol
     * and are dropped so naturalness suggestions remain in the separate polish collection.
     */
    if (typeof candidate.level !== 'number' || !Number.isInteger(candidate.level) ||
        candidate.level < 1 || candidate.level > 2 ||
        typeof candidate.observation !== 'string' || !candidate.observation.trim() ||
        typeof candidate.evidence !== 'string' || !candidate.evidence.trim() ||
        !sourceWords.some((words) => words.includes(normalise(candidate.evidence as string)))) continue;
    const turnCount = Array.isArray(readerWords) && typeof candidate.turnCount === 'number' &&
      Number.isInteger(candidate.turnCount) && candidate.turnCount >= 1 && candidate.turnCount <= readerWords.length
      ? candidate.turnCount : undefined;
    report.findings.push({
      level: candidate.level,
      observation: candidate.observation.trim(),
      evidence: candidate.evidence,
      ...(typeof candidate.correction === 'string' &&
        candidate.correction.trim() && normalise(candidate.correction) !== normalise(candidate.evidence)
        ? { correction: candidate.correction.trim() } : {}),
      ...(turnCount === undefined ? {} : { turnCount }),
      ...(targetId && findTrainingMapNode(targetId) ? { targetId } : {})
    });
  }
  report.findings.sort((left, right) =>
    (Array.isArray(readerWords) ? (right.turnCount ?? 1) - (left.turnCount ?? 1) : 0) ||
    (Array.isArray(readerWords) || analysis === 'Weakness analysis' ? left.level - right.level : 0));
  report.findings = report.findings.slice(0, 5);
  // Polish reaches every learner level under its own cap, independent of accuracy findings.
  if (Array.isArray(value.polish)) {
    for (const candidate of value.polish) {
      if (!isRecord(candidate)) continue;
      const evidence = typeof candidate.evidence === 'string' ? candidate.evidence : '';
      const suggestion = typeof candidate.suggestion === 'string' ? candidate.suggestion.trim() : '';
      const reason = typeof candidate.reason === 'string' ? candidate.reason.trim() : '';
      if (!evidence.trim() || !suggestion || !reason) continue;
      // The same check a finding's evidence faces. A suggestion about words nobody wrote is
      // worse than no suggestion, because the reader reads it as something they wrote.
      if (!sourceWords.some((words) => words.includes(normalise(evidence)))) continue;
      // A suggestion that changes nothing is not a suggestion.
      if (normalise(suggestion) === normalise(evidence)) continue;
      const targetId = typeof candidate.targetId === 'string' ? candidate.targetId.trim() : '';
      report.polish!.push({
        evidence,
        suggestion,
        reason,
        ...(targetId && findTrainingMapNode(targetId) ? { targetId } : {})
      });
      if (report.polish!.length === POLISH_LIMIT) break;
    }
  }
  return report;
}
