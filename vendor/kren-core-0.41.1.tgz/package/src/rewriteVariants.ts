import type { RewriteVariantId } from './contracts.js';

/**
 * The two rewrite variants differ in whether style settings apply. Minimal corrects
 * phrasing without applying axes; Full uses the axes supplied by the caller.
 */
/**
 * Shared correction policy for Minimal Rewrite and Smart Grammar Check. One returns a
 * corrected draft; the other presents corrections as individually acceptable findings.
 * Both minimize changes subject to native phrasing, so restraint cannot hide an error.
 */
export const MINIMAL_CORRECTION_POLICY = [
  'find the smallest set of changes that makes the text',
  'native-speaker-grade in the detected language, and apply exactly that set.',
  'Treat this as a constrained minimization rather than a preference.',
  'The constraint is that every phrase in the result is one a native speaker would produce.',
  'The quantity you minimize is the number of the writer\'s phrases you change.',
  'Changing nothing fails the constraint wherever a phrase is not native, and changing a',
  'phrase that already satisfies the constraint is not minimal. Both are wrong answers.',
  'When every phrase in the input is already one a native speaker would produce, the empty',
  'set of changes is the correct answer, and you return the text unchanged.',
  'Word choice is the level you work at here. Work phrase by phrase, and for each phrase',
  'ask whether a native speaker would produce it. If they would not, change that phrase.',
  'If they would, keep the writer\'s phrase, even where you would have written something else.',
  'Never change wording you would merely have chosen differently: where a native speaker',
  'would use either phrasing, the writer\'s phrasing is correct and stays.',
  'Correcting one phrase is not a licence to revise the phrases around it, and a sentence',
  'containing one error is not thereby open for rewriting.',
  'When you genuinely cannot decide whether a native speaker would produce a phrase, change it.',
  'Keep the sentence order, the paragraph structure, the point of view, and the level of',
  'detail. Do not restructure a sentence, do not merge or split sentences, do not shorten',
  'or expand, and do not apply any style setting.',
  'Add nothing the writer did not state, including a possessive or a relationship the',
  'original left open.',
  'The result should still sound like the writer, and keeping their sentence order and',
  'their level of detail is what achieves that; it is not a reason to keep a word a native',
  'speaker would not have used.'
].join(' ');

export const REWRITE_VARIANTS = [
  {
    id: 'minimal',
    label: 'Minimal Rewrite',
    /**
     * Minimal correction works phrase by phrase. Correct unnatural wording while keeping
     * natural phrases, sentence structure, and relationships the writer actually stated.
     * REWRITE_WORKED_EXAMPLE demonstrates both making a change and stopping after it.
     */
    instruction: `Minimal Rewrite: ${MINIMAL_CORRECTION_POLICY}`
  },
  {
    id: 'full',
    label: 'Full Rewrite',
    /**
     * The caller appends the axis instructions because the settings define this variant.
     * REWRITE_OUTPUT_RULES supplies the native-phrasing requirement to both variants.
     */
    instruction: [
      'Full Rewrite: rewrite the text to satisfy the style settings that follow,',
      'in the detected language, preserving every claim, qualification, number, and citation.',
      'Restructuring a sentence is expected wherever a setting calls for it.',
      'Where no setting calls for a change, do not restructure for its own sake, and never',
      'make the text longer, more roundabout, or more formal than the original.',
      'Where two rewrites would both satisfy the settings, choose the one that changes less',
      'of the writer\'s text.'
    ].join(' ')
  }
] as const satisfies readonly { id: RewriteVariantId; label: string; instruction: string }[];

export const REWRITE_VARIANT_IDS: readonly RewriteVariantId[] =
  REWRITE_VARIANTS.map((variant) => variant.id);

export function rewriteVariantLabel(id: RewriteVariantId): string {
  return REWRITE_VARIANTS.find((variant) => variant.id === id)?.label ?? id;
}

/**
 * Shared output rules prohibit adding jargon or decorative language while preserving
 * precise domain terms. Both variants and every mode require native phrasing, including
 * corrections to grammatical text whose collocation or register is unnatural.
 */
/**
 * Place this rule first in the request because instruction order establishes priority.
 * Preservation and style rules constrain the correction without excusing unnatural phrasing.
 */
export const REWRITE_PRIORITY_RULE = [
  'Your first priority is natural, native-speaker-grade phrasing in the detected language.',
  'Every other instruction below constrains how you achieve that. None of them is a reason',
  'to leave unnatural phrasing in place.'
].join(' ');

/**
 * Worked examples demonstrate correcting unnatural phrasing in grammatical text and
 * stopping once the required correction has been made.
 */
export const REWRITE_WORKED_EXAMPLE = [
  'Worked example one. The input contains no grammatical error and both variants must still change it:',
  'Input: I played with my friends last weekend.',
  'Minimal Rewrite: I hung out with my friends last weekend.',
  'Full Rewrite: I spent time with my friends last weekend.',
  'Returning the input unchanged would be wrong, because an adult English speaker does not play with friends.',
  'Worked example two. The input contains one error, and Minimal Rewrite corrects that error and nothing else:',
  'Input: Although he worked very hard to finish the project on time, but the manager still criticized him.',
  'Minimal Rewrite: Although he worked very hard to finish the project on time, the manager still criticized him.',
  'Only "but" is removed, because English takes the subordinator or the coordinator and not both. "Although" stays, because a native speaker writes it, so changing it to "Even though" would be a preference rather than a correction. "the manager" stays, because it is natural English and "his manager" would add a relationship the writer did not state.'
].join('\n');

export const REWRITE_OUTPUT_RULES = [
  'Every variant must read as though a native speaker of the detected language wrote it.',
  'Correct phrasing that is grammatical but is not what a native speaker would say: collocations the language does not use, a verb or preposition that does not pair with its noun, a literal rendering of an idiom from another language, and vocabulary belonging to a register or an age group that does not fit the writer. A sentence containing no grammatical error can still need this, and leaving such a sentence untouched is a failure rather than a safe choice.',
  'Never introduce buzzwords, cliches, corporate jargon, or decorative metaphor.',
  'Keep precise domain terms the text needs to stay correct.',
  'Never use an em dash or an en dash.'
] as const;
