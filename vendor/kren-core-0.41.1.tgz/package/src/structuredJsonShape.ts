/*
 * Two ways to tell a provider what shape to return, both derived from the one schema.
 *
 * Both functions read the same schema object because separately maintained field lists
 * can drift. A textual outline supplies the expected fields when a provider cannot accept
 * the structured schema directly.
 */

type Schema = Record<string, unknown>;

/*
 * Removing `additionalProperties` alone cannot make a schema compatible with a provider
 * that accepts `enum` only on strings: a numeric constant still requires a representation
 * that the provider supports. Callers choose a supported schema or the textual outline.
 */

const isSchema = (value: unknown): value is Schema =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/**
 * A compact outline of the same schema, for the instruction. It is the fallback when a
 * provider will not take a schema at all, and it costs little to send either way: a model
 * given both agrees with itself more often than one given only a schema.
 *
 * Required fields are marked, optional ones are not, so a model can tell which it may omit.
 */
export function schemaOutline(schema: Schema, indent = 0): string {
  const pad = '  '.repeat(indent);
  const type = schema['type'];

  if (type === 'array') {
    const items = schema['items'];
    return isSchema(items) ? `array of ${schemaOutline(items, indent).trim()}` : 'array';
  }
  if (type !== 'object' || !isSchema(schema['properties'])) {
    if (Array.isArray(schema['enum'])) {
      return `one of ${schema['enum'].map((value) => JSON.stringify(value)).join(' | ')}`;
    }
    if (schema['const'] !== undefined) return JSON.stringify(schema['const']);
    return typeof type === 'string' ? type : 'value';
  }

  const required = new Set(
    Array.isArray(schema['required']) ? schema['required'].map(String) : []
  );
  const lines = Object.entries(schema['properties']).map(([name, child]) => {
    const shape = isSchema(child) ? schemaOutline(child, indent + 1) : 'value';
    const mark = required.has(name) ? '' : ' (optional)';
    return `${pad}  ${name}: ${shape}${mark}`;
  });
  return `{\n${lines.join('\n')}\n${pad}}`;
}

/**
 * The sentence pair that carries the outline. Kept here rather than in the transport so the
 * wording and the outline it introduces stay together.
 */
export function schemaInstruction(schema: Schema): string {
  return 'Return exactly this JSON shape, using these field names and no others. ' +
    'Every field not marked optional must be present.\n' +
    schemaOutline(schema);
}
