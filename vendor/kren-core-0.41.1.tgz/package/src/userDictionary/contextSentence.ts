import { USER_DICTIONARY_CONTEXT_MAX_CHARACTERS } from './contract.js';

/**
 * The sentence a selection sits in, taken from the surrounding block of text.
 *
 * Both hosts need this and neither should own it. VS Code has the paragraph as editor
 * lines; Word has it as `Range.paragraphs`; PowerPoint already holds the whole shape text
 * and the selection offset within it. All three arrive here as the same two arguments, so
 * the rule that decides what counts as a sentence is stated once and the hosts only supply
 * the text.
 *
 * Returns undefined rather than a best effort whenever the answer would be misleading: no
 * usable block, an offset that does not point into it, or a sentence longer than the shared
 * cap. An absent context renders as today's entry, which is a correct outcome; a wrong
 * sentence is shown to the reader as the reason a meaning was chosen.
 */
export function sentenceAroundSelection(
  block: string,
  selectionStart: number,
  expression?: string
): string | undefined {
  if (typeof block !== 'string' || !block.trim()) return undefined;
  if (!Number.isInteger(selectionStart) || selectionStart < 0 ||
      selectionStart >= block.length) {
    return undefined;
  }

  let start = 0;
  for (let index = selectionStart - 1; index >= 0; index -= 1) {
    const end = sentenceEndAt(block, index);
    if (end !== undefined && end <= selectionStart) {
      start = end;
      break;
    }
  }

  let end = block.length;
  for (let index = selectionStart; index < block.length; index += 1) {
    const candidate = sentenceEndAt(block, index);
    if (candidate !== undefined) {
      end = candidate;
      break;
    }
  }

  const sentence = tidyCapturedText(block.slice(start, end));
  if (!sentence || sentence.length > USER_DICTIONARY_CONTEXT_MAX_CHARACTERS) {
    return undefined;
  }
  // Context that is only the expression is not context. Selecting a bare word on a line of
  // its own produced a box reading "This sentence did not single out one meaning" above the
  // word itself, which tells the reader nothing and costs a longer prompt to produce.
  if (expression !== undefined && addsNothingTo(sentence, expression)) return undefined;
  return sentence;
}

/**
 * The captured text as a reader would write it, rather than as it happened to sit in the
 * document.
 *
 * Three things are cleaned. A leading list marker, quotation mark, or bullet belongs to the
 * document's formatting and not to the sentence. A trailing comma, colon, or semicolon is a
 * join to text that was not captured, so it dangles. And a run of text that reads as a
 * complete sentence but was cut at a line break ends with nothing at all, so it gets a full
 * stop; a fragment does not, because inventing a full stop after "the attached file" would
 * assert it was a sentence when it was not.
 */
export function tidyCapturedText(value: string): string {
  const collapsed = value.replace(/\s+/gu, ' ').trim();
  // Quotation marks are deliberately not stripped. A leading quote has a closing quote later
  // in the same captured run, so removing one of the pair leaves `He turned up."`, which is
  // worse than the untouched text. List markers have no counterpart and are safe to drop.
  const withoutLeadingMarkers = collapsed
    .replace(/^(?:[-–—*•·>#]+|\d+[.)]|[a-z][.)])\s+/iu, '')
    .trim();
  const withoutTrailingJoins = withoutLeadingMarkers.replace(/[\s,;:]+$/u, '');
  if (!withoutTrailingJoins) return '';
  if (TERMINATORS.has(withoutTrailingJoins.at(-1)!)) return withoutTrailingJoins;
  if (CLOSERS.has(withoutTrailingJoins.at(-1)!)) return withoutTrailingJoins;
  return readsAsCompleteSentence(withoutTrailingJoins)
    ? `${withoutTrailingJoins}.`
    : withoutTrailingJoins;
}

/**
 * A capitalised run of several words is treated as a sentence that lost its full stop to a
 * line break, which is what a heading or a table cell looks like. Two words or fewer is a
 * label, and a lowercase opening is a fragment cut out of the middle of something.
 * Scripts without letter case never reach the capital test, so they are judged on length
 * alone, which is the only signal available there.
 */
function readsAsCompleteSentence(value: string): boolean {
  if (value.split(' ').length < 3) return false;
  const first = value[0]!;
  return first.toLowerCase() !== first || first.toUpperCase() === first;
}

function addsNothingTo(sentence: string, expression: string): boolean {
  return comparable(sentence) === comparable(expression);
}

function comparable(value: string): string {
  return value.replace(/\s+/gu, ' ').replace(/[.!?。！？,;:'"“”‘’]/gu, '').trim().toLowerCase();
}

const TERMINATORS = new Set(['.', '!', '?', '。', '！', '？']);
const CLOSERS = new Set(['"', "'", '”', '’', ')', ']', '»', '』', '」']);

/**
 * Where the sentence ends if one ends at this character, and undefined if none does.
 *
 * Three things make this more than a search for a period. A run of terminators is one
 * boundary rather than three, so "Wait..." is not three sentences. The closing quotation
 * mark belongs to the sentence it closes, so `"He turned up."` keeps its quote. And a
 * terminator followed by a lowercase letter is not ending anything, which is what keeps
 * "Wait... he turned up" whole; that test is skipped for scripts without letter case, where
 * a lowercase letter does not exist to look for.
 */
function sentenceEndAt(block: string, index: number): number | undefined {
  const character = block[index]!;
  // A line break is a stronger boundary than any punctuation, because a host hands in a
  // block that can hold a heading and a paragraph with no period between them.
  if (character === '\n') return index + 1;
  if (!TERMINATORS.has(character)) return undefined;

  let end = index + 1;
  while (end < block.length && TERMINATORS.has(block[end]!)) end += 1;
  while (end < block.length && CLOSERS.has(block[end]!)) end += 1;

  let probe = end;
  while (probe < block.length && /\s/u.test(block[probe]!)) probe += 1;
  if (probe < block.length && isLowercaseLetter(block[probe]!)) return undefined;
  return end;
}

function isLowercaseLetter(character: string): boolean {
  return character.toLowerCase() === character && character.toUpperCase() !== character;
}
