import type { RewriteAxes, RewriteDomain } from '../rewriteAxes.js';
import type { RewriteVariant as CoreRewriteVariant } from '../contracts.js';
export type FeatureRewriteOperation = 'rewrite' | 'rewriteMinimal' | 'rewriteFull';
export interface FeatureTranslationRequest {
    text: string;
    sourceLanguage: string;
    targetLanguage: string;
    kind: 'translation' | 'dictionary';
    operation: 'translate' | 'explain';
    explanationLanguage?: string;
    domain?: RewriteDomain;
}
export interface FeatureRewriteRequest extends RewriteAxes {
    text: string;
    sourceLanguage: string;
    targetLanguage: string;
    kind: 'translation';
    operation: FeatureRewriteOperation;
    preserveFormatting?: boolean;
    includeChangeNotes?: boolean;
}
export interface FeatureResultBase {
    providerId: string;
    sourceText: string;
    sourceLanguage: string;
    targetLanguage: string;
    createdAt: string;
}
export interface FeatureTranslationResult extends FeatureResultBase {
    kind: 'translation';
    operation: 'translate' | 'explain';
    translatedText: string;
    alternatives?: string[];
    note?: string;
}
export interface FeatureRewriteVariant extends CoreRewriteVariant {
    targetLanguage?: string;
}
export interface FeatureRewriteResult extends FeatureResultBase, RewriteAxes {
    kind: 'rewrite';
    variants: FeatureRewriteVariant[];
}
export type CompatibleProvider = 'groq' | 'cloudflare';
export interface CompatibleBodyCall {
    provider: CompatibleProvider;
    model: string;
    thinkingOrEffort: import('../contracts.js').LanguageModelEffort;
    schema: Record<string, unknown>;
    schemaName: string;
}
export interface StructuredBodyCall extends Omit<CompatibleBodyCall, 'provider'> {
    provider: import('../languageModelRouting.js').LanguageModelRoutingProvider;
}
export interface StructuredBodyRequest {
    instruction: string;
    input: string;
}
export class ProviderResponseError extends Error {
    public constructor(message: string, public readonly code: 'structuredOutput' | 'emptyOutput' = 'structuredOutput', public readonly retryable = false, public readonly status?: number, public readonly reason: 'structuredOutput' | 'refused' = 'structuredOutput') { super(message); this.name = 'ProviderResponseError'; }
}
