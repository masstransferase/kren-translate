import type { FeatureRewriteRequest as RewriteRequest, FeatureTranslationRequest as TranslationRequest } from './contracts.js';
import { systemInstruction, rewriteSystemInstruction } from './features.js';
import { REWRITE_VARIANT_IDS } from '../rewriteVariants.js';
export function buildGeminiRewriteRequestBody(request: RewriteRequest, thinkingLevel: GeminiThinkingLevel | undefined = 'minimal'): ReturnType<typeof buildGeminiRequestBody> {
    return {
        systemInstruction: {
            parts: [{ text: rewriteSystemInstruction(request) }]
        },
        contents: [
            {
                role: 'user',
                parts: [{ text: request.text }]
            }
        ],
        generationConfig: {
            responseMimeType: 'application/json',
            ...(thinkingLevel ? { thinkingConfig: { thinkingLevel } } : {})
        }
    };
}
export type GeminiThinkingLevel = 'minimal' | 'low' | 'medium' | 'high';
export function buildGeminiRequestBody(request: TranslationRequest, thinkingLevel: GeminiThinkingLevel | undefined = 'minimal'): {
    systemInstruction: {
        parts: Array<{
            text: string;
        }>;
    };
    contents: Array<{
        role: 'user';
        parts: Array<{
            text: string;
        }>;
    }>;
    generationConfig: {
        responseMimeType: 'application/json';
        thinkingConfig?: {
            thinkingLevel: GeminiThinkingLevel;
        };
    };
} {
    return {
        systemInstruction: {
            parts: [{ text: systemInstruction(request) }]
        },
        contents: [
            {
                role: 'user',
                parts: [{ text: request.text }]
            }
        ],
        generationConfig: {
            responseMimeType: 'application/json',
            ...(thinkingLevel ? { thinkingConfig: { thinkingLevel } } : {})
        }
    };
}
export function thinkingLevelForModel(model: string): GeminiThinkingLevel | undefined {
    const normalized = model.replace(/^models\//u, '').toLocaleLowerCase('en-US');
    if (/^gemini-(?:3(?:\.\d+)?-.*pro|2\.5-|3\.8-flash(?:$|-))/u.test(normalized))
        return 'low';
    if (/^gemini-3(?:\.\d+)?-.*flash/u.test(normalized))
        return 'minimal';
    return undefined;
}
export function configuredThinkingLevel(model: string, configured: GeminiThinkingLevel | 'auto'): GeminiThinkingLevel | undefined {
    const automatic = thinkingLevelForModel(model);
    if (configured === 'auto')
        return automatic;
    const normalized = model.replace(/^models\//u, '').toLocaleLowerCase('en-US');
    if (configured === 'minimal' && /^gemini-(?:3(?:\.\d+)?-.*pro|2\.5-|3\.8-flash(?:$|-))/u.test(normalized)) {
        return 'low';
    }
    return configured;
}
export type OpenAIReasoningEffort = 'auto' | 'none' | 'low' | 'medium' | 'high';
export function buildOpenAIRequestBody(model: string, instructions: string, text: string, schemaName: string, schema: Record<string, unknown>, reasoningEffort: OpenAIReasoningEffort = 'auto'): Record<string, unknown> {
    return {
        model,
        instructions,
        input: [{
                role: 'user',
                content: [{ type: 'input_text', text }]
            }],
        store: false,
        max_output_tokens: 4096,
        text: {
            format: {
                type: 'json_schema',
                name: schemaName,
                strict: true,
                schema
            }
        },
        ...(reasoningEffort === 'auto' ? {} : { reasoning: { effort: reasoningEffort } })
    };
}
export function explanationSchema(): Record<string, unknown> {
    return {
        type: 'object',
        additionalProperties: false,
        required: ['kind', 'translatedText', 'alternatives', 'note'],
        properties: {
            kind: { type: 'string', enum: ['translation'] },
            translatedText: { type: 'string' },
            alternatives: { type: 'array', items: { type: 'string' }, maxItems: 3 },
            note: { type: 'string' }
        }
    };
}
export function rewriteSchema(request: RewriteRequest): Record<string, unknown> {
    const includeChangeNotes = request.includeChangeNotes === true;
    const variantProperties: Record<string, unknown> = {
        id: { type: 'string', enum: REWRITE_VARIANT_IDS },
        label: { type: 'string' },
        text: { type: 'string' }
    };
    if (includeChangeNotes)
        variantProperties.changeNote = { type: 'string' };
    const count = request.operation === 'rewrite' ? REWRITE_VARIANT_IDS.length : 1;
    return {
        type: 'object',
        additionalProperties: false,
        required: ['kind', 'detectedLanguage', 'variants'],
        properties: {
            kind: { type: 'string', enum: ['rewrite'] },
            detectedLanguage: { type: 'string' },
            variants: {
                type: 'array',
                minItems: count,
                maxItems: count,
                items: {
                    type: 'object',
                    additionalProperties: false,
                    required: includeChangeNotes ? ['id', 'label', 'text', 'changeNote'] : ['id', 'label', 'text'],
                    properties: variantProperties
                }
            }
        }
    };
}
export type AnthropicEffort = 'auto' | 'low' | 'medium' | 'high';
export function buildAnthropicRequestBody(model: string, system: string, text: string, schema: Record<string, unknown>, effort: AnthropicEffort = 'low'): Record<string, unknown> {
    return {
        model,
        max_tokens: 4096,
        system,
        messages: [{ role: 'user', content: [{ type: 'text', text }] }],
        output_config: {
            format: { type: 'json_schema', schema },
            ...(effort === 'auto' ? {} : { effort })
        }
    };
}
