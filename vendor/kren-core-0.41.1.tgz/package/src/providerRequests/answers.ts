import { ProviderResponseError } from './contracts.js';
import { parseJson } from './features.js';
interface GeminiPayload {
    candidates?: Array<{
        content?: {
            parts?: Array<{
                text?: unknown;
            }>;
        };
    }>;
    error?: {
        message?: unknown;
        details?: unknown;
        status?: unknown;
    };
}
interface OpenAIResponse {
    output?: Array<{
        type?: unknown;
        content?: Array<{
            type?: unknown;
            text?: unknown;
            refusal?: unknown;
        }>;
    }>;
    error?: {
        message?: unknown;
    };
}
interface AnthropicResponse {
    content?: Array<{
        type?: unknown;
        text?: unknown;
    }>;
    error?: {
        message?: unknown;
    };
}
function openAIOutputText(payload: OpenAIResponse): string | undefined {
    for (const item of payload.output ?? []) {
        for (const content of item.content ?? []) {
            if (content.type === 'refusal' && typeof content.refusal === 'string') {
                throw new ProviderResponseError('OpenAI declined the request.', undefined, false, undefined, 'refused');
            }
            if (content.type === 'output_text' && typeof content.text === 'string' && content.text.trim()) {
                return content.text.trim();
            }
        }
    }
    return undefined;
}
export function structuredJsonOutputText(provider: import('../languageModelRouting.js').LanguageModelRoutingProvider, value: unknown): string | undefined {
    if (!isRecord(value))
        return undefined;
    if (provider === 'groq' || provider === 'cloudflare') {
        const choices = value.choices;
        if (!Array.isArray(choices) || !isRecord(choices[0]) || !isRecord(choices[0].message))
            return undefined;
        const content = choices[0].message.content;
        return typeof content === 'string' ? content : undefined;
    }
    if (provider === 'gemini') {
        const candidates = value.candidates;
        if (!Array.isArray(candidates))
            return undefined;
        const candidate = candidates[0];
        if (!isRecord(candidate) || !isRecord(candidate.content) ||
            !Array.isArray(candidate.content.parts))
            return undefined;
        const text = candidate.content.parts
            .flatMap((part) => isRecord(part) && typeof part.text === 'string' ? [part.text] : [])
            .join('')
            .trim();
        return text || undefined;
    }
    if (provider === 'openai') {
        if (!Array.isArray(value.output))
            return undefined;
        for (const output of value.output) {
            if (!isRecord(output) || !Array.isArray(output.content))
                continue;
            for (const content of output.content) {
                if (isRecord(content) && content.type === 'output_text' &&
                    typeof content.text === 'string' && content.text.trim())
                    return content.text.trim();
            }
        }
        return undefined;
    }
    if (!Array.isArray(value.content))
        return undefined;
    const block = value.content.find((item) => isRecord(item) && item.type === 'text' && typeof item.text === 'string');
    return isRecord(block) && typeof block.text === 'string' && block.text.trim()
        ? block.text.trim()
        : undefined;
}
function isRecord(value: unknown): value is Record<string, unknown> {
    return typeof value === 'object' && value !== null;
}
export function readGeminiFeatureResponse(envelope: unknown): unknown {
    const payload = (envelope ?? {}) as GeminiPayload;
    const rawText = payload.candidates?.[0]?.content?.parts?.map(part => typeof part.text === 'string' ? part.text : '').join('').trim();
    if (!rawText)
        throw new ProviderResponseError('Gemini returned no result.', 'emptyOutput', true);
    return parseJson(rawText, 'Gemini');
}
export function readOpenAIFeatureResponse(envelope: unknown): unknown {
    const raw = openAIOutputText((envelope ?? {}) as OpenAIResponse);
    if (!raw)
        throw new ProviderResponseError('OpenAI returned no usable text output.');
    return parseJson(raw, 'OpenAI');
}
export function readAnthropicFeatureResponse(envelope: unknown): unknown {
    const payload = (envelope ?? {}) as AnthropicResponse;
    const raw = payload.content?.find(block => block.type === 'text' && typeof block.text === 'string')?.text;
    if (typeof raw !== 'string' || !raw.trim())
        throw new ProviderResponseError('Anthropic returned no usable text output.');
    return parseJson(raw.trim(), 'Anthropic');
}
