import type { StructuredBodyCall, StructuredBodyRequest } from './contracts.js';
import { configuredThinkingLevel } from './bodies.js';
import { buildCompatibleRequestBody } from './compatible.js';
import { schemaInstruction } from '../structuredJsonShape.js';
export function buildStructuredJsonBody(call: StructuredBodyCall, request: StructuredBodyRequest): Record<string, unknown> {
    const { provider, model, thinkingOrEffort, schema, schemaName } = call;
    if (provider === 'groq' || provider === 'cloudflare')
        return buildCompatibleRequestBody({ provider, model, thinkingOrEffort, schema, schemaName }, request.instruction, request.input);
    if (provider === 'gemini') {
        const level = thinkingOrEffort === 'none' ? undefined : configuredThinkingLevel(model, thinkingOrEffort);
        const thinking = level === undefined
            ? {}
            : { thinkingConfig: { thinkingLevel: level } };
        return ({
            systemInstruction: {
                parts: [{ text: `${request.instruction}\n\n${schemaInstruction(schema)}` }]
            },
            contents: [{ role: 'user', parts: [{ text: request.input }] }],
            generationConfig: {
                responseMimeType: 'application/json',
                ...thinking
            }
        });
    }
    if (provider === 'openai') {
        const effort = thinkingOrEffort === 'minimal' ? 'low' : thinkingOrEffort;
        return ({
            model,
            instructions: request.instruction,
            input: [{ role: 'user', content: [{ type: 'input_text', text: request.input }] }],
            store: false,
            max_output_tokens: 4096,
            text: {
                format: {
                    type: 'json_schema',
                    name: schemaName,
                    strict: true,
                    schema
                }
            },
            ...(effort === 'auto' ? {} : { reasoning: { effort } })
        });
    }
    const effort = thinkingOrEffort === 'auto'
        ? {}
        : { effort: thinkingOrEffort === 'none' || thinkingOrEffort === 'minimal'
                ? 'low'
                : thinkingOrEffort };
    return ({
        model,
        max_tokens: 4096,
        system: request.instruction,
        messages: [{ role: 'user', content: [{ type: 'text', text: request.input }] }],
        output_config: {
            format: { type: 'json_schema', schema },
            ...effort
        }
    });
}
