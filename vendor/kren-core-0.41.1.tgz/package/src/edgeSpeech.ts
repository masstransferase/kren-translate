import { EDGE_SPEECH_LOCALES } from './edgeSpeechCatalog.js';

// Re-exported so a consumer needs one import for the catalog and the rules that read it.
export { EDGE_SPEECH_LOCALES } from './edgeSpeechCatalog.js';

export interface EdgeSpeechVoice {
  id: string;
  label: string;
}

export interface EdgeSpeechLocale {
  id: string;
  label: string;
  defaultVoice: string;
  voices: readonly EdgeSpeechVoice[];
}

/** The locale chosen for Read Aloud, or `auto` to resolve it per playback. */
export const EDGE_SPEECH_AUTO_LOCALE = 'auto';

export function isEdgeSpeechLocale(value: unknown): boolean {
  return typeof value === 'string' &&
    (value === EDGE_SPEECH_AUTO_LOCALE ||
      EDGE_SPEECH_LOCALES.some((locale) => locale.id === value));
}

export function edgeSpeechLocale(id: string): EdgeSpeechLocale | undefined {
  return EDGE_SPEECH_LOCALES.find((locale) => locale.id === id);
}

export function isEdgeSpeechVoice(value: unknown): boolean {
  return typeof value === 'string' &&
    EDGE_SPEECH_LOCALES.some((locale) => locale.voices.some((voice) => voice.id === value));
}

/**
 * The voice to speak with, given the resolved locale and whatever the reader last chose.
 *
 * The stored voice wins only when it belongs to this locale. A reader who selects Korean
 * after using an English voice must not get an English voice reading Korean, which is the
 * failure this whole feature exists to remove, so a voice from another locale is discarded
 * rather than carried across.
 */
export function resolveEdgeSpeechVoice(
  localeId: string,
  storedVoice: string | undefined
): string | undefined {
  const locale = edgeSpeechLocale(localeId);
  if (!locale) return storedVoice;
  return locale.voices.some((voice) => voice.id === storedVoice)
    ? storedVoice
    : locale.defaultVoice;
}

/**
 * The locale a passage is written in, from its script alone, or undefined when the script
 * does not say.
 *
 * Deterministic and deliberately narrow. Hangul, Thai, Arabic, and Devanagari each belong to
 * one language on KREN's list. Kana is checked before Han because Japanese is mostly Han
 * with Kana mixed through it, so a passage with any Kana is Japanese and one with Han and no
 * Kana is Chinese. Latin script returns undefined, because French, Spanish, German, Italian,
 * and Portuguese cannot be told apart by their alphabet, and a wrong guess reads the
 * reader's text aloud in the wrong accent.
 */
export function edgeSpeechLocaleFromScript(text: string): string | undefined {
  if (/\p{Script=Hiragana}|\p{Script=Katakana}/u.test(text)) return 'ja-JP';
  if (/\p{Script=Hangul}/u.test(text)) return 'ko-KR';
  if (/\p{Script=Thai}/u.test(text)) return 'th-TH';
  if (/\p{Script=Arabic}/u.test(text)) return 'ar-SA';
  if (/\p{Script=Devanagari}/u.test(text)) return 'hi-IN';
  if (/\p{Script=Han}/u.test(text)) return 'zh-CN';
  return undefined;
}

// The bare languages the Rewrite Text output list leaves regionally open, mapped to the
// majority region. Chinese and Portuguese are here for a bare "zh" or "pt", but an exact
// code such as pt-BR matches a locale directly above and never reaches this.
const MAJORITY_REGION: Record<string, string | undefined> = {
  ar: 'ar-SA', de: 'de-DE', en: 'en-US', es: 'es-ES', fa: 'fa-IR', fr: 'fr-FR',
  hi: 'hi-IN', it: 'it-IT', ja: 'ja-JP', ko: 'ko-KR', pt: 'pt-BR', th: 'th-TH',
  vi: 'vi-VN', zh: 'zh-CN'
};

/**
 * The locale a language code names, for a result whose language KREN already knows.
 *
 * An exact code wins, so pt-BR stays Brazilian rather than collapsing to Portuguese.
 */
export function edgeSpeechLocaleFromLanguage(code: string): string | undefined {
  const normalized = code.trim();
  if (!normalized || normalized === 'auto') return undefined;
  const exact = EDGE_SPEECH_LOCALES.find(
    (locale) => locale.id.toLowerCase() === normalized.toLowerCase()
  );
  if (exact) return exact.id;
  return MAJORITY_REGION[normalized.split('-')[0]!.toLowerCase()];
}

export type EdgeSpeechLocaleReason = 'chosen' | 'result' | 'script' | 'words' | 'fallback';

/**
 * The locale Read Aloud should speak in, and how it was decided.
 *
 * Three steps, stopping at the first that answers. The reason travels with the answer,
 * because a reader who hears an unexpected accent needs to know whether KREN was told, saw,
 * or fell back.
 *
 * `resultLanguage` is the strongest signal and is not a guess at all: a rewrite reports the
 * language it detected or was asked to write in. Script detection is deterministic.
 * Closed-class words are next and answer only on clear evidence. The fallback is the
 * reader's preferred locale, for everything left over.
 */
export function resolveEdgeSpeechLocale(options: {
  configured: string;
  resultLanguage?: string;
  text?: string;
  fallback: string;
}): { locale: string; reason: EdgeSpeechLocaleReason } {
  if (options.configured !== EDGE_SPEECH_AUTO_LOCALE && edgeSpeechLocale(options.configured)) {
    return { locale: options.configured, reason: 'chosen' };
  }
  const fromResult = options.resultLanguage
    ? edgeSpeechLocaleFromLanguage(options.resultLanguage)
    : undefined;
  if (fromResult) return { locale: fromResult, reason: 'result' };

  const fromScript = options.text ? edgeSpeechLocaleFromScript(options.text) : undefined;
  if (fromScript) return { locale: fromScript, reason: 'script' };

  const fromWords = options.text ? edgeSpeechLocaleFromLatinWords(options.text) : undefined;
  if (fromWords) return { locale: fromWords, reason: 'words' };

  return {
    locale: edgeSpeechLocale(options.fallback) ? options.fallback : 'en-US',
    reason: 'fallback'
  };
}

/**
 * The Latin-script language a passage is written in, or undefined when the evidence is thin
 * or divided.
 *
 * Shared alphabets do not imply shared vocabulary. German function words such as "der",
 * "und", and "nicht" provide evidence that script detection alone cannot supply.
 *
 * Each candidate scores two ways. Closed-class words are the strong signal, because a
 * language neither borrows nor avoids them. Characters no other candidate uses are the weak
 * one, and they carry a language whose function words a short passage happens to miss: "ß"
 * is German, "ñ" is Spanish, "ã" is Portuguese.
 *
 * Two guards keep it from guessing. A winner must clear MINIMUM_SCORE, so a passage with one
 * accidental hit answers nothing, and it must beat the runner-up by MINIMUM_MARGIN, so
 * Spanish and Portuguese sharing a sentence answer nothing rather than picking the luckier
 * one. Undefined still means "fall back to the reader's preference", which is the outcome
 * this replaces only where it can do better.
 */
export function edgeSpeechLocaleFromLatinWords(text: string): string | undefined {
  const words = text.toLowerCase().match(/[\p{Script=Latin}'’]+/gu) ?? [];
  if (words.length < LATIN_MINIMUM_WORDS) return undefined;
  const unique = new Set(words);
  const lowered = text.toLowerCase();

  const scored = LATIN_LANGUAGES.map((language) => {
    const wordHits = language.words.filter((word) => unique.has(word)).length;
    const characterHits = language.characters
      .filter((character) => lowered.includes(character)).length;
    return { locale: language.locale, score: wordHits * 2 + characterHits };
  }).sort((left, right) => right.score - left.score);

  const best = scored[0]!;
  const runnerUp = scored[1]!;
  if (best.score < LATIN_MINIMUM_SCORE) return undefined;
  if (best.score - runnerUp.score < LATIN_MINIMUM_MARGIN) return undefined;
  return best.locale;
}

// Six words is the same floor the English gate uses: below it, an absent function word says
// nothing, because the passage had no room for one.
const LATIN_MINIMUM_WORDS = 6;
// Two function words, or one plus a distinctive character. One hit alone is a coincidence.
const LATIN_MINIMUM_SCORE = 4;
// A clear win, not a tie broken by list order. Below this the answer is "I do not know".
const LATIN_MINIMUM_MARGIN = 2;

/**
 * Closed-class words and exclusive characters per candidate.
 *
 * Deliberately short and deliberately non-overlapping: a word that two candidates share adds
 * noise to both and helps neither. "de" is absent from French, Spanish, and Portuguese for
 * that reason, and "a" and "e" are absent everywhere. English is here so that a German
 * passage competes against it rather than winning by default.
 */
const LATIN_LANGUAGES: ReadonlyArray<{
  locale: string;
  words: readonly string[];
  characters: readonly string[];
}> = [
  {
    locale: 'en-US',
    words: ['the', 'and', 'of', 'to', 'is', 'was', 'this', 'that', 'with', 'from', 'which',
      'they', 'have', 'has', 'been', 'not', 'are', 'were', 'would', 'their'],
    characters: []
  },
  {
    locale: 'de-DE',
    words: ['der', 'die', 'das', 'und', 'ist', 'nicht', 'ein', 'eine', 'mit', 'auf', 'sich',
      'dem', 'den', 'des', 'aber', 'auch', 'oder', 'wird', 'werden', 'zum', 'zur', 'durch',
      'ich', 'du', 'dir', 'mir', 'wie', 'was', 'wo', 'wer', 'noch', 'schon', 'sehr', 'hier',
      'habe', 'hat', 'haben', 'war', 'kann', 'muss', 'soll', 'will', 'mein', 'dein', 'sein',
      'ihr', 'wir', 'uns', 'nur', 'immer', 'wieder', 'geht', 'gut'],
    characters: ['ß']
  },
  {
    locale: 'fr-FR',
    words: ['le', 'la', 'les', 'des', 'du', 'et', 'est', 'une', 'dans', 'pour', 'que', 'qui',
      'pas', 'sur', 'avec', 'sont', 'ils', 'elle', 'nous', 'cette', 'aux', 'ce',
      'je', 'tu', 'vous', 'moi', 'toi', 'ne', 'comment', 'allez', 'vas', 'suis', 'ai',
      'depuis', 'longtemps', 'bien', 'merci', 'oui', 'non', 'ici', 'maintenant', 'mais',
      'aussi', 'quand', 'faire', 'tout', 'plus', 'bonjour', 'salut'],
    characters: ['ç', 'ê', 'î', 'û', 'œ']
  },
  {
    locale: 'es-ES',
    words: ['el', 'los', 'las', 'del', 'que', 'con', 'por', 'para', 'como', 'pero', 'este',
      'esta', 'son', 'está', 'muy', 'sin', 'sus', 'más', 'también', 'hay',
      'hola', 'estas', 'estoy', 'yo', 'tu', 'te', 'me', 'no', 'si', 'bien', 'gracias',
      'favor', 'ella', 'eso', 'aqui', 'aquí', 'ahora', 'cuando', 'donde', 'dónde', 'quien',
      'mucho', 'tiempo', 'visto', 'hace'],
    characters: ['ñ', '¿', '¡']
  },
  {
    locale: 'pt-BR',
    words: ['que', 'não', 'uma', 'com', 'para', 'como', 'mas', 'este', 'esta', 'são', 'pelo',
      'pela', 'dos', 'das', 'ele', 'ela', 'muito', 'também', 'ser', 'está'],
    characters: ['ã', 'õ']
  },
  {
    locale: 'it-IT',
    words: ['il', 'lo', 'gli', 'che', 'non', 'una', 'per', 'con', 'sono', 'questo', 'questa',
      'nel', 'nella', 'delle', 'degli', 'anche', 'come', 'più', 'essere', 'sua'],
    characters: []
  },
  {
    locale: 'vi-VN',
    words: ['của', 'và', 'là', 'không', 'các', 'được', 'trong', 'người', 'này', 'với',
      'những', 'cho', 'một', 'đã', 'khi', 'để'],
    characters: ['ơ', 'ư', 'đ', 'ạ', 'ế', 'ộ']
  }
];
