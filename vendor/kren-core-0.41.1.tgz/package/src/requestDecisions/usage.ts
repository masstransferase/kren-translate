import { resolveRetiredGeminiModel } from '../modelNames.js';
export interface LanguageModelUsage {
  geminiProfile?: 'standard' | 'pro';
  provider: string;
  model: string;
  requests: number;
  input: number;
  output: number;
  thinking: number;
  characters?: number;
}
export interface LanguageModelRequest { feature: string; provider: string; model: string; geminiProfile?: 'standard' | 'pro' }
export const recordObject = (value: unknown): Record<string, unknown> =>
  value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
export const count = (value: unknown): number => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? value : 0;

/** Read reported counts only. No prompt, completion, audio, credential, or response is retained. */
export function reportedLanguageModelUsage(provider: string, envelope: unknown): Pick<LanguageModelUsage, 'input' | 'output' | 'thinking'> {
  const value = recordObject(envelope);
  const usage = recordObject(provider === 'gemini' ? value.usageMetadata : value.usage ?? recordObject(value.result).usage);
  return provider === 'gemini'
    ? { input: count(usage.promptTokenCount), output: count(usage.candidatesTokenCount ?? usage.responseTokenCount), thinking: count(usage.thoughtsTokenCount) }
    : { input: count(usage.prompt_tokens ?? usage.input_tokens), output: count(usage.completion_tokens ?? usage.output_tokens), thinking: 0 };
}
export const localDay = (date: Date): string => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
export const identifier = (value: string): string => /^[A-Za-z0-9@_./:+-]{1,160}$/u.test(value) ? value : 'custom';


export function normalizeUsageRows(rows: readonly unknown[]): LanguageModelUsage[] {
  return rows.flatMap(row => {
    const r = recordObject(row);
    return typeof r.provider === 'string' && typeof r.model === 'string'
      ? [{ provider: identifier(r.provider), model: identifier(r.model), requests: count(r.requests), input: count(r.input), output: count(r.output), thinking: count(r.thinking), ...(r.provider === 'gemini' && (r.geminiProfile === 'pro' || r.geminiProfile === 'standard') ? { geminiProfile: r.geminiProfile } : {}), ...(r.characters !== undefined ? { characters: count(r.characters) } : {}) }] : [];
  });
}
export function addLanguageModelUsage(previous: readonly LanguageModelUsage[], request: LanguageModelRequest, envelope?: unknown): {
  rows: LanguageModelUsage[]; provider: string; model: string; tokens: Pick<LanguageModelUsage, 'input' | 'output' | 'thinking'>
} {
  const provider = identifier(request.provider);
  const model = identifier(provider === 'gemini' ? resolveRetiredGeminiModel(request.model).replace(/^models\//u, '') : request.model);
  const tokens = reportedLanguageModelUsage(provider, envelope), rows = previous.map(row => ({ ...row }));
  const profile = provider === 'gemini' ? request.geminiProfile ?? 'standard' : undefined;
  let row = rows.find(r => r.provider === provider && r.model === model && (provider !== 'gemini' || r.geminiProfile === profile));
  if (!row) { row = { provider, model, ...(profile ? { geminiProfile: profile } : {}), requests: 0, input: 0, output: 0, thinking: 0 }; rows.push(row); }
  row.requests += 1; row.input += tokens.input; row.output += tokens.output; row.thinking += tokens.thinking;
  if (provider === 'google-tts') row.characters = (row.characters ?? 0) + count(recordObject(envelope).characters);
  return { rows, provider, model, tokens };
}
