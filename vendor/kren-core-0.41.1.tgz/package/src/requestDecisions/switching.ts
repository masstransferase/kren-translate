import { isLanguageModelRoutingProvider, type LanguageModelRoutingProvider, type LanguageModelRoutingEffort } from '../languageModelRouting.js';
import { TUTOR_MODELS, modeEffort, type ThinkingMode } from './thinking.js';
export const DEFAULT_PROVIDER_ORDER = ['gemini', 'groq', 'cloudflare'] as const;

export interface QuotaRoute { provider: LanguageModelRoutingProvider; geminiProfile: 'standard' | 'pro'; model: string }
export interface ExhaustionSnapshot { day: string; exhausted: string[] }
export const dayOf = (date: Date): string => `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
export const quotaPool = (route: QuotaRoute): string => `${route.provider}:${route.provider === 'gemini' ? route.geminiProfile : 'standard'}:${
  route.provider === 'gemini' || route.provider === 'groq' ? route.model.replace(/^models\//u, '') : '*'}`;
export const validPool = (pool: unknown): pool is string => typeof pool === 'string' &&
  isLanguageModelRoutingProvider(pool.split(':')[0]) && pool.split(':').length === 3;

export function validProviderOrder(value: unknown): value is LanguageModelRoutingProvider[] {
  return Array.isArray(value) && value.length > 0 && value.length <= 5 &&
    value.every(isLanguageModelRoutingProvider) && new Set(value).size === value.length;
}

export function advanceExhaustionDay(state: ExhaustionSnapshot, date: Date): { state: ExhaustionSnapshot; changed: boolean } {
  const day = dayOf(date);
  return state.day === day ? { state, changed: false } : { state: { day, exhausted: [] }, changed: true };
}
export function quotaPoolIsExhausted(state: ExhaustionSnapshot, route: QuotaRoute): boolean {
  return state.exhausted.includes(quotaPool(route));
}
export function markExhaustion(state: ExhaustionSnapshot, route: QuotaRoute): { state: ExhaustionSnapshot; changed: boolean } {
  return quotaPoolIsExhausted(state, route) ? { state, changed: false }
    : { state: { ...state, exhausted: [...state.exhausted, quotaPool(route)] }, changed: true };
}
export function keepExhaustionPool(pool: string, provider?: LanguageModelRoutingProvider): boolean {
  return provider !== undefined && !pool.startsWith(`${provider}:`);
}
export function clearExhaustion(state: ExhaustionSnapshot, provider?: LanguageModelRoutingProvider): ExhaustionSnapshot {
  return { ...state, exhausted: state.exhausted.filter(pool => keepExhaustionPool(pool, provider)) };
}
export function exhaustedProviders(state: ExhaustionSnapshot): LanguageModelRoutingProvider[] {
  return [...new Set(state.exhausted.map(pool => pool.split(':')[0] as LanguageModelRoutingProvider))];
}
export function providerCandidates(order: readonly LanguageModelRoutingProvider[], provider: LanguageModelRoutingProvider): readonly LanguageModelRoutingProvider[] {
  return order.slice(Math.max(0, order.indexOf(provider) + 1));
}
export function switchedProviderRoute<T extends QuotaRoute & { thinkingOrEffort: LanguageModelRoutingEffort }>(route: T, provider: LanguageModelRoutingProvider, mode: ThinkingMode): T & { fastModel: string } {
  const model = TUTOR_MODELS[provider][mode];
  return { ...route, provider, model, fastModel: TUTOR_MODELS[provider].fast, geminiProfile: 'standard',
    thinkingOrEffort: modeEffort(provider, model, mode, route.thinkingOrEffort) };
}
export function providerSwitchCause(provider: LanguageModelRoutingProvider, status: number | undefined, reason: string | undefined, aborted: boolean, providerError: boolean): 'overloaded' | 'quotaExhausted' | undefined {
  if (aborted || !providerError) return undefined;
  const overloaded = provider === 'gemini' && (status === 503 || reason === 'overloaded');
  return overloaded ? 'overloaded' : reason === 'quotaExhausted' ? 'quotaExhausted' : undefined;
}
