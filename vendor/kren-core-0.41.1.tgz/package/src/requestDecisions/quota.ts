import { providerIdentifier } from '../providerRequests/httpError.js';
export type GeminiQuotaCategory = 'perDay' | 'perMinute' | 'perHour' | 'other';

export interface GeminiRateLimitClassification {
  kind: 'rateLimit' | 'quotaExhausted' | 'unknown';
  retryable: boolean;
  quotaCategory?: GeminiQuotaCategory;
  /** Google's quota limit for the violated quota, digits only (0 means the tier has none). */
  quotaLimit?: string;
  retryDelayMs?: number;
}
function geminiQuotaCategory(value: unknown): GeminiQuotaCategory {
  if (typeof value !== 'string') return 'other';
  if (/per[_ -]?day|daily/iu.test(value)) return 'perDay';
  if (/per[_ -]?minute/iu.test(value)) return 'perMinute';
  if (/per[_ -]?hour/iu.test(value)) return 'perHour';
  return 'other';
}

/**
 * Distinguishes a short Google rate window from a quota that cannot succeed on another
 * immediate attempt. Google reports both as 429 RESOURCE_EXHAUSTED, so the status alone is
 * deliberately insufficient.
 */
export function classifyGeminiRateLimit(payload: unknown): GeminiRateLimitClassification {
  const error = recordValue(payload)?.error;
  const errorRecord = recordValue(error);
  const details = Array.isArray(errorRecord?.details) ? errorRecord.details : [];
  let quotaCategory: GeminiQuotaCategory | undefined;
  let quotaValue: string | undefined;
  let retryDelay: number | undefined;
  const quotaDescriptions: string[] = [];
  for (const detail of details) {
    const item = recordValue(detail);
    if (!item) continue;
    if (String(item['@type'] ?? '').endsWith('google.rpc.RetryInfo')) {
      retryDelay = googleDurationMs(item.retryDelay);
    }
    if (!String(item['@type'] ?? '').endsWith('google.rpc.QuotaFailure') ||
        !Array.isArray(item.violations)) continue;
    for (const violation of item.violations) {
      const entry = recordValue(violation);
      if (!entry) continue;
      if (!quotaCategory && Object.hasOwn(entry, 'quotaId')) quotaCategory = geminiQuotaCategory(entry.quotaId);
      const candidateValue = stringField(entry.quotaValue);
      if (candidateValue !== undefined) quotaValue = candidateValue;
      for (const value of [entry.quotaId, entry.quotaMetric, entry.description]) {
        if (typeof value === 'string') quotaDescriptions.push(value);
      }
    }
  }
  const quotaText = quotaDescriptions.join(' ').toLocaleLowerCase('en-US');
  const message = typeof errorRecord?.message === 'string'
    ? errorRecord.message.toLocaleLowerCase('en-US') : '';
  // Google's generic 429 message can say "current quota" for a per-minute limit too. The
  // QuotaFailure window therefore outranks that wording whenever Google supplied one.
  const shortWindow = /per[_ -]?(?:second|minute)|requests?[_ -]per[_ -](?:second|minute)/u
    .test(quotaText);
  const longWindow = /per[_ -]?(?:day|month)|daily|monthly/u.test(quotaText);
  const limit = quotaValue !== undefined && /^\d{1,12}$/u.test(quotaValue) ? { quotaLimit: quotaValue } : {};
  const hardLimit = quotaValue === '0' || longWindow || (!shortWindow &&
    /exceeded your current quota|check your plan and billing/u.test(message));
  if (hardLimit) {
    return { kind: 'quotaExhausted', retryable: false, ...(quotaCategory ? { quotaCategory } : {}), ...limit, ...(retryDelay === undefined ? {} : { retryDelayMs: retryDelay }) };
  }
  if (shortWindow || retryDelay !== undefined) {
    return {
      kind: 'rateLimit', retryable: true,
      ...(quotaCategory ? { quotaCategory } : {}), ...limit,
      ...(retryDelay === undefined ? {} : { retryDelayMs: retryDelay })
    };
  }
  return { kind: 'unknown', retryable: true, ...(quotaCategory ? { quotaCategory } : {}), ...limit };
}

function googleDurationMs(value: unknown): number | undefined {
  if (!providerIdentifier(value)) return undefined;
  const match = /^(\d+(?:\.\d+)?)s$/u.exec(value as string);
  if (!match) return undefined;
  const milliseconds = Math.round(Number(match[1]) * 1000);
  return Number.isSafeInteger(milliseconds) && milliseconds >= 0 ? milliseconds : undefined;
}

function recordValue(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown> : undefined;
}

function stringField(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}


/** The status alone never establishes daily exhaustion. Free-text diagnostics stay local. */
export function isProviderQuotaExhausted(provider: string, status: number, payload: unknown): boolean {
  if (provider === 'gemini') return status === 429 && classifyGeminiRateLimit(payload).kind === 'quotaExhausted';
  if (provider !== 'groq' && provider !== 'cloudflare') return false;
  const data = payload as { errors?: Array<{ code?: number }>; error?: { code?: number; message?: string }; message?: string } | undefined;
  if (provider === 'cloudflare' && (data?.errors?.some(error => error.code === 3036) || data?.error?.code === 3036)) return true;
  const text = JSON.stringify(payload ?? '').toLowerCase();
  return status === 429 && !/per[_ -]?(?:minute|second)|\b(?:rpm|tpm)\b/u.test(text) &&
    /per[_ -]?(?:day|month)|daily|monthly|\b(?:rpd|tpd)\b/u.test(text);
}
