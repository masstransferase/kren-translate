import type { LanguageModelRoutingProvider } from '../languageModelRouting.js';

export type ThinkingMode = 'fast' | 'thorough';
export const TUTOR_MODELS = {
  gemini: { fast: 'gemini-3.5-flash-lite', thorough: 'gemini-3.8-flash' },
  groq: { fast: 'openai/gpt-oss-120b', thorough: 'openai/gpt-oss-120b' },
  cloudflare: { fast: '@cf/meta/llama-3.1-8b-instruct', thorough: '@cf/meta/llama-3.3-70b-instruct-fp8-fast' },
  openai: { fast: 'gpt-5.4', thorough: 'gpt-5.4' },
  anthropic: { fast: 'claude-sonnet-4-6', thorough: 'claude-sonnet-4-6' }
} as const;

export const GROQ_RETIRED_MODELS: Readonly<Record<string, string>> = { 'openai/gpt-oss-20b': 'openai/gpt-oss-120b' };

export function tutorModeModel(provider: LanguageModelRoutingProvider, mode: ThinkingMode, configured?: string): string {
  if (provider === 'groq' && configured?.trim() && GROQ_RETIRED_MODELS[configured.trim()]) return GROQ_RETIRED_MODELS[configured.trim()]!;
  if (!configured) return TUTOR_MODELS[provider][mode];
  const owner = /^(?:models\/)?gemini-/u.test(configured) ? 'gemini'
    : /^@(?:cf|hf)\//u.test(configured) ? 'cloudflare' : /^openai\/|^qwen\//u.test(configured) ? 'groq'
      : /^claude-/u.test(configured) ? 'anthropic' : /^(?:gpt-|o\d)/u.test(configured) ? 'openai' : undefined;
  return owner && owner !== provider ? TUTOR_MODELS[provider][mode] : configured;
}

import type { LanguageModelRoutingEffort } from '../languageModelRouting.js';
import { configuredThinkingLevel, thinkingLevelForModel } from '../providerRequests/bodies.js';
/** A validation rejection permits one Fast to Thorough transition, never a transport retry. */
export function canEscalateThinking(mode: ThinkingMode, aborted: boolean, validationFailure: boolean): boolean {
  return mode === 'fast' && !aborted && validationFailure;
}

/** Every generation kind is explicit; unknown future requests still default to thorough. */
export const TUTOR_THINKING_MODES = {
  targetSearch: 'fast', liveSessionCredential: 'thorough', conversationOpening: 'thorough',
  conversationDemoCast: 'fast', conversationDemoBatch: 'fast', conversationCorrections: 'thorough',
  conversationDiagnosis: 'thorough', passageDiagnosis: 'thorough', conversationTakeHome: 'thorough', tailoredPrompt: 'thorough',
  practiceHint: 'fast', conversationHint: 'fast', lesson: 'thorough', example: 'thorough',
  exercises: 'thorough', review: 'thorough', reviewBatch: 'thorough', conversationStop: 'thorough',
  exampleQuestion: 'fast', practiceQuestion: 'fast', conversationTurn: 'fast', translate: 'fast'
} as const;

export function tutorFastModel(provider: LanguageModelRoutingProvider, configured: string | undefined, thorough: string): string {
  if (configured === '') return tutorModeModel(provider, 'thorough', thorough);
  const model = tutorModeModel(provider, 'fast', configured);
  return (provider === 'openai' || provider === 'anthropic') && model === TUTOR_MODELS[provider].fast
    ? tutorModeModel(provider, 'thorough', thorough) : model;
}

export function modeEffort(provider: LanguageModelRoutingProvider, model: string, mode: ThinkingMode,
  configured: LanguageModelRoutingEffort): LanguageModelRoutingEffort {
  if (mode === 'thorough') return configured === 'auto'
    ? provider === 'gemini' ? configuredThinkingLevel(model, 'auto') ?? 'none'
      : provider === 'openai' ? lowestOpenAIEffort(model)
        : provider === 'anthropic' ? lowestAnthropicEffort(model)
          : provider === 'groq' && /^openai\/gpt-oss-/u.test(model) ? 'low' : 'none'
    : provider === 'gemini' && configured !== 'none' ? configuredThinkingLevel(model, configured) ?? 'none' : configured;
  return provider === 'gemini' ? thinkingLevelForModel(model) ?? 'none'
    : provider === 'anthropic' ? lowestAnthropicEffort(model)
      : provider === 'groq' && /^openai\/gpt-oss-/u.test(model) ? 'low'
      : provider === 'openai' ? lowestOpenAIEffort(model) : 'none';
}

function lowestOpenAIEffort(model: string): LanguageModelRoutingEffort {
  return /^gpt-5\.[1-4](?:$|[-.])/u.test(model) ? 'none'
    : /^gpt-5(?:$|-)/u.test(model) ? 'minimal' : /^o\d/u.test(model) ? 'low' : 'auto';
}

function lowestAnthropicEffort(model: string): LanguageModelRoutingEffort {
  return /^claude-(?:opus-4-[56]|sonnet-4-6)(?:$|-)/u.test(model) ? 'low' : 'auto';
}

export const wordCount = (text: string): number => text.trim() ? text.trim().split(/\s+/u).length : 0;
export function adaptiveEffort(provider: LanguageModelRoutingProvider, model: string, text: string,
  configured: LanguageModelRoutingEffort): LanguageModelRoutingEffort {
  return modeEffort(provider, model, wordCount(text) <= 40 ? 'fast' : 'thorough', configured);
}


export function selectAdaptiveThinking(text: string, retry = false): { mode: ThinkingMode; reason?: 'retry' | 'long input' } {
  const mode: ThinkingMode = retry || wordCount(text) > 40 ? 'thorough' : 'fast';
  return { mode, ...(retry ? { reason: 'retry' as const } : mode === 'thorough' ? { reason: 'long input' as const } : {}) };
}
export function selectTutorThinking(kind: string, retry: boolean | undefined, learnerInput: string, transcriptTurns: number): {
  base: ThinkingMode; mode: ThinkingMode; reason?: 'retry' | 'long input'
} {
  const base = (TUTOR_THINKING_MODES as Record<string, ThinkingMode>)[kind] ?? 'thorough';
  const reason = base === 'fast' ? retry ? 'retry'
    : wordCount(learnerInput) > 40 || transcriptTurns > 10 ? 'long input' : undefined : undefined;
  return { base, mode: reason ? 'thorough' : base, ...(reason ? { reason } : {}) };
}
