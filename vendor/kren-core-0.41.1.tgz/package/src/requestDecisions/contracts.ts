import type { LanguageModelRoutingProvider, LanguageModelRoutingEffort } from '../languageModelRouting.js';
import { TUTOR_THINKING_MODES, type ThinkingMode } from './thinking.js';

export type RequestFeature = 'translate' | 'rewrite' | 'explain' | 'userDictionary' | 'grammar' | 'tutor';
export type RequestKind = Exclude<keyof typeof TUTOR_THINKING_MODES, 'liveSessionCredential'> | 'capture' | 'grammar' | 'rewrite' | 'explain';
export type FindingCode = 'unreadableOutput' | 'requiredField' | 'wordCount' | 'excerpt' | 'contentRejected' | 'refused';
export type FailureCause = 'noResponse' | 'authenticationRejected' | 'quotaExhausted' | 'rateLimit' |
  'overloaded' | 'serviceUnavailable' | 'requestRejected' | 'unreadableOutput' | 'contentRejected' | 'refused' | 'budget' | 'deadline';
export type ReaderAction = 'retry' | 'checkQuota' | 'setCredential' | 'configureProvider';

export interface RequestIdentity {
  feature: RequestFeature;
  kind: RequestKind;
  trigger: 'explicitAction' | 'existingPrefetch';
  signal: AbortSignal;
}
export interface AuthorizedPayload { readonly instruction: string; readonly input: string }
export interface RequestRoute {
  provider: LanguageModelRoutingProvider;
  geminiProfile: 'standard' | 'pro';
  model: string;
  mode: ThinkingMode;
  effort: LanguageModelRoutingEffort;
}
export interface SelectedRequestRoute extends RequestRoute {
  fastModel?: string;
  thoroughModel?: string;
  thoroughEffort?: LanguageModelRoutingEffort;
  fallback?: { model: string; effort: LanguageModelRoutingEffort };
}
export type ValidationResult<T> =
  | { type: 'accepted'; value: T }
  | { type: 'acceptedWithWarnings' | 'salvaged'; value: T; warnings: readonly FindingCode[] }
  | { type: 'rejected'; cause: 'unreadableOutput' | 'contentRejected' | 'refused'; codes: readonly FindingCode[] };

/** Named feature policies preserve the existing recovery differences. */
export interface RequestPolicy {
  temporaryServiceSwitch: 'geminiOnly';
  fallbackProfiles: 'tutorBothProfiles';
  contentRecovery: 'selectedLessonChecks' | 'singleReviewTerminal' | 'reviewAllItems' | 'localTakeHomeSalvage' | 'featureValidation';
  switchedAttemptSettings: 'actualProvider' | 'originalProvider';
  validationLogging: 'trackedFastAndDictionary' | 'deferredPanel';
  terminalPresentation: 'conversationActions' | 'fixedHint' | 'preservedWork' | 'validatorDetail';
  fallbackClaims: 'configuredLegacy' | 'attemptHistory';
  preflightObservation: 'quietLegacy' | 'decisionEvent';
  modeRouting: 'selectedModel' | 'tutorModels';
  openingAttemptCap?: 3;
  /** Smart Grammar historically performs model fallback after adaptive thinking has finished. */
  fallbackPlacement?: 'afterThinking';
}
const ordinaryPolicy: RequestPolicy = {
  temporaryServiceSwitch: 'geminiOnly', fallbackProfiles: 'tutorBothProfiles',
  contentRecovery: 'featureValidation', switchedAttemptSettings: 'actualProvider',
  validationLogging: 'deferredPanel', terminalPresentation: 'validatorDetail', fallbackClaims: 'attemptHistory',
  preflightObservation: 'decisionEvent', modeRouting: 'selectedModel'
};
const tutorPolicy: RequestPolicy = { ...ordinaryPolicy, fallbackProfiles: 'tutorBothProfiles',
  validationLogging: 'trackedFastAndDictionary', terminalPresentation: 'conversationActions', fallbackClaims: 'attemptHistory',
  modeRouting: 'tutorModels', openingAttemptCap: 3 };
export const CURRENT_REQUEST_POLICIES = {
  ordinary: ordinaryPolicy,
  tutor: tutorPolicy,
  userDictionary: { ...ordinaryPolicy,
    switchedAttemptSettings: 'actualProvider', validationLogging: 'trackedFastAndDictionary' },
  grammar: { ...ordinaryPolicy, switchedAttemptSettings: 'actualProvider', fallbackPlacement: 'afterThinking' },
  lesson: { ...tutorPolicy, contentRecovery: 'selectedLessonChecks', validationLogging: 'deferredPanel' },
  singleReview: { ...tutorPolicy, contentRecovery: 'singleReviewTerminal', validationLogging: 'deferredPanel' },
  reviewAll: { ...tutorPolicy, contentRecovery: 'reviewAllItems', validationLogging: 'deferredPanel' },
  takeHome: { ...tutorPolicy, contentRecovery: 'localTakeHomeSalvage', terminalPresentation: 'preservedWork', validationLogging: 'deferredPanel' },
  hint: { ...tutorPolicy, terminalPresentation: 'fixedHint' }
} as const satisfies Record<string, RequestPolicy>;

export interface RequestRecoveryPolicy {
  /** Already resolved host settings, including the retry-enabled toggle. Values are capped at five. */
  transportAttempts: Readonly<Record<LanguageModelRoutingProvider, number>>;
  escalation: 'once' | 'never';
  providerSwitch: boolean;
  providerOrder?: readonly LanguageModelRoutingProvider[];
  contentRetry: { allowance: number; correctiveInstruction: string; on: readonly FindingCode[] };
  policy: RequestPolicy;
}
export interface RequestBudget {
  /** Across the entire request, keyed by provider, profile, model, mode and effort. */
  perRouteAttempts: number;
  totalRequests: number;
  /** Absolute clock time in milliseconds. */
  deadline: number;
}
export interface CenterRequest<T> {
  identity: RequestIdentity;
  payload: AuthorizedPayload;
  route: SelectedRequestRoute;
  validate(value: unknown, route: RequestRoute): ValidationResult<T> | Promise<ValidationResult<T>>;
  recovery: RequestRecoveryPolicy;
  budget: RequestBudget;
  preservation?: 'none' | 'previousResult' | 'localFindings' | 'conversation';
}
/** One network attempt only. Credentials stay in the injected host transport. */
export interface TransportResponse {
  status: number;
  envelope?: unknown;
  value?: unknown;
  output?: 'empty' | 'refused';
  retryAfter?: string | null;
}
export interface AttemptHistory {
  attempt: number;
  route: RequestRoute;
  status?: number;
  outcome: 'accepted' | 'acceptedWithWarnings' | 'salvaged' | 'failed' | 'canceled';
  cause?: FailureCause;
  codes: readonly FindingCode[];
}
export type RecoveryDecision =
  | { decision: 'switch' | 'preflightSkip'; from: RequestRoute; to: RequestRoute; cause: 'quotaExhausted' | 'overloaded' }
  | { decision: 'fallback' | 'escalation'; from: RequestRoute; to: RequestRoute }
  | { decision: 'contentRetry' | 'salvage'; route: RequestRoute; codes: readonly FindingCode[] };
export type RequestOutcome<T> =
  | { type: 'accepted'; value: T; warnings: readonly FindingCode[]; route: RequestRoute; history: AttemptHistory[]; recovery: RecoveryDecision[] }
  | { type: 'failed'; cause: FailureCause; attemptedRoute?: RequestRoute; actions: readonly ReaderAction[];
      preservation: NonNullable<CenterRequest<T>['preservation']>; history: AttemptHistory[]; recovery: RecoveryDecision[] }
  | { type: 'canceled'; history: AttemptHistory[]; recovery: RecoveryDecision[] };
