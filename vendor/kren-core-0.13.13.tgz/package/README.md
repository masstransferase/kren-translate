# KREN Core

KREN Core contains host-independent language contracts, language routing, and
pure input validation shared by KREN for VS Code and KREN for Microsoft Office.

It contains no UI, editor or document access, credentials, provider keys,
storage, telemetry, native automation, or host metadata. Consumer applications
vendor a versioned package archive so every repository remains independently
cloneable and buildable.

See [SHARED_CORE_PLAN.md](SHARED_CORE_PLAN.md) and
[ACTION_ITEMS.md](ACTION_ITEMS.md). Future extraction is currently deferred
under [FUTURE_DEVELOPMENT_PLAN.md](FUTURE_DEVELOPMENT_PLAN.md) until the KREN
Office self-connection and lifecycle work produces an accepted baseline.
