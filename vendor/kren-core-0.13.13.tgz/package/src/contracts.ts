export type LanguageCode = string;
export type LanguageModelProviderId = 'gemini' | 'openai' | 'anthropic';
/**
 * The thinking or effort scale KREN offers, ordered from least committed to most.
 *
 * 'none' and 'minimal' were reachable only from the User Dictionary settings until
 * 2026-08-21, so Explain Nuance and Rewrite Text could not ask for less thinking than 'low'
 * even though every provider offers it. What each value becomes on the wire is per provider
 * and, for Gemini, per model; see geminiThinkingConfig in ./thinking.js.
 */
export type LanguageModelEffort = 'auto' | 'none' | 'minimal' | 'low' | 'medium' | 'high';

export type {
  RewriteDomain,
  RewriteEnglishVariety,
  RewriteRhetoricalMode
} from './rewriteAxes.js';

/**
 * Retired legacy tone setting. This migration-only type exists so a consumer can
 * read a stored value before migrating it; no new code should accept it.
 * @deprecated Use rewrite formality, voice, and stance axes for new code.
 */
export type RewriteTone = import('./rewriteAxes.js').LegacyRewriteTone;
/**
 * The two rewrites KREN produces. Minimal keeps the writer's wording and ignores the style
 * settings; Full is defined by them. See src/rewriteVariants.ts for why the previous three
 * were replaced on 2026-08-20.
 */
export type RewriteVariantId = 'minimal' | 'full';
/** BCP-47 language code, or `auto` for provider detection. */
export type RewriteSourceLanguage = string;

export interface RewriteVariant {
  id: RewriteVariantId;
  label: string;
  text: string;
  changeNote?: string;
}

export interface RewriteLanguageMetadata {
  /** User-selected BCP-47 source language, or auto for provider detection. */
  requestedSourceLanguage: RewriteSourceLanguage;
  /** Provider-detected or user-forced BCP-47 language of the rewritten text. */
  sourceLanguage: string;
}

export type GrammarDialect = 'american' | 'british' | 'australian' | 'canadian' | 'indian';
export type GrammarSuggestionKind = 'replace' | 'remove' | 'insertAfter';

export interface GrammarSuggestion {
  kind: GrammarSuggestionKind;
  replacement: string;
  label: string;
}

export interface GrammarIssue {
  id: string;
  start: number;
  end: number;
  original: string;
  category: string;
  message: string;
  suggestions: GrammarSuggestion[];
  ignoreHash?: string;
}

export interface GrammarChoice {
  issueId: string;
  suggestionIndex: number;
}

export interface GrammarSource {
  sourceText: string;
  issues: GrammarIssue[];
}

export interface DictionaryEntry {
  senseNumber?: string;
  grammaticalLabel?: string;
  partOfSpeech?: string;
  meaning: string;
  definition?: string;
  examples?: string[];
}

export interface DictionaryDiscussionBlock {
  kind: 'text' | 'example';
  text: string;
}

export interface DictionaryDiscussion {
  label?: string;
  text: string;
  examples?: string[];
  seeAlso?: string[];
  blocks?: DictionaryDiscussionBlock[];
}

export interface DictionarySection {
  headword: string;
  homograph?: number;
  partOfSpeech?: string;
  pronunciation?: string;
  audioUrl?: string;
  inflections?: string[];
  entries: DictionaryEntry[];
  synonymDiscussions?: DictionaryDiscussion[];
}

export interface ThesaurusWord {
  word: string;
  labels?: string[];
}

export interface ThesaurusSense {
  senseNumber?: string;
  definition?: string;
  synonyms: ThesaurusWord[];
  nearSynonyms?: ThesaurusWord[];
  relatedWords?: ThesaurusWord[];
  synonymousPhrases?: ThesaurusWord[];
  antonyms?: ThesaurusWord[];
  nearAntonyms?: ThesaurusWord[];
}

export interface ThesaurusSection {
  headword: string;
  partOfSpeech?: string;
  pronunciation?: string;
  audioUrl?: string;
  senses: ThesaurusSense[];
}
