/**
 * Every KREN control icon, defined once for every host.
 *
 * This is a table of SVG path data and nothing else, because the two hosts draw differently
 * and neither drawing method belongs in a host-independent package. The Office task pane
 * builds elements with `document.createElementNS`, since it never assigns `innerHTML`
 * anywhere. The VS Code panel builds a string, because a webview is served as HTML.
 *
 * What the hosts must share is the drawing itself, so a control means the same thing in
 * Word as it does in the editor. Two copies of a path table is the condition that lets one
 * host quietly acquire a different eraser.
 *
 * Every path is drawn on a 24 by 24 grid as an unfilled stroke, so a host sets `fill: none`,
 * `stroke: currentColor`, and its own stroke width. Following `currentColor` is what lets
 * one set of paths serve a light theme, a dark theme, and a danger colour with no second
 * set of assets.
 */
export const ICON_PATHS = {
  speaker: ['M4 9h3.2L12 5v14l-4.8-4H4zM15.8 9.6a4 4 0 0 1 0 4.8M18.4 7.2a8 8 0 0 1 0 9.6'],
  stop: ['M8 7.5h8a.5.5 0 0 1 .5.5v8a.5.5 0 0 1-.5.5H8a.5.5 0 0 1-.5-.5V8a.5.5 0 0 1 .5-.5z'],
  edit: ['M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3zM14.5 6.5l3 3'],
  delete: ['M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 12.5h9L17.5 7M10 10.5v6M14 10.5v6'],
  regenerate: ['M4 9.5a8 8 0 0 1 13.5-3.2L20 8.5M20 14.5A8 8 0 0 1 6.5 17.7L4 15.5M20 4.5v4h-4M4 19.5v-4h4'],
  save: ['M5 4.5h11L19.5 8v11.5H5zM8.5 4.5v5h7v-5M8.5 19.5V14h7v5.5'],
  // A cross inside a circle, which the owner chose from a reference image on 2026-08-19.
  cancel: ['M12 3.5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17', 'M8.6 8.6l6.8 6.8M15.4 8.6l-6.8 6.8'],
  clear: ['M8.5 19.5 4.6 15.6a2 2 0 0 1 0-2.8l8-8a2 2 0 0 1 2.8 0l4 4a2 2 0 0 1 0 2.8l-7 7zM9.5 19.5H20M9 9l6 6'],
  // Two arrows swapping places: Replace exchanges the text in the document for this draft.
  replace: ['M4 8.5h14.5M14.5 4.5l4 4-4 4M20 15.5H5.5M9.5 11.5l-4 4 4 4'],
  // A single anticlockwise arrow, distinct from the two-arrow regenerate cycle.
  reset: ['M4 12a8 8 0 1 0 2.34-5.66M4 4.5V10h5.5'],
  // A house, matching the header control the owner supplied as the reference for the set.
  home: ['M3 11.5 12 4l9 7.5M5.5 10.5V20h13v-9.5M9.5 20v-6h5v6'],
  menu: ['M4 6h16M4 12h16M4 18h16'],
  // Settings. A six-tooth gear drawn as one outline plus a centre circle, at the same
  // 24 by 24 stroke weight as the rest, so it sits beside Clear without redrawing the eye.
  settings: [
    'M10.3 3.5h3.4l.35 2.3a6.6 6.6 0 0 1 1.72 1l2.14-.9 1.7 2.95-1.79 1.48a6.7 6.7 0 0 1 0 1.98l1.79 1.48-1.7 2.95-2.14-.9a6.6 6.6 0 0 1-1.72 1l-.35 2.3h-3.4l-.35-2.3a6.6 6.6 0 0 1-1.72-1l-2.14.9-1.7-2.95 1.79-1.48a6.7 6.7 0 0 1 0-1.98L4.71 8.85l1.7-2.95 2.14.9a6.6 6.6 0 0 1 1.72-1z',
    'M12 9.4a2.6 2.6 0 1 1 0 5.2 2.6 2.6 0 0 1 0-5.2'
  ]
} as const satisfies Record<string, readonly string[]>;

export type IconName = keyof typeof ICON_PATHS;

export const ICON_NAMES = Object.keys(ICON_PATHS) as IconName[];

export function isIconName(value: string): value is IconName {
  return Object.hasOwn(ICON_PATHS, value);
}

/**
 * The icon as an SVG string, for a host that builds markup rather than elements.
 *
 * There is nothing to escape here. The argument is narrowed to a key of the table above, so
 * the only text that reaches the output is path data this file authored. A host that has a
 * plain string must pass it through `isIconName` first, which is what makes that true.
 */
export function iconSvgMarkup(name: IconName): string {
  const paths = ICON_PATHS[name].map((definition) => `<path d="${definition}"/>`).join('');
  return `<svg aria-hidden="true" viewBox="0 0 24 24">${paths}</svg>`;
}
