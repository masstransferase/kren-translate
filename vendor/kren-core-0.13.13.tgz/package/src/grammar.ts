import type { GrammarChoice, GrammarIssue, GrammarSource } from './contracts.js';
import { MINIMAL_CORRECTION_POLICY } from './rewriteVariants.js';

interface GrammarToken {
  text: string;
  start: number;
  end: number;
}

interface DiffOperation {
  kind: 'equal' | 'replace' | 'delete' | 'insert';
  oldIndex: number;
  newIndex: number;
}

interface ChangedRun {
  oldStart: number;
  oldEnd: number;
  newStart: number;
  newEnd: number;
}

interface GrammarEdit {
  start: number;
  end: number;
  replacement: string;
}

interface SmartGrammarEdit extends GrammarEdit {
  original: string;
}

export const SMART_GRAMMAR_RESPONSE_SCHEMA: Record<string, unknown> = {
  type: 'object',
  additionalProperties: false,
  required: ['correctedText'],
  properties: {
    correctedText: { type: 'string' }
  }
};

/**
 * What Smart Grammar Check looks for, in both hosts.
 *
 * **Usage was widened on 2026-08-20 at the owner's request.** The instruction had said
 * "Correct only grammar, spelling, punctuation, and agreement", then "Never change word
 * choice for style" and "Never change the register", which between them ruled out the
 * whole class this feature exists for. The owner writes English as a second language, and
 * "I played with my friends last weekend." is the shape their errors take: faultless
 * grammar, wrong register, because "play with" is what children do. Harper cannot see it
 * either, so nothing in KREN could.
 *
 * The line that keeps this from becoming a second rewriter is the distinction between
 * *wrong* and *different*. A phrasing a native speaker would not produce is wrong and gets
 * corrected. Two phrasings a native speaker uses interchangeably are both right, and the
 * writer's stands. Style belongs to Rewrite Text, which is a separate action the user
 * chooses deliberately.
 *
 * **The correction policy moved to MINIMAL_CORRECTION_POLICY on 2026-08-21**, so this and
 * Minimal Rewrite now read from one copy. They are the same job at two levels of
 * presentation: one hands back a draft, the other hands back the same corrections as
 * findings you accept one at a time. Two copies of that policy drifted, and the drift was
 * one-sided, because this one had the restraint clause and neither counterweight.
 *
 * What is left here is what is genuinely specific to this feature: the response shape, the
 * worked examples, and the sentence naming the error classes. Everything about how much to
 * change is imported, so a clause cannot be added to one feature and forgotten in the other.
 *
 * DEFAULT_SMART_GRAMMAR_MAX_CHANGED_PROPORTION is the backstop. A model that ignores all
 * of this and returns a restyled paragraph still has its answer discarded, so widening the
 * instruction did not widen what can reach the document.
 */
export const SMART_GRAMMAR_INSTRUCTION = [
  `Smart Grammar Check: ${MINIMAL_CORRECTION_POLICY}`,
  'Correct grammar, spelling, punctuation, and agreement as part of that set.',
  'Phrasing is wrong when a native speaker of the text\'s language would not say it: a collocation the language does not use, a verb or preposition that does not pair with its noun, a literal rendering of an idiom from another language, and vocabulary belonging to a register or an age group that does not fit the writer. A sentence containing no grammatical error can still be wrong in this way.',
  // OpenAI and Anthropic receive the schema, but Gemini cannot. The instruction
  // therefore repeats the shape literally, and a test keeps both statements aligned.
  'Return JSON only, with exactly this shape and no other keys:',
  '{"correctedText":"corrected text"}',
  'Return the complete corrected text in correctedText only. Do not return an explanation, notes, alternatives, or character offsets.',
  'Minimal-change example:',
  'Input: He showed up my office today',
  'Output: {"correctedText":"He showed up at my office today"}',
  'Register example, where the grammar is already correct:',
  'Input: I played with my friends last weekend.',
  'Output: {"correctedText":"I hung out with my friends last weekend."}',
  'Collocation example, where the grammar is already correct:',
  'Input: We discussed about the schedule.',
  'Output: {"correctedText":"We discussed the schedule."}',
  'No-change example:',
  'Input: The report is ready.',
  'Output: {"correctedText":"The report is ready."}'
].join('\n');

// One changed token in a two-token clause is a legitimate correction, while changing
// more than half of a longer input is more likely restyling than grammar repair.
export const DEFAULT_SMART_GRAMMAR_MAX_CHANGED_PROPORTION = 0.5;

/**
 * Returns undefined when the correction changes too much of the input to be trusted.
 * An empty array means the model returned the input unchanged.
 */
export function smartGrammarCorrectionToIssues(
  sourceText: string,
  correctedText: string,
  maximumChangedProportion = DEFAULT_SMART_GRAMMAR_MAX_CHANGED_PROPORTION
): GrammarIssue[] | undefined {
  if (!Number.isFinite(maximumChangedProportion) || maximumChangedProportion < 0 ||
      maximumChangedProportion > 1) {
    throw new RangeError('The Smart Grammar changed proportion must be between zero and one.');
  }
  if (sourceText === correctedText) return [];

  const sourceTokens = grammarTokens(sourceText);
  const correctedTokens = grammarTokens(correctedText);
  const { distance, operations } = alignTokens(sourceTokens, correctedTokens);
  const changedProportion = sourceTokens.length === 0
    ? (distance === 0 ? 0 : Number.POSITIVE_INFINITY)
    : distance / sourceTokens.length;
  if (changedProportion > maximumChangedProportion) return undefined;

  const runs = changedRuns(operations, sourceTokens.length, correctedTokens.length);
  const edits = runs.map((run) =>
    runEdit(sourceText, correctedText, sourceTokens, correctedTokens, run)
  );
  edits.push(...unchangedGapEdits(
    sourceText,
    correctedText,
    sourceTokens,
    correctedTokens,
    operations
  ));
  return edits
    .filter((edit) => edit.original !== edit.replacement)
    .sort((left, right) => left.start - right.start || left.end - right.end)
    .map((edit, index) =>
      smartGrammarIssue(edit.start, edit.end, edit.original, edit.replacement, index)
    );
}

export function applyGrammarChoices(
  result: GrammarSource,
  choices: readonly GrammarChoice[]
): string {
  const selected = new Map<string, number>();
  for (const choice of choices) {
    if (Number.isInteger(choice.suggestionIndex) && choice.suggestionIndex >= 0) {
      selected.set(choice.issueId, choice.suggestionIndex);
    }
  }

  // One choice selects one finding. Ids are unique in practice, from a counter in the
  // Harper worker and from start, end, and index in the smart corrections, but the
  // selection above is keyed by id, so a repeated id used to spend a single choice on every
  // finding wearing it. Two of those overlap by construction, which threw. Consuming the id
  // makes the code mean what `GrammarChoice` says.
  const spent = new Set<string>();
  const edits = result.issues.flatMap((issue) => {
    if (spent.has(issue.id)) return [];
    const suggestionIndex = selected.get(issue.id);
    if (suggestionIndex !== undefined) spent.add(issue.id);
    return selectedEdit(result.sourceText, issue, suggestionIndex);
  });
  edits.sort((left, right) => right.start - left.start || right.end - left.end);

  for (let index = 1; index < edits.length; index += 1) {
    const previous = edits[index - 1];
    const current = edits[index];
    if (previous && current && current.end > previous.start) {
      throw new Error('Overlapping grammar corrections cannot be applied together.');
    }
  }

  return edits.reduce(
    (text, edit) => text.slice(0, edit.start) + edit.replacement + text.slice(edit.end),
    result.sourceText
  );
}

/**
 * The choices a review panel should start on: the first suggestion of every finding that
 * has one, minus any that `applyGrammarChoices` would then refuse.
 *
 * The owner asked on 2026-08-20 for panels to open on the first suggestion rather than on
 * Keep original, because the common case is accepting what the checker found and starting
 * on Keep original made every finding a click.
 *
 * **Turning that default on is what makes `applyGrammarChoices` able to throw at all.**
 * While nothing was selected until a click, its two rejections were unreachable from an
 * opening state. Now the opening state is the first thing to meet them, so this function
 * has to rule out every finding they would reject, and it takes the whole `GrammarSource`
 * rather than the issues alone because one of those rejections is about the text:
 *
 * - **A span that meets one already chosen.** Two edits over the same characters cannot
 *   both be applied. Findings are walked in order and the later one is left on Keep
 *   original. A zero-width insertion at an offset inside a chosen replacement counts as
 *   meeting it, which is correct: they overlap when applied. Two zero-width insertions at
 *   the same offset do not meet, and core applies both.
 * - **A span whose text no longer reads as the finding described it**, which covers a
 *   stale range and a reversed one, since `slice(4, 2)` is empty and matches no original.
 * - **A repeated issue id.** `GrammarChoice` names a finding by id and `applyGrammarChoices`
 *   keys its selection by id, so a second finding under one id would silently select both.
 *   Ids are unique in practice, from a counter in the Harper worker and from start, end,
 *   and index in the smart corrections, so this is defence rather than a fix.
 *
 * The result therefore always applies without throwing. That is asserted in the tests by
 * feeding this function's output straight back into `applyGrammarChoices`, rather than by
 * this comment saying so. Deciding here rather than in each host is what keeps the rule and
 * `editSpan` below in the same file, reading the same insertion convention.
 */
export function preselectedGrammarChoices(source: GrammarSource): GrammarChoice[] {
  const chosen: GrammarChoice[] = [];
  const spans: GrammarEdit[] = [];
  const seenIds = new Set<string>();
  for (const issue of source.issues) {
    const suggestion = issue.suggestions[0];
    if (!suggestion) continue;
    if (seenIds.has(issue.id)) continue;
    seenIds.add(issue.id);
    if (source.sourceText.slice(issue.start, issue.end) !== issue.original) continue;
    const span = editSpan(issue, suggestion.kind === 'insertAfter');
    if (spans.some((taken) => span.start < taken.end && taken.start < span.end)) continue;
    chosen.push({ issueId: issue.id, suggestionIndex: 0 });
    spans.push(span);
  }
  return chosen;
}

function editSpan(issue: GrammarIssue, insertion: boolean): GrammarEdit {
  return {
    start: insertion ? issue.end : issue.start,
    end: issue.end,
    replacement: ''
  };
}

function selectedEdit(
  sourceText: string,
  issue: GrammarIssue,
  suggestionIndex: number | undefined
): GrammarEdit[] {
  if (suggestionIndex === undefined) return [];
  const suggestion = issue.suggestions[suggestionIndex];
  if (!suggestion) return [];
  if (sourceText.slice(issue.start, issue.end) !== issue.original) {
    throw new Error('A grammar issue no longer matches the checked text.');
  }

  // Through editSpan, so the preselection above and the application here cannot disagree
  // about where an insertion lands. They did not have to agree while nothing was selected
  // by default; now a disagreement would preselect a set core then refuses to apply.
  return [{ ...editSpan(issue, suggestion.kind === 'insertAfter'), replacement: suggestion.replacement }];
}

function grammarTokens(text: string): GrammarToken[] {
  const tokens: GrammarToken[] = [];
  const pattern = /[\p{L}\p{M}\p{N}]+(?:['\u2019-][\p{L}\p{M}\p{N}]+)*|[^\s]/gu;
  for (const match of text.matchAll(pattern)) {
    const value = match[0];
    const start = match.index;
    tokens.push({ text: value, start, end: start + value.length });
  }
  return tokens;
}

function alignTokens(
  source: readonly GrammarToken[],
  corrected: readonly GrammarToken[]
): { distance: number; operations: DiffOperation[] } {
  const distances = Array.from(
    { length: source.length + 1 },
    () => Array<number>(corrected.length + 1).fill(0)
  );
  for (let oldIndex = source.length; oldIndex >= 0; oldIndex -= 1) {
    for (let newIndex = corrected.length; newIndex >= 0; newIndex -= 1) {
      if (oldIndex === source.length) {
        distances[oldIndex]![newIndex] = corrected.length - newIndex;
      } else if (newIndex === corrected.length) {
        distances[oldIndex]![newIndex] = source.length - oldIndex;
      } else if (source[oldIndex]!.text === corrected[newIndex]!.text) {
        distances[oldIndex]![newIndex] = distances[oldIndex + 1]![newIndex + 1]!;
      } else {
        distances[oldIndex]![newIndex] = 1 + Math.min(
          distances[oldIndex + 1]![newIndex + 1]!,
          distances[oldIndex + 1]![newIndex]!,
          distances[oldIndex]![newIndex + 1]!
        );
      }
    }
  }

  const operations: DiffOperation[] = [];
  let oldIndex = 0;
  let newIndex = 0;
  while (oldIndex < source.length || newIndex < corrected.length) {
    if (oldIndex < source.length && newIndex < corrected.length &&
        source[oldIndex]!.text === corrected[newIndex]!.text) {
      operations.push({ kind: 'equal', oldIndex, newIndex });
      oldIndex += 1;
      newIndex += 1;
      continue;
    }

    const replacement = oldIndex < source.length && newIndex < corrected.length
      ? distances[oldIndex + 1]![newIndex + 1]!
      : Number.POSITIVE_INFINITY;
    const deletion = oldIndex < source.length
      ? distances[oldIndex + 1]![newIndex]!
      : Number.POSITIVE_INFINITY;
    const insertion = newIndex < corrected.length
      ? distances[oldIndex]![newIndex + 1]!
      : Number.POSITIVE_INFINITY;
    if (replacement <= deletion && replacement <= insertion) {
      operations.push({ kind: 'replace', oldIndex, newIndex });
      oldIndex += 1;
      newIndex += 1;
    } else if (deletion <= insertion) {
      operations.push({ kind: 'delete', oldIndex, newIndex });
      oldIndex += 1;
    } else {
      operations.push({ kind: 'insert', oldIndex, newIndex });
      newIndex += 1;
    }
  }

  return { distance: distances[0]![0]!, operations };
}

function changedRuns(
  operations: readonly DiffOperation[],
  sourceLength: number,
  correctedLength: number
): ChangedRun[] {
  const runs: ChangedRun[] = [];
  let operationIndex = 0;
  while (operationIndex < operations.length) {
    const first = operations[operationIndex]!;
    if (first.kind === 'equal') {
      operationIndex += 1;
      continue;
    }
    const oldStart = first.oldIndex;
    const newStart = first.newIndex;
    while (operationIndex < operations.length &&
           operations[operationIndex]!.kind !== 'equal') {
      operationIndex += 1;
    }
    const next = operations[operationIndex];
    runs.push({
      oldStart,
      oldEnd: next?.oldIndex ?? sourceLength,
      newStart,
      newEnd: next?.newIndex ?? correctedLength
    });
  }
  return runs;
}

function runEdit(
  sourceText: string,
  correctedText: string,
  sourceTokens: readonly GrammarToken[],
  correctedTokens: readonly GrammarToken[],
  run: ChangedRun
): SmartGrammarEdit {
  if (run.oldStart < run.oldEnd && run.newStart < run.newEnd) {
    const firstSource = sourceTokens[run.oldStart]!;
    const lastSource = sourceTokens[run.oldEnd - 1]!;
    const firstCorrection = correctedTokens[run.newStart]!;
    const lastCorrection = correctedTokens[run.newEnd - 1]!;
    return {
      start: firstSource.start,
      end: lastSource.end,
      original: sourceText.slice(firstSource.start, lastSource.end),
      replacement: correctedText.slice(firstCorrection.start, lastCorrection.end)
    };
  }

  if (run.oldStart === run.oldEnd) {
    const nextSource = sourceTokens[run.oldStart];
    const firstCorrection = correctedTokens[run.newStart]!;
    const nextCorrection = correctedTokens[run.newEnd];
    const start = nextSource?.start ?? sourceText.length;
    const replacementStart = nextCorrection
      ? firstCorrection.start
      : (correctedTokens[run.newStart - 1]?.end ?? firstCorrection.start);
    const replacementEnd = nextCorrection?.start ?? correctedText.length;
    return {
      start,
      end: start,
      original: '',
      replacement: correctedText.slice(replacementStart, replacementEnd)
    };
  }

  const firstSource = sourceTokens[run.oldStart]!;
  const nextSource = sourceTokens[run.oldEnd];
  const previousSource = sourceTokens[run.oldStart - 1];
  const start = nextSource ? firstSource.start : (previousSource?.end ?? firstSource.start);
  const end = nextSource?.start ?? sourceText.length;
  return {
    start,
    end,
    original: sourceText.slice(start, end),
    replacement: ''
  };
}

function unchangedGapEdits(
  sourceText: string,
  correctedText: string,
  sourceTokens: readonly GrammarToken[],
  correctedTokens: readonly GrammarToken[],
  operations: readonly DiffOperation[]
): SmartGrammarEdit[] {
  if (operations.length === 0) {
    return sourceText === correctedText
      ? []
      : [{ start: 0, end: sourceText.length, original: sourceText, replacement: correctedText }];
  }

  const edits: SmartGrammarEdit[] = [];
  for (let index = 0; index < operations.length; index += 1) {
    const current = operations[index]!;
    if (current.kind !== 'equal') continue;
    const currentSource = sourceTokens[current.oldIndex]!;
    const currentCorrection = correctedTokens[current.newIndex]!;
    if (index === 0) {
      addGapEdit(edits, sourceText, correctedText, 0, currentSource.start, 0,
        currentCorrection.start);
    }

    const previous = operations[index - 1];
    if (previous?.kind === 'equal') {
      const previousSource = sourceTokens[previous.oldIndex]!;
      const previousCorrection = correctedTokens[previous.newIndex]!;
      addGapEdit(
        edits,
        sourceText,
        correctedText,
        previousSource.end,
        currentSource.start,
        previousCorrection.end,
        currentCorrection.start
      );
    }

    if (index === operations.length - 1) {
      addGapEdit(
        edits,
        sourceText,
        correctedText,
        currentSource.end,
        sourceText.length,
        currentCorrection.end,
        correctedText.length
      );
    }
  }
  return edits;
}

function addGapEdit(
  edits: SmartGrammarEdit[],
  sourceText: string,
  correctedText: string,
  sourceStart: number,
  sourceEnd: number,
  correctedStart: number,
  correctedEnd: number
): void {
  const original = sourceText.slice(sourceStart, sourceEnd);
  const replacement = correctedText.slice(correctedStart, correctedEnd);
  if (original !== replacement) {
    edits.push({ start: sourceStart, end: sourceEnd, original, replacement });
  }
}

function smartGrammarIssue(
  start: number,
  end: number,
  original: string,
  replacement: string,
  index: number
): GrammarIssue {
  const originalLabel = original.trim();
  const replacementLabel = replacement.trim();
  const spacingOnly = originalLabel === '' && replacementLabel === '';
  const message = spacingOnly
    ? 'Smart Grammar Check suggests changing the spacing.'
    : originalLabel === ''
    ? `Smart Grammar Check suggests inserting "${replacementLabel}".`
    : replacementLabel === ''
      ? `Smart Grammar Check suggests removing "${originalLabel}".`
      : `Smart Grammar Check suggests changing "${originalLabel}" to "${replacementLabel}".`;
  return {
    id: `smart-grammar-${start}-${end}-${index}`,
    start,
    end,
    original,
    category: 'grammar',
    message,
    suggestions: [{
      kind: replacement === '' ? 'remove' : 'replace',
      replacement,
      label: spacingOnly ? 'Change spacing' : replacementLabel || 'Remove'
    }]
  };
}

/**
 * The selection split into the whitespace the user swept up and the text they meant.
 *
 * Selecting a sentence in Word very often takes a leading or trailing space with it, and
 * KREN used to send that whitespace to Harper and to the model. Neither has anything useful
 * to say about it, and the model in particular returns the text trimmed, so the difference
 * between what was sent and what came back included the whitespace itself. That produced
 * findings at the edges of the selection that correct nothing, and accepting them silently
 * removed spacing the writer had put there.
 *
 * The affixes are kept rather than discarded so replacement can put them back. Trimming
 * without restoring would eat the space between two words in the document, which is a
 * quieter and worse failure than the one being fixed.
 */
export interface TrimmedSelection {
  readonly leading: string;
  readonly text: string;
  readonly trailing: string;
}

export function trimSelectionForChecking(selection: string): TrimmedSelection {
  // A selection of nothing but whitespace has no text to check. It is reported as empty
  // text with the whole selection as its leading affix, so restoring still returns exactly
  // what the writer had.
  const match = /^(\s*)([\s\S]*?)(\s*)$/u.exec(selection);
  if (!match) return { leading: '', text: selection, trailing: '' };
  return { leading: match[1] ?? '', text: match[2] ?? '', trailing: match[3] ?? '' };
}

/**
 * Collapses runs of repeated spaces to one.
 *
 * The owner's rule, 2026-08-21: a single space at either edge of the selection is not an
 * error and must never be reported, while two or more spaces are an error wherever they
 * appear, including at the edges.
 *
 * **A value containing a line break is returned untouched.** A blank line between
 * paragraphs is structure, not repeated spacing, and collapsing it would join two
 * paragraphs. That is a worse edit than the one being made and the pane cannot undo it.
 */
export function collapseRepeatedSpaces(value: string): string {
  if (/[\r\n]/u.test(value)) return value;
  return value.replace(/ {2,}/gu, ' ');
}

export function restoreSelectionAffixes(
  trimmed: TrimmedSelection,
  replacement: string
): string {
  const leading = collapseRepeatedSpaces(trimmed.leading);
  const trailing = collapseRepeatedSpaces(trimmed.trailing);
  return `${leading}${replacement}${trailing}`;
}

/**
 * A finding for every run of two or more spaces inside the checked text.
 *
 * KREN produces these itself rather than hoping a checker notices. Harper's ruleset is not
 * guaranteed to cover repeated spacing, and Smart Grammar Check is a language model, so
 * neither is a dependable answer to "is the spacing right". This is decidable by looking,
 * so it is decided by looking.
 *
 * They are ordinary findings, so they appear in the review list, arrive already chosen like
 * every other first suggestion, and can be rejected individually. The owner's example on
 * 2026-08-21 was "I am fine.  Your  parents?", which carries two of them.
 */
export function repeatedSpaceIssues(sourceText: string): GrammarIssue[] {
  const issues: GrammarIssue[] = [];
  for (const match of sourceText.matchAll(/ {2,}/gu)) {
    const start = match.index;
    const original = match[0];
    issues.push({
      id: `spacing-${start}-${original.length}`,
      start,
      end: start + original.length,
      original,
      category: 'style',
      message: `${original.length} spaces where one is expected.`,
      suggestions: [{ kind: 'replace', replacement: ' ', label: 'one space' }]
    });
  }
  return issues;
}
