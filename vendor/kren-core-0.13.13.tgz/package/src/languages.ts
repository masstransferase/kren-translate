export interface KrenLanguage {
  code: string;
  name: string;
}

export const AUTO_ENGLISH_KOREAN_TARGET = 'auto-en-ko';
export const AUTO_REWRITE_SOURCE_LANGUAGE = 'auto';

export const KREN_LANGUAGES: readonly KrenLanguage[] = [
  { code: 'ar', name: 'Arabic' },
  { code: 'bn', name: 'Bengali' },
  { code: 'bg', name: 'Bulgarian' },
  { code: 'zh-CN', name: 'Chinese (Simplified)' },
  { code: 'zh-TW', name: 'Chinese (Traditional)' },
  { code: 'hr', name: 'Croatian' },
  { code: 'cs', name: 'Czech' },
  { code: 'da', name: 'Danish' },
  { code: 'nl', name: 'Dutch' },
  { code: 'en', name: 'English' },
  { code: 'et', name: 'Estonian' },
  { code: 'fil', name: 'Filipino' },
  { code: 'fi', name: 'Finnish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'el', name: 'Greek' },
  { code: 'he', name: 'Hebrew' },
  { code: 'hi', name: 'Hindi' },
  { code: 'hu', name: 'Hungarian' },
  { code: 'id', name: 'Indonesian' },
  { code: 'it', name: 'Italian' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ko', name: 'Korean' },
  { code: 'lv', name: 'Latvian' },
  { code: 'lt', name: 'Lithuanian' },
  { code: 'ms', name: 'Malay' },
  { code: 'no', name: 'Norwegian' },
  { code: 'fa', name: 'Persian' },
  { code: 'pl', name: 'Polish' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ro', name: 'Romanian' },
  { code: 'ru', name: 'Russian' },
  { code: 'sr', name: 'Serbian' },
  { code: 'sk', name: 'Slovak' },
  { code: 'sl', name: 'Slovenian' },
  { code: 'es', name: 'Spanish' },
  { code: 'sw', name: 'Swahili' },
  { code: 'sv', name: 'Swedish' },
  { code: 'ta', name: 'Tamil' },
  { code: 'te', name: 'Telugu' },
  { code: 'th', name: 'Thai' },
  { code: 'tr', name: 'Turkish' },
  { code: 'uk', name: 'Ukrainian' },
  { code: 'ur', name: 'Urdu' },
  { code: 'vi', name: 'Vietnamese' }
] as const;

export function languageName(code: string): string {
  if (code === 'auto') return 'Auto-detect';
  if (code === AUTO_ENGLISH_KOREAN_TARGET) {
    return 'Auto: English to Korean or Korean to English';
  }
  if (code === 'bilingual') return 'English and Korean';
  return KREN_LANGUAGES.find((language) => language.code === code)?.name ?? code;
}

export function isEnglishLanguageCode(code: string): boolean {
  return /^en(?:-|$)/iu.test(code.trim());
}

export function isSupportedTargetLanguage(code: string): boolean {
  return KREN_LANGUAGES.some((language) => language.code === code);
}

export function containsKorean(text: string): boolean {
  return /[\u1100-\u11ff\u3130-\u318f\ua960-\ua97f\uac00-\ud7af\ud7b0-\ud7ff]/u.test(text);
}

export function resolveTranslationTarget(text: string, selectedTarget: string): string {
  if (selectedTarget !== AUTO_ENGLISH_KOREAN_TARGET) return selectedTarget;
  return containsKorean(text) ? 'en' : 'ko';
}
