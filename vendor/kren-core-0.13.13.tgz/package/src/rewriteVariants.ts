import type { RewriteVariantId } from './contracts.js';

/**
 * The two rewrites KREN produces, and the words that ask for each.
 *
 * The owner replaced three variants with these two on 2026-08-20, and the reason is that
 * the old three fought the style axes rather than composing with them:
 *
 * - **Concise contradicted the Length axis.** With Length set to expand, the Concise
 *   variant was still told to be tighter and more direct, so one prompt argued with itself.
 * - **Jargon-Free contradicted the Domain axis.** Domain technical asks for domain
 *   terminology and Jargon-Free stripped it, then walked it back with an exception. It was
 *   also redundant: `plainEnglish` is the first entry in REWRITE_MODES and does the same
 *   job through the axes, where it composes with everything else.
 * - **Natural was the axes applied**, which is what Full Rewrite is, under a vaguer name.
 *
 * What the two now differ in is whether the style settings apply at all. Minimal ignores
 * them; Full is defined by them. That is the only difference, and it is why a caller must
 * add the axis instructions to Full alone.
 */
/**
 * How to correct a text without rewriting it, stated once for both features that do it.
 *
 * Minimal Rewrite and Smart Grammar Check are the same job at two levels of presentation:
 * one returns a draft, the other returns the same corrections as individually acceptable
 * findings. They had separate instructions until 2026-08-21, and they drifted, which is
 * this repository's characteristic defect rather than a surprise.
 *
 * The drift was one-sided and the owner found it. Smart Grammar Check carried the restraint
 * clause and neither counterweight: it said "make the smallest possible change", then "never
 * change wording you would merely have chosen differently", then "if a native speaker would
 * have written the input as it stands, return it unchanged", with nothing anywhere saying
 * that changing nothing can also be wrong. Three clauses telling it to hold still and none
 * telling it to move is the same shape as the instruction that failed on 2026-08-20, and it
 * failed the same way: given "I am doing fine. What about your parents?", Minimal Rewrite
 * corrected it and Smart Grammar Check returned it untouched.
 *
 * So the policy lives here and both import it. A clause added to one is now added to both,
 * and neither can quietly acquire a bias the other lacks.
 */
export const MINIMAL_CORRECTION_POLICY = [
  'find the smallest set of changes that makes the text',
  'native-speaker-grade in the detected language, and apply exactly that set.',
  'Treat this as a constrained minimization rather than a preference.',
  'The constraint is that every phrase in the result is one a native speaker would produce.',
  'The quantity you minimize is the number of the writer\'s phrases you change.',
  'Changing nothing fails the constraint wherever a phrase is not native, and changing a',
  'phrase that already satisfies the constraint is not minimal. Both are wrong answers.',
  'When every phrase in the input is already one a native speaker would produce, the empty',
  'set of changes is the correct answer, and you return the text unchanged.',
  'Word choice is the level you work at here. Work phrase by phrase, and for each phrase',
  'ask whether a native speaker would produce it. If they would not, change that phrase.',
  'If they would, keep the writer\'s phrase, even where you would have written something else.',
  'Never change wording you would merely have chosen differently: where a native speaker',
  'would use either phrasing, the writer\'s phrasing is correct and stays.',
  'Correcting one phrase is not a licence to revise the phrases around it, and a sentence',
  'containing one error is not thereby open for rewriting.',
  'When you genuinely cannot decide whether a native speaker would produce a phrase, change it.',
  'Keep the sentence order, the paragraph structure, the point of view, and the level of',
  'detail. Do not restructure a sentence, do not merge or split sentences, do not shorten',
  'or expand, and do not apply any style setting.',
  'Add nothing the writer did not state, including a possessive or a relationship the',
  'original left open.',
  'The result should still sound like the writer, and keeping their sentence order and',
  'their level of detail is what achieves that; it is not a reason to keep a word a native',
  'speaker would not have used.'
].join(' ');

export const REWRITE_VARIANTS = [
  {
    id: 'minimal',
    label: 'Minimal Rewrite',
    /**
     * The owner writes English as a second language and wants their own sentence back,
     * corrected. This sits between Grammar Check, which only offers fixes for findings a
     * rule matched, and a full rewrite, which is allowed to say it differently.
     *
     * **The first version of this instruction contradicted itself and lost.** It opened with
     * "change as little as possible", then said "Keep the writer's own wording", and only
     * then asked for wording changes wherever the original read as non-native. Two of the
     * three clauses told the model to hold still, and the first two came first. On
     * 2026-08-20 the owner submitted "I played with my friends last weekend." and got it
     * back unchanged, where a native speaker says "hung out with" or "spent time with";
     * "played with" is what children do, so the sentence is faultless grammar in the wrong
     * register. Fixing it requires changing wording, which the instruction forbade.
     *
     * What "minimal" now means is the **level** the rewrite works at, which is word choice,
     * rather than the **quantity** of change. Nothing here tells the model to prefer holding
     * still, because a model facing an unresolved conflict takes the safest reading and the
     * safest reading was doing nothing.
     *
     * **Refined again on 2026-08-21, after the opposite failure.** Given "Although he worked
     * very hard to finish the project on time, but the manager still criticized him.", which
     * carries exactly one error, it returned "Even though he worked very hard to finish the
     * project on time, his manager still criticized him." It deleted "but", correctly, then
     * also replaced "Although" and added a possessive, neither of which was wrong.
     *
     * The cause was the previous tie-breaker: "returning a sentence unchanged is correct only
     * when a native speaker would have written it word for word", together with "when you are
     * unsure, change the wording rather than keep it". Word for word is a whole-sentence bar,
     * so one bad conjunction failed the entire sentence and nothing then said where to stop.
     * The bar is per phrase now, the bias toward changing survives only where a phrase is
     * genuinely undecidable, and the restraint clause Smart Grammar Check already carried is
     * here too. Both failures appear in REWRITE_WORKED_EXAMPLE, one demonstrating a change and
     * one demonstrating stopping, because the owner's evidence is that demonstrations move
     * this model where rules did not.
     */
    instruction: `Minimal Rewrite: ${MINIMAL_CORRECTION_POLICY}`
  },
  {
    id: 'full',
    label: 'Full Rewrite',
    /**
     * Every axis instruction is appended after this one by the caller. Without them this
     * says almost nothing, which is correct: this variant is defined by the settings.
     *
     * **Two failures on 2026-08-20, from the same sentence.** At default settings it
     * returned "During the previous weekend, I spent time playing with my friends.", which
     * is longer and more roundabout than the original and still carries the unidiomatic
     * "playing with my friends". In Plain English mode it returned the input unchanged.
     *
     * Both follow from what this variant was told. "Rewriting sentence structure is
     * expected here" is a licence to restructure with no reason to, and at default settings
     * only three axis lines are emitted, none of which asks for anything in particular. A
     * mode that asks for plainer prose then finds nothing to simplify and stops. The
     * requirement that the result read as a native speaker wrote it now lives in
     * REWRITE_OUTPUT_RULES, which both variants and every mode receive.
     */
    instruction: [
      'Full Rewrite: rewrite the text to satisfy the style settings that follow,',
      'in the detected language, preserving every claim, qualification, number, and citation.',
      'Restructuring a sentence is expected wherever a setting calls for it.',
      'Where no setting calls for a change, do not restructure for its own sake, and never',
      'make the text longer, more roundabout, or more formal than the original.',
      'Where two rewrites would both satisfy the settings, choose the one that changes less',
      'of the writer\'s text.'
    ].join(' ')
  }
] as const satisfies readonly { id: RewriteVariantId; label: string; instruction: string }[];

export const REWRITE_VARIANT_IDS: readonly RewriteVariantId[] =
  REWRITE_VARIANTS.map((variant) => variant.id);

export function rewriteVariantLabel(id: RewriteVariantId): string {
  return REWRITE_VARIANTS.find((variant) => variant.id === id)?.label ?? id;
}

/**
 * What every variant and every mode must do, and must never do.
 *
 * The prohibitions are the owner's global rule, taken from what used to be the Jargon-Free
 * variant. As a rule it composes with the Domain axis instead of arguing with it: KREN
 * never *adds* this material, and removing what the writer already put there is what the
 * Plain English mode is for. Stating it as a prohibition rather than a variant is what
 * makes both true at once.
 *
 * **The native-speaker requirement was added here on 2026-08-20, and where it lives is the
 * point.** It had existed only inside the Minimal Rewrite instruction, so no other path
 * carried it: Full Rewrite at default settings never asked for idiom, and Plain English
 * mode returned "I played with my friends last weekend." unchanged, because it was asked
 * to simplify prose that was already simple and nothing told it the phrasing was the
 * problem. One requirement in one place, received by both variants and every mode, is why
 * a mode can no longer be a way to opt out of it.
 *
 * The second line is the one that does the work. "Correct grammar" is not enough, because
 * the sentence that failed had no grammatical error; what it had was a verb belonging to a
 * different register, and a model needs to be told that counts.
 */
/**
 * The first line of the request, above everything else.
 *
 * **Position was the remaining fault, and the owner found it by experiment on
 * 2026-08-20.** Given only "Number one priority is natural English, native-speaker-grade",
 * the same style profile, and the same sentence, Gemini returned "I hung out with my
 * friends last night." KREN, holding the identical requirement at line 8 of 24 behind
 * three preservation lines, returned the input unchanged.
 *
 * Nothing was missing by then. The requirement was present, shared, and correctly worded.
 * It was outranked: a request whose opening lines are "Rewrite only the exact text",
 * "Preserve intentional mixed-language terms", "Preserve factual meaning" establishes
 * caution as the frame, and one line arriving later does not displace it. Ranking is not
 * decoration in a prompt; a model reads earlier instructions as governing later ones.
 *
 * This is why it says "first priority" and says outright that nothing else outranks it.
 */
export const REWRITE_PRIORITY_RULE = [
  'Your first priority is natural, native-speaker-grade phrasing in the detected language.',
  'Every other instruction below constrains how you achieve that. None of them is a reason',
  'to leave unnatural phrasing in place.'
].join(' ');

/**
 * A demonstration, because the owner's evidence is that a rule alone did not move the
 * model and Smart Grammar Check, which carries examples, behaved differently on the same
 * sentence. The input has no grammatical error, which is the case a rewriter is most
 * likely to pass over, so this shows both variants changing it anyway.
 */
export const REWRITE_WORKED_EXAMPLE = [
  'Worked example one. The input contains no grammatical error and both variants must still change it:',
  'Input: I played with my friends last weekend.',
  'Minimal Rewrite: I hung out with my friends last weekend.',
  'Full Rewrite: I spent time with my friends last weekend.',
  'Returning the input unchanged would be wrong, because an adult English speaker does not play with friends.',
  'Worked example two. The input contains one error, and Minimal Rewrite corrects that error and nothing else:',
  'Input: Although he worked very hard to finish the project on time, but the manager still criticized him.',
  'Minimal Rewrite: Although he worked very hard to finish the project on time, the manager still criticized him.',
  'Only "but" is removed, because English takes the subordinator or the coordinator and not both. "Although" stays, because a native speaker writes it, so changing it to "Even though" would be a preference rather than a correction. "the manager" stays, because it is natural English and "his manager" would add a relationship the writer did not state.'
].join('\n');

export const REWRITE_OUTPUT_RULES = [
  'Every variant must read as though a native speaker of the detected language wrote it.',
  'Correct phrasing that is grammatical but is not what a native speaker would say: collocations the language does not use, a verb or preposition that does not pair with its noun, a literal rendering of an idiom from another language, and vocabulary belonging to a register or an age group that does not fit the writer. A sentence containing no grammatical error can still need this, and leaving such a sentence untouched is a failure rather than a safe choice.',
  'Never introduce buzzwords, cliches, corporate jargon, or decorative metaphor.',
  'Keep precise domain terms the text needs to stay correct.',
  'Never use an em dash or an en dash.'
] as const;
