// This module is the only place in the package that imports Node builtins, and the only
// one reachable through the ./user-dictionary-node entry point. @types/node is a dev
// dependency so this file typechecks here; it is not a runtime dependency and the
// browser-safe entry points cannot reach this file, which publicSurface.test.ts proves
// by walking the import graph.
//
// These imports carried @ts-expect-error until 2026-08-16, on the reasoning that core
// has no type dependencies. That broke every consumer: core ships TypeScript source, so
// the consumer compiles this file, and a consumer that does have @types/node sees the
// directives as unused and fails with TS2578. It was found by the Office bridge, not by
// core's own typecheck, which is the same shape as the node:crypto defect that made this
// entry point necessary: a host assumption is invisible in the host where it holds.
import { randomUUID } from 'node:crypto';
import { AsyncLocalStorage } from 'node:async_hooks';
import { mkdir, open, readFile, readdir, realpath, rename, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import {
  emptyUserDictionaryStore,
  exportUserDictionaryJson,
  importUserDictionaryJson
} from './index.js';

export const USER_DICTIONARY_STORAGE_ERROR_CODES = [
  'corruptStore',
  'lockLost',
  'lockTimeout',
  'reentrantAccess',
  'staleWrite',
  'storageFailure'
] as const;

export type UserDictionaryStorageErrorCode =
  typeof USER_DICTIONARY_STORAGE_ERROR_CODES[number];

export class UserDictionaryStorageError extends Error {
  public constructor(
    public readonly code: UserDictionaryStorageErrorCode,
    message: string,
    cause?: unknown
  ) {
    super(message, { cause });
    this.name = 'UserDictionaryStorageError';
  }
}

type UserDictionaryStore = ReturnType<typeof emptyUserDictionaryStore>;
interface LockHandle {
  close(): Promise<void>;
  sync(): Promise<void>;
  write(
    content: string,
    position: number,
    encoding: 'utf8'
  ): Promise<{ bytesWritten: number }>;
  writeFile(content: string, encoding: 'utf8'): Promise<void>;
}

export interface UserDictionaryStorageOptions {
  commitTemporaryFile?: (temporaryPath: string, filePath: string) => Promise<void>;
  closeLockHandle?: (handle: LockHandle) => Promise<void>;
  lockRetryMs?: number;
  lockWaitMs?: number;
  staleLockAgeMs?: number;
}

const DEFAULT_LOCK_RETRY_MS = 25;
const DEFAULT_LOCK_WAIT_MS = 5_000;
const DEFAULT_STALE_LOCK_AGE_MS = 30_000;

/**
 * Operations are serialized exactly within this process by a shared per-directory
 * promise chain. The file lock provides only best-effort cross-process coordination.
 * A second process can still, in a narrow window inside commitTemporaryFile, displace
 * a live lock and have its change overwritten. This limitation is knowingly accepted
 * on 2026-08-16, rather than unnoticed, because three attempts to close it each
 * revealed a further check-to-rename gap.
 */
export class UserDictionaryStorage {
  private static readonly operationChains = new Map<string, Promise<void>>();
  private static readonly operationContexts = new AsyncLocalStorage<
    ReadonlyMap<string, object>
  >();
  private static readonly executingOperations = new Map<string, object>();

  public readonly filePath: string;
  public readonly lockPath: string;

  private initialized = false;
  private readonly commitTemporaryFile: NonNullable<
    UserDictionaryStorageOptions['commitTemporaryFile']
  >;
  private readonly closeLockHandle: NonNullable<
    UserDictionaryStorageOptions['closeLockHandle']
  >;
  private readonly lockRetryMs: number;
  private readonly lockWaitMs: number;
  private readonly staleLockAgeMs: number;

  public constructor(
    private readonly directory: string,
    options: UserDictionaryStorageOptions = {}
  ) {
    this.filePath = path.join(directory, 'entries.json');
    this.lockPath = path.join(directory, 'entries.json.lock');
    this.commitTemporaryFile = options.commitTemporaryFile ?? rename;
    this.closeLockHandle = options.closeLockHandle ?? ((handle) => handle.close());
    this.lockRetryMs = options.lockRetryMs ?? DEFAULT_LOCK_RETRY_MS;
    this.lockWaitMs = options.lockWaitMs ?? DEFAULT_LOCK_WAIT_MS;
    this.staleLockAgeMs = options.staleLockAgeMs ?? DEFAULT_STALE_LOCK_AGE_MS;
  }

  public initialize(): Promise<UserDictionaryStore> {
    return this.runSerialized('initialize', () => this.initializeUnserialized());
  }

  public read(): Promise<UserDictionaryStore> {
    return this.runSerialized('read', () => this.readUnserialized());
  }

  public write(store: UserDictionaryStore): Promise<void> {
    return this.runSerialized('write', () => this.writeUnserialized(store));
  }

  public update(
    mutate: (
      current: UserDictionaryStore
    ) => UserDictionaryStore | Promise<UserDictionaryStore>
  ): Promise<UserDictionaryStore> {
    return this.runSerialized('update', () => this.updateUnserialized(mutate));
  }

  private async initializeUnserialized(): Promise<UserDictionaryStore> {
    if (this.initialized) return this.readInitializedStore();

    await this.ensureDirectory();
    try {
      const store = await this.readStoreFile();
      this.initialized = true;
      return store;
    } catch (error) {
      if (!isFileMissing(error)) throw this.asReadError(error);
    }

    const store = await this.withLock(async () => {
      try {
        return await this.readStoreFile();
      } catch (error) {
        if (!isFileMissing(error)) throw this.asReadError(error);
      }
      const emptyStore = emptyUserDictionaryStore();
      await this.writeFileAtomically(emptyStore);
      return emptyStore;
    });
    this.initialized = true;
    return store;
  }

  private async readUnserialized(): Promise<UserDictionaryStore> {
    if (!this.initialized) return this.initializeUnserialized();
    return this.readInitializedStore();
  }

  private async writeUnserialized(store: UserDictionaryStore): Promise<void> {
    const canonicalJson = this.canonicalJson(store);
    if (!this.initialized) await this.initializeUnserialized();

    try {
      await this.withLock(async () => {
        await this.assertStoreExists();
        await this.writeCanonicalJsonAtomically(canonicalJson);
      });
    } catch (error) {
      if (error instanceof UserDictionaryStorageError) throw error;
      throw new UserDictionaryStorageError(
        'storageFailure',
        `Could not write User Dictionary store at ${this.filePath}.`,
        error
      );
    }
  }

  private async updateUnserialized(
    mutate: (
      current: UserDictionaryStore
    ) => UserDictionaryStore | Promise<UserDictionaryStore>,
  ): Promise<UserDictionaryStore> {
    if (!this.initialized) await this.ensureDirectory();

    try {
      const updated = await this.withLock(async (lockToken) => {
        let current: UserDictionaryStore;
        let storeExists = true;
        let readCanonicalJson: string | undefined;
        try {
          const readStore = await this.readStoreFileWithCanonicalJson();
          current = readStore.store;
          readCanonicalJson = readStore.canonicalJson;
        } catch (error) {
          if (!this.initialized && isFileMissing(error)) {
            current = emptyUserDictionaryStore();
            storeExists = false;
          } else if (isFileMissing(error)) {
            throw new UserDictionaryStorageError(
              'corruptStore',
              `Initialized User Dictionary store is missing at ${this.filePath}.`,
              error
            );
          } else {
            throw this.asReadError(error);
          }
        }
        const updated = await mutate(current);
        if (storeExists) await this.assertStoreExists();
        await this.assertLockOwnership(lockToken);
        await this.writeFileAtomically(updated, {
          lockToken,
          readCanonicalJson
        });
        return updated;
      });
      this.initialized = true;
      return updated;
    } catch (error) {
      if (error instanceof UserDictionaryStorageError) throw error;
      throw new UserDictionaryStorageError(
        'storageFailure',
        `Could not update User Dictionary store at ${this.filePath}.`,
        error
      );
    }
  }

  private async runSerialized<T>(
    method: 'initialize' | 'read' | 'write' | 'update',
    operation: () => Promise<T>
  ): Promise<T> {
    // Mutual exclusion does not promise first-in, first-out invocation order because
    // each call resolves its asynchronous directory key before it joins the chain.
    const directoryKey = await directoryChainKey(this.directory);
    const inheritedOperation = UserDictionaryStorage.operationContexts
      .getStore()?.get(directoryKey);
    if (inheritedOperation !== undefined &&
        UserDictionaryStorage.executingOperations.get(directoryKey) === inheritedOperation) {
      throw new UserDictionaryStorageError(
        'reentrantAccess',
        `Cannot call User Dictionary ${method} during another operation for the same directory.`
      );
    }

    const previous = UserDictionaryStorage.operationChains.get(directoryKey) ?? Promise.resolve();
    const operationIdentity = {};
    const result = previous.catch(() => undefined).then(async () => {
      const operationContext = new Map(UserDictionaryStorage.operationContexts.getStore());
      operationContext.set(directoryKey, operationIdentity);
      UserDictionaryStorage.executingOperations.set(directoryKey, operationIdentity);
      try {
        return await UserDictionaryStorage.operationContexts.run(
          operationContext,
          operation
        );
      } finally {
        if (UserDictionaryStorage.executingOperations.get(directoryKey) === operationIdentity) {
          UserDictionaryStorage.executingOperations.delete(directoryKey);
        }
      }
    });
    const settled = result.then(() => undefined, () => undefined);
    UserDictionaryStorage.operationChains.set(directoryKey, settled);
    try {
      return await result;
    } finally {
      if (UserDictionaryStorage.operationChains.get(directoryKey) === settled) {
        UserDictionaryStorage.operationChains.delete(directoryKey);
      }
    }
  }

  private async readInitializedStore(): Promise<UserDictionaryStore> {
    try {
      return await this.readStoreFile();
    } catch (error) {
      if (isFileMissing(error)) {
        throw new UserDictionaryStorageError(
          'corruptStore',
          `Initialized User Dictionary store is missing at ${this.filePath}.`,
          error
        );
      }
      throw this.asReadError(error);
    }
  }

  private async readStoreFile(): Promise<UserDictionaryStore> {
    return (await this.readStoreFileWithCanonicalJson()).store;
  }

  private async readStoreFileWithCanonicalJson(): Promise<{
    store: UserDictionaryStore;
    canonicalJson: string;
  }> {
    const canonicalJson = await readFile(this.filePath, 'utf8');
    return {
      store: importUserDictionaryJson(canonicalJson),
      canonicalJson
    };
  }

  private asReadError(error: unknown): UserDictionaryStorageError {
    if (error instanceof UserDictionaryStorageError) return error;
    if (isDataError(error)) {
      return new UserDictionaryStorageError(
        'corruptStore',
        `User Dictionary store is corrupt at ${this.filePath}.`,
        error
      );
    }
    return new UserDictionaryStorageError(
      'storageFailure',
      `Could not read User Dictionary store at ${this.filePath}.`,
      error
    );
  }

  private canonicalJson(store: UserDictionaryStore): string {
    try {
      return exportUserDictionaryJson(store);
    } catch (error) {
      throw new UserDictionaryStorageError(
        'storageFailure',
        `Could not serialize User Dictionary store${
          error instanceof Error ? `: ${error.message}` : '.'
        }`,
        error
      );
    }
  }

  private async ensureDirectory(): Promise<void> {
    try {
      await mkdir(this.directory, { recursive: true });
    } catch (error) {
      throw new UserDictionaryStorageError(
        'storageFailure',
        `Could not create User Dictionary directory ${this.directory}.`,
        error
      );
    }
  }

  private async assertStoreExists(): Promise<void> {
    try {
      await stat(this.filePath);
    } catch (error) {
      if (isFileMissing(error)) {
        throw new UserDictionaryStorageError(
          'corruptStore',
          `Initialized User Dictionary store is missing at ${this.filePath}.`,
          error
        );
      }
      throw error;
    }
  }

  private async withLock<T>(operation: (lockToken: string) => Promise<T>): Promise<T> {
    const lock = await this.acquireLock();
    const stopRefreshing = this.startLockRefresh(lock);
    try {
      return await operation(lock.token);
    } finally {
      try {
        await stopRefreshing();
      } finally {
        // The release belongs in the close's finally. If close rejects, an adjacent
        // release await is skipped and leaves the store locked until stale recovery.
        try {
          await this.closeLockHandle(lock.handle);
        } finally {
          await this.releaseLock(lock.token);
        }
      }
    }
  }

  private async acquireLock(): Promise<{
    handle: LockHandle;
    token: string;
    createdAt: string;
  }> {
    const startedAt = Date.now();
    while (true) {
      const token = randomUUID();
      try {
        const handle = await open(this.lockPath, 'wx', 0o600);
        const createdAt = new Date().toISOString();
        try {
          await handle.writeFile(JSON.stringify({
            token,
            pid: (globalThis as unknown as { process: { pid: number } }).process.pid,
            createdAt,
            refreshedAt: createdAt
          }), 'utf8');
        } catch (error) {
          try {
            await handle.close();
          } finally {
            await rm(this.lockPath, { force: true });
          }
          throw error;
        }
        return { handle, token, createdAt };
      } catch (error) {
        if (!isAlreadyExists(error)) {
          throw new UserDictionaryStorageError(
            'storageFailure',
            `Could not acquire User Dictionary lock ${this.lockPath}.`,
            error
          );
        }
      }

      if (await this.breakStaleLock()) continue;
      if (Date.now() - startedAt >= this.lockWaitMs) {
        throw new UserDictionaryStorageError(
          'lockTimeout',
          `Timed out waiting for User Dictionary lock ${this.lockPath}.`
        );
      }
      await delay(this.lockRetryMs);
    }
  }

  private startLockRefresh(
    lock: { handle: LockHandle; token: string; createdAt: string }
  ): () => Promise<void> {
    const intervalMs = Math.max(1, Math.floor(this.staleLockAgeMs / 3));
    let stopped = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let wake: (() => void) | undefined;
    let refreshError: unknown;
    const completed = (async () => {
      while (!stopped) {
        await new Promise<void>((resolve) => {
          wake = resolve;
          timer = setTimeout(resolve, intervalMs);
        });
        timer = undefined;
        wake = undefined;
        if (stopped) break;
        try {
          await this.refreshLock(lock);
        } catch (error) {
          refreshError = error;
          break;
        }
      }
    })();

    return async () => {
      stopped = true;
      if (timer !== undefined) clearTimeout(timer);
      wake?.();
      await completed;
      if (refreshError !== undefined) {
        throw new UserDictionaryStorageError(
          'storageFailure',
          `Could not refresh User Dictionary lock ${this.lockPath}.`,
          refreshError
        );
      }
    };
  }

  private async refreshLock(lock: {
    handle: LockHandle;
    token: string;
    createdAt: string;
  }): Promise<void> {
    const content = JSON.stringify({
      token: lock.token,
      pid: (globalThis as unknown as { process: { pid: number } }).process.pid,
      createdAt: lock.createdAt,
      refreshedAt: new Date().toISOString()
    });
    let offset = 0;
    while (offset < content.length) {
      const { bytesWritten } = await lock.handle.write(
        content.slice(offset),
        offset,
        'utf8'
      );
      if (bytesWritten <= 0) throw new Error('Lock refresh wrote no bytes.');
      offset += bytesWritten;
    }
  }

  private async breakStaleLock(): Promise<boolean> {
    try {
      const lockStat = await stat(this.lockPath);
      let createdAtMs = lockStat.mtimeMs;
      try {
        const lock = JSON.parse(await readFile(this.lockPath, 'utf8')) as {
          createdAt?: unknown;
          refreshedAt?: unknown;
        };
        if (typeof lock.refreshedAt === 'string' &&
            Number.isFinite(Date.parse(lock.refreshedAt))) {
          createdAtMs = Date.parse(lock.refreshedAt);
        } else if (typeof lock.createdAt === 'string' &&
                   Number.isFinite(Date.parse(lock.createdAt))) {
          createdAtMs = Date.parse(lock.createdAt);
        }
      } catch {
        // A process can crash partway through writing its lock metadata. The file's
        // modification time remains a safe age fallback for that incomplete lock.
      }
      if (Date.now() - createdAtMs <= this.staleLockAgeMs) return false;

      // Rename first so two recoverers cannot both delete whichever lock currently
      // occupies lockPath. Only one can claim this stale file.
      const stalePath = path.join(
        this.directory,
        `entries.json.lock.stale-${randomUUID()}`
      );
      try {
        await rename(this.lockPath, stalePath);
      } catch (error) {
        if (isFileMissing(error)) return true;
        throw error;
      }
      await rm(stalePath, { force: true });
      return true;
    } catch (error) {
      if (isFileMissing(error)) return true;
      throw new UserDictionaryStorageError(
        'storageFailure',
        `Could not inspect User Dictionary lock ${this.lockPath}.`,
        error
      );
    }
  }

  private async assertLockOwnership(token: string): Promise<void> {
    try {
      const content = await readFile(this.lockPath, 'utf8');
      const lock = JSON.parse(content) as { token?: unknown };
      if (lock.token === token) return;
    } catch (error) {
      if (!isFileMissing(error)) {
        throw new UserDictionaryStorageError(
          'lockLost',
          `Lost ownership of User Dictionary lock ${this.lockPath}.`,
          error
        );
      }
    }
    throw new UserDictionaryStorageError(
      'lockLost',
      `Lost ownership of User Dictionary lock ${this.lockPath}.`
    );
  }

  private async assertStoreUnchanged(
    readCanonicalJson: string,
    activeTemporaryPath: string,
    lockToken: string
  ): Promise<void> {
    let currentCanonicalJson: string;
    try {
      currentCanonicalJson = await readFile(this.filePath, 'utf8');
    } catch (error) {
      if (isFileMissing(error)) {
        throw new UserDictionaryStorageError(
          'corruptStore',
          `Initialized User Dictionary store is missing at ${this.filePath}.`,
          error
        );
      }
      throw this.asReadError(error);
    }
    if (currentCanonicalJson !== readCanonicalJson) {
      await this.assertLockOwnership(lockToken);
      throw new UserDictionaryStorageError(
        'staleWrite',
        `User Dictionary store changed before commit at ${this.filePath}.`
      );
    }
    await this.removeAbandonedTemporaryFiles(activeTemporaryPath);
  }

  private async removeAbandonedTemporaryFiles(activeTemporaryPath: string): Promise<void> {
    const names = await readdir(this.directory) as string[];
    await Promise.all(names
      .filter((name) => name.startsWith('entries.json.') && name.endsWith('.tmp'))
      .filter((name) => path.join(this.directory, name) !== activeTemporaryPath)
      .map((name) => rm(path.join(this.directory, name), { force: true })));
  }

  private async releaseLock(token: string): Promise<void> {
    try {
      const content = await readFile(this.lockPath, 'utf8');
      const lock = JSON.parse(content) as { token?: unknown };
      if (lock.token === token) await rm(this.lockPath, { force: true });
    } catch (error) {
      if (isFileMissing(error)) return;
      throw error;
    }
  }

  private async writeFileAtomically(
    store: UserDictionaryStore,
    commitGuard?: { lockToken: string; readCanonicalJson?: string }
  ): Promise<void> {
    await this.writeCanonicalJsonAtomically(this.canonicalJson(store), commitGuard);
  }

  private async writeCanonicalJsonAtomically(
    content: string,
    commitGuard?: { lockToken: string; readCanonicalJson?: string }
  ): Promise<void> {
    const temporaryPath = path.join(
      this.directory,
      `entries.json.${randomUUID()}.tmp`
    );
    let temporaryHandle: LockHandle | undefined;
    try {
      const handle = await open(temporaryPath, 'wx', 0o600) as LockHandle;
      temporaryHandle = handle;
      await handle.writeFile(content, 'utf8');
      await handle.sync();
      await handle.close();
      temporaryHandle = undefined;
      if (commitGuard?.readCanonicalJson !== undefined) {
        await this.assertStoreUnchanged(
          commitGuard.readCanonicalJson,
          temporaryPath,
          commitGuard.lockToken
        );
      }
      if (commitGuard) await this.assertLockOwnership(commitGuard.lockToken);
      await this.commitTemporaryFile(temporaryPath, this.filePath);
    } catch (error) {
      if (temporaryHandle) {
        try {
          await temporaryHandle.close();
        } catch {
          // Preserve the original failure; cleanup below remains best effort.
        }
      }
      await rm(temporaryPath, { force: true }).catch(() => undefined);
      if (commitGuard && !(error instanceof UserDictionaryStorageError)) {
        try {
          await this.assertLockOwnership(commitGuard.lockToken);
        } catch (ownershipError) {
          if (ownershipError instanceof UserDictionaryStorageError &&
              ownershipError.code === 'lockLost') {
            throw ownershipError;
          }
        }
      }
      if (error instanceof UserDictionaryStorageError) throw error;
      throw new UserDictionaryStorageError(
        'storageFailure',
        `Could not commit User Dictionary store at ${this.filePath}.`,
        error
      );
    }
  }
}

function isNodeError(error: unknown): error is Error & { code?: string } {
  return error instanceof Error && 'code' in error;
}

function isFileMissing(error: unknown): boolean {
  return isNodeError(error) && error.code === 'ENOENT';
}

function isAlreadyExists(error: unknown): boolean {
  return isNodeError(error) && error.code === 'EEXIST';
}

function isDataError(error: unknown): boolean {
  return error instanceof SyntaxError ||
    (error instanceof Error && (
      error.name === 'UserDictionaryImportError' ||
      error.name === 'UserDictionaryValidationError'
    ));
}

async function directoryChainKey(directory: string): Promise<string> {
  const resolved = path.resolve(directory);
  const unresolvedSegments: string[] = [];
  let ancestor = resolved;
  let key = resolved;
  while (true) {
    try {
      const canonicalAncestor = await realpath(ancestor);
      key = path.join(canonicalAncestor, ...unresolvedSegments);
      break;
    } catch {
      const parent = path.dirname(ancestor);
      if (parent === ancestor) break;
      unresolvedSegments.unshift(path.basename(ancestor));
      ancestor = parent;
    }
  }

  // realpath on the nearest existing ancestor unifies symbolic-link and junction
  // aliases even when the directory itself does not exist yet. Appending the
  // unresolved remainder preserves the requested cold path. Windows case folding
  // also unifies case-only aliases. Paths that the platform reports as different
  // real paths remain different keys.
  //
  // Known limitation, found by verification on 2026-08-16 and accepted rather than fixed.
  // Windows supports per-directory case sensitivity, so `Foo` and `foo` can be genuinely
  // different directories. This lowercasing gives them one key, so they serialize against
  // each other unnecessarily. That is the safe direction to be wrong in: they block a
  // little, they never lose a write. Enabling the flag needs elevation and is rare, and
  // the alternative, treating case-only aliases as different on ordinary NTFS, would split
  // one real directory into two chains and lose data. Blocking beats losing.
  const platform = (globalThis as unknown as { process: { platform: string } }).process.platform;
  return platform === 'win32' ? key.toLowerCase() : key;
}

function delay(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
