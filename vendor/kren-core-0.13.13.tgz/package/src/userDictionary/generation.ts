import { isPlausibleLanguageCode } from '../validation.js';
import type {
  UserDictionaryCaptureMode,
  UserDictionaryEntryV1,
  UserDictionaryProvider
} from './contract.js';
import { normalizeUserDictionaryTerm } from './normalization.js';
import { validateUserDictionaryEntry } from './validation.js';

const USER_DICTIONARY_EXPRESSION_MAX_CHARACTERS = 200;
const USER_DICTIONARY_EXPRESSION_MAX_WORDS = 16;

export interface UserDictionaryCaptureSettings {
  captureMode?: UserDictionaryCaptureMode;
  entryLanguage: string;
  includePronunciation: boolean;
  includeSynonyms: boolean;
  includeUsageNotes: boolean;
  numberOfExamples: number;
  includeTechnicalMeanings: boolean;
}

interface GeneratedSense {
  partOfSpeech: string;
  definition: string;
  usageNote: string;
  synonyms: string[];
  antonyms: string[];
  relatedTerms: string[];
  examples: string[];
}

interface GeneratedDictionaryContent {
  term?: string;
  language: string;
  entryType: string;
  domains: string[];
  tags: string[];
  pronunciation: string;
  senses: GeneratedSense[];
  aliases: string[];
}

export class UserDictionaryMalformedOutputError extends Error {
  public constructor() {
    super('The selected language-model provider returned malformed User Dictionary output. No entry was saved.');
    this.name = 'UserDictionaryMalformedOutputError';
  }
}

export const USER_DICTIONARY_GENERATION_SCHEMA: Record<string, unknown> = {
  type: 'object',
  additionalProperties: false,
  required: [
    'term', 'language', 'entryType', 'domains', 'tags', 'pronunciation', 'senses', 'aliases'
  ],
  properties: {
    term: { type: 'string' },
    language: { type: 'string' },
    entryType: { type: 'string' },
    domains: { type: 'array', items: { type: 'string' }, maxItems: 12 },
    tags: { type: 'array', items: { type: 'string' }, maxItems: 20 },
    pronunciation: { type: 'string' },
    senses: {
      type: 'array',
      minItems: 1,
      maxItems: 12,
      items: {
        type: 'object',
        additionalProperties: false,
        required: [
          'partOfSpeech', 'definition', 'usageNote', 'synonyms', 'antonyms',
          'relatedTerms', 'examples'
        ],
        properties: {
          partOfSpeech: { type: 'string' },
          definition: { type: 'string' },
          usageNote: { type: 'string' },
          synonyms: { type: 'array', items: { type: 'string' }, maxItems: 20 },
          antonyms: { type: 'array', items: { type: 'string' }, maxItems: 20 },
          relatedTerms: { type: 'array', items: { type: 'string' }, maxItems: 20 },
          examples: { type: 'array', items: { type: 'string' }, maxItems: 3 }
        }
      }
    },
    aliases: { type: 'array', items: { type: 'string' }, maxItems: 20 }
  }
};

export interface UserDictionaryGenerationOptions {
  /**
   * True when the expression came from the user typing it rather than from a document
   * selection. Regenerating after editing the Expression field is the case that matters:
   * the user has already decided the headword, so proposing a different citation form
   * overrules a deliberate choice. Selecting "attached" in a document is ambiguous;
   * typing it into the field and asking again is not.
   */
  termSuppliedByUser?: boolean;
}

export function userDictionaryGenerationInstruction(
  settings: UserDictionaryCaptureSettings,
  options: UserDictionaryGenerationOptions = {}
): string {
  const language = settings.entryLanguage === 'auto'
    ? 'Detect the expression language and return its BCP-47 language tag.'
    : `Use the BCP-47 entry language ${settings.entryLanguage}.`;
  return [
    'Create a concise personal dictionary draft for exactly the expression supplied by the user.',
    'No surrounding document context exists. Do not infer a file, workspace, author, audience, or unstated context.',
    language,
    'The term is the citation form of the lexical unit actually being recorded, not the lemma of its first word, and this is not blind lemmatisation.',
    'When the selection is one lexical item in an inflected form, lemmatise that lexical item: "showed up" becomes "show up", and "shows" becomes "show".',
    'Keep the selected form unchanged when it is a phrase or clause rather than one lexical item: "an image attached to an email" stays "an image attached to an email".',
    'Keep an inflected-looking form unchanged when it is itself a distinct lexical item: the noun "meaning" stays "meaning", not "mean".',
    'Keep a participle unchanged only when the selection itself contains the noun it modifies: "attached" in "the attached file" stays "attached", not "attach".',
    'A past-tense or participle form standing alone is a verb form, because no surrounding context exists to make it an adjective: "attached" alone becomes "attach", and "showed" alone becomes "show".',
    options.termSuppliedByUser
      ? 'The user supplied this expression directly rather than selecting it from a document, so it is already the term they want. Return it in term exactly as given, with no citation-form change, and describe that exact form.'
      : 'Return this citation form in term.',
    // OpenAI and Anthropic receive the schema, but Gemini cannot. The instruction
    // therefore repeats the shape literally, and a test keeps both statements aligned.
    'Return JSON only, with exactly this shape and no other keys:',
    '{"term":"citation form","language":"BCP-47 tag","entryType":"short label","domains":[],"tags":[],' +
      '"pronunciation":"","senses":[{"partOfSpeech":"","definition":"","usageNote":"",' +
      '"synonyms":[],"antonyms":[],"relatedTerms":[],"examples":[]}],"aliases":[]}',
    'Use at least one sense with a non-empty definition. Keep every claim within ordinary lexical knowledge.',
    settings.includePronunciation
      ? 'Include a readable pronunciation when appropriate; otherwise return an empty pronunciation string.'
      : 'Return an empty pronunciation string.',
    settings.includeSynonyms
      ? 'Include relevant synonyms, antonyms, and related expressions.'
      : 'Return empty synonyms, antonyms, and relatedTerms arrays.',
    settings.includeUsageNotes
      ? 'Include a short usage note only when it prevents misunderstanding.'
      : 'Return an empty usageNote string for every sense.',
    'Put in aliases the other surface forms a reader might search for: irregular inflected forms such as "gave" and "given" for "give", and spelling variants. Omit regular forms a reader can predict, and never repeat the term itself.',
    `Return no more than ${settings.numberOfExamples} example${settings.numberOfExamples === 1 ? '' : 's'} per sense.`,
    settings.includeTechnicalMeanings
      ? 'Include established technical meanings when they are genuinely applicable.'
      : 'Do not add a technical sense solely because one might exist.'
  ].join('\n');
}

export function assembleUserDictionaryDraft(
  expression: string,
  settings: UserDictionaryCaptureSettings,
  provider: UserDictionaryProvider,
  model: string,
  value: unknown,
  now: () => string = () => new Date().toISOString(),
  uuid: () => string = () => globalThis.crypto.randomUUID(),
  options: UserDictionaryGenerationOptions = {}
): UserDictionaryEntryV1 {
  const content = validateGeneratedContent(value);
  // Both clients expose term as an editable field. That is the safety net for a poor
  // model judgement, so core deliberately does not invent a semantic similarity check.
  // A user-typed expression is the term by definition, so the model's proposal is
  // discarded rather than trusted. Enforced here as well as in the instruction, because
  // an instruction is a request and this is a promise.
  const term = options.termSuppliedByUser ? expression : (content.term ?? expression);
  const aliases = [...content.aliases];
  const normalizedExpression = normalizeUserDictionaryTerm(expression);
  if (normalizedExpression !== normalizeUserDictionaryTerm(term) &&
      !aliases.some((alias) => normalizeUserDictionaryTerm(alias) === normalizedExpression)) {
    aliases.push(expression);
  }
  const timestamp = now();
  const entry: UserDictionaryEntryV1 = {
    schemaVersion: 1,
    id: uuid(),
    term,
    normalizedTerm: normalizeUserDictionaryTerm(term),
    language: settings.entryLanguage === 'auto' ? content.language : settings.entryLanguage,
    entryType: content.entryType,
    collection: 'Other',
    domains: content.domains,
    tags: content.tags,
    ...(settings.includePronunciation && content.pronunciation
      ? { pronunciation: { display: content.pronunciation, audioAvailable: false } }
      : {}),
    senses: content.senses.map((sense) => ({
      id: uuid(),
      ...(sense.partOfSpeech ? { partOfSpeech: sense.partOfSpeech } : {}),
      definition: sense.definition,
      ...(settings.includeUsageNotes && sense.usageNote
        ? { usageNote: sense.usageNote }
        : {}),
      synonyms: settings.includeSynonyms ? sense.synonyms : [],
      antonyms: settings.includeSynonyms ? sense.antonyms : [],
      relatedTerms: settings.includeSynonyms ? sense.relatedTerms : [],
      examples: sense.examples.slice(0, settings.numberOfExamples)
    })),
    aliases,
    capture: {
      mode: settings.captureMode === 'merriamWebsterAndLlm'
        ? 'merriamWebsterAndLlm'
        : 'llmOnly',
      provider,
      model,
      generatedAt: timestamp,
      userEdited: false
    },
    createdAt: timestamp,
    updatedAt: timestamp
  };
  try {
    return validateUserDictionaryEntry(entry);
  } catch {
    throw new UserDictionaryMalformedOutputError();
  }
}

function validateGeneratedContent(value: unknown): GeneratedDictionaryContent {
  if (!isRecord(value) || !hasExpectedGeneratedFields(value)) {
    throw new UserDictionaryMalformedOutputError();
  }
  if (typeof value.language !== 'string' || !isPlausibleLanguageCode(value.language) ||
      typeof value.entryType !== 'string' || !value.entryType.trim() ||
      typeof value.pronunciation !== 'string' ||
      !isStringArray(value.domains, 12) || !isStringArray(value.tags, 20) ||
      !isStringArray(value.aliases, 20) || !Array.isArray(value.senses) ||
      value.senses.length < 1 || value.senses.length > 12) {
    throw new UserDictionaryMalformedOutputError();
  }
  const senses = value.senses.map((sense) => validateGeneratedSense(sense));
  const term = validGeneratedTerm(value.term);
  return {
    ...(term ? { term } : {}),
    language: value.language,
    entryType: value.entryType.trim(),
    domains: cleanStrings(value.domains),
    tags: cleanStrings(value.tags),
    pronunciation: value.pronunciation.trim(),
    senses,
    aliases: cleanStrings(value.aliases)
  };
}

function validateGeneratedSense(value: unknown): GeneratedSense {
  if (!isRecord(value) || !hasExactFields(value, [
    'partOfSpeech', 'definition', 'usageNote', 'synonyms', 'antonyms',
    'relatedTerms', 'examples'
  ]) || typeof value.partOfSpeech !== 'string' || typeof value.definition !== 'string' ||
      !value.definition.trim() || typeof value.usageNote !== 'string' ||
      !isStringArray(value.synonyms, 20) || !isStringArray(value.antonyms, 20) ||
      !isStringArray(value.relatedTerms, 20) || !isStringArray(value.examples, 3)) {
    throw new UserDictionaryMalformedOutputError();
  }
  return {
    partOfSpeech: value.partOfSpeech.trim(),
    definition: value.definition.trim(),
    usageNote: value.usageNote.trim(),
    synonyms: cleanStrings(value.synonyms),
    antonyms: cleanStrings(value.antonyms),
    relatedTerms: cleanStrings(value.relatedTerms),
    examples: cleanStrings(value.examples)
  };
}

function validGeneratedTerm(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const term = value.trim();
  if (!term || term.length > USER_DICTIONARY_EXPRESSION_MAX_CHARACTERS ||
      /[\r\n\0]/u.test(term) || term.split(/\s+/u).length > USER_DICTIONARY_EXPRESSION_MAX_WORDS) {
    return undefined;
  }
  return term;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function hasExpectedGeneratedFields(value: Record<string, unknown>): boolean {
  const required = [
    'language', 'entryType', 'domains', 'tags', 'pronunciation', 'senses', 'aliases'
  ];
  const allowed = new Set(['term', ...required]);
  return required.every((field) => Object.hasOwn(value, field)) &&
    Object.keys(value).every((field) => allowed.has(field));
}

function hasExactFields(value: Record<string, unknown>, fields: readonly string[]): boolean {
  const expected = new Set(fields);
  return Object.keys(value).length === expected.size &&
    Object.keys(value).every((field) => expected.has(field));
}

function isStringArray(value: unknown, maximum: number): value is string[] {
  return Array.isArray(value) && value.length <= maximum &&
    value.every((item) => typeof item === 'string');
}

function cleanStrings(values: string[]): string[] {
  return values.map((value) => value.trim()).filter(Boolean);
}
