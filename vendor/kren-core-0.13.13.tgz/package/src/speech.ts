/** Produces the bounded, artifact-free copy sent to the selected speech engine. */
export function prepareTextForSpeech(text: string): string {
  return text
    .normalize('NFC')
    .replace(/```[\s\S]*?```/gu, ' ')
    .replace(/~~~[\s\S]*?~~~/gu, ' ')
    .replace(/!\[[^\]]*\]\([^)]*\)/gu, ' ')
    .replace(/\[([^\]]+)\]\((?:[^()]|\([^)]*\))*\)/gu, '$1')
    .replace(/\[([^\]]+)\]\[[^\]]*\]/gu, '$1')
    .replace(/<https?:\/\/[^>]+>/giu, ' ')
    .replace(/<[^>]+>/gu, ' ')
    .replace(/https?:\/\/\S+/giu, ' ')
    .replace(/\[(?:\s|x|X)\]/gu, ' ')
    .replace(/\[\^(?:[^\]]+)\]/gu, ' ')
    .replace(/\[(?:@[^\]]+|\d+(?:\s*[-,;]\s*\d+)*)\]/gu, ' ')
    .replace(/^\s{0,3}(?:#{1,6}|>|[-+*]|\d+[.)])\s+/gmu, '')
    .replace(/^\s*\|?(?:\s*:?-{3,}:?\s*\|)+\s*$/gmu, ' ')
    .replace(/[|]/gu, ' ')
    .replace(/[`*_~]/gu, '')
    .replace(/&nbsp;/giu, ' ')
    .replace(/&amp;/giu, ' and ')
    .replace(/&(?:lt|gt|quot|apos);/giu, ' ')
    .replace(/[\u200B-\u200D\u2060\uFEFF]/gu, '')
    .replace(/\s+/gu, ' ')
    .replace(/\s+([,.;:!?])/gu, '$1')
    .trim()
    .slice(0, 20_000);
}
