export interface RetryStatusOptions {
  retryNotFound?: boolean;
  retryNotImplemented?: boolean;
}

export interface RetryDelayOptions {
  baseDelayMs?: number;
  maxBackoffMs?: number;
  maxRetryAfterMs?: number;
  jitterMs?: number;
  parseHttpDate?: boolean;
  now?: () => number;
  random?: () => number;
}

export interface RetryWaitOptions {
  abortReason?: () => unknown;
}

export function isRetryableLanguageModelStatus(
  status: number,
  options: RetryStatusOptions = {}
): boolean {
  if (status === 404) return options.retryNotFound === true;
  if (status === 501) return options.retryNotImplemented !== false;
  return status === 408 ||
    status === 429 ||
    status === 500 ||
    status === 502 ||
    status === 503 ||
    status === 504;
}

export function retryDelayMs(
  attempt: number,
  retryAfter: string | null = null,
  options: RetryDelayOptions = {}
): number {
  const maxRetryAfterMs = options.maxRetryAfterMs ?? 20_000;
  const seconds = retryAfter ? Number.parseFloat(retryAfter) : Number.NaN;
  if (Number.isFinite(seconds) && seconds >= 0) {
    return Math.min(seconds * 1_000, maxRetryAfterMs);
  }

  if (options.parseHttpDate === true) {
    const retryAt = retryAfter ? Date.parse(retryAfter) : Number.NaN;
    if (Number.isFinite(retryAt)) {
      return Math.max(
        0,
        Math.min(retryAt - (options.now ?? Date.now)(), maxRetryAfterMs)
      );
    }
  }

  const normalizedAttempt = Math.max(0, Number.isFinite(attempt) ? Math.floor(attempt) : 0);
  const baseDelayMs = options.baseDelayMs ?? 1_000;
  const jitterMs = Math.max(0, options.jitterMs ?? 0);
  const random = options.random ?? Math.random;
  const jitter = jitterMs > 0 ? Math.floor(random() * (jitterMs + 1)) : 0;
  return Math.min(
    options.maxBackoffMs ?? 12_000,
    baseDelayMs * 2 ** normalizedAttempt + jitter
  );
}

export function waitForRetry(
  milliseconds: number,
  signal: AbortSignal,
  options: RetryWaitOptions = {}
): Promise<void> {
  return new Promise((resolve, reject) => {
    const abortReason = (): unknown =>
      options.abortReason
        ? options.abortReason()
        : new DOMException('The request was aborted.', 'AbortError');

    if (signal.aborted) {
      reject(abortReason());
      return;
    }

    const onAbort = (): void => {
      clearTimeout(timeout);
      signal.removeEventListener('abort', onAbort);
      reject(abortReason());
    };
    const timeout = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, Math.max(0, milliseconds));
    signal.addEventListener('abort', onAbort, { once: true });
  });
}
