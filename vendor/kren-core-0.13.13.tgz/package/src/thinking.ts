import type { LanguageModelEffort } from './contracts.js';

/**
 * What Gemini receives for a thinking setting, which is one field or the other and never
 * both.
 *
 * Gemini has two generations of this parameter and they are mutually exclusive: sending
 * `thinkingLevel` and `thinkingBudget` together is a 400. Gemini 3 models take
 * `thinkingLevel`, an ordered name. Gemini 2.5 models take `thinkingBudget`, a token count
 * with two reserved values, where -1 means the model decides and 0 means do not think.
 * `thinkingBudget` is still accepted on Gemini 3 for backwards compatibility, and Google
 * warns that using it there can behave unexpectedly, so KREN sends the parameter that
 * belongs to the model rather than the one that merely still works.
 */
export interface GeminiThinkingConfig {
  readonly thinkingLevel?: 'minimal' | 'low' | 'medium' | 'high';
  readonly thinkingBudget?: number;
}

/**
 * KREN's three points on the Gemini 2.5 budget scale.
 *
 * These are KREN's choice, not Google's: the API documents a range rather than named
 * steps. All three sit inside both published ranges, which are 0 to 24576 for 2.5 Flash and
 * 128 to 32768 for 2.5 Pro, so one table serves both without a second model check.
 */
const GEMINI_BUDGETS = { low: 1_024, medium: 8_192, high: 24_576 } as const;

/**
 * Whether this model takes `thinkingLevel` rather than `thinkingBudget`.
 *
 * An unrecognised name is treated as current rather than legacy, because the owner types
 * model IDs by hand as Google renames them, and a model KREN has never heard of is far more
 * likely to be newer than the ones it knows.
 */
export function geminiModelUsesThinkingLevel(model: string): boolean {
  const match = /gemini-(\d+)/u.exec(normalizeGeminiModel(model));
  if (!match?.[1]) return true;
  return Number(match[1]) >= 3;
}

export function normalizeGeminiModel(model: string): string {
  return model.trim().replace(/^models\//u, '').toLowerCase();
}

/**
 * The thinking configuration for one model and one setting, or undefined to send no
 * thinking configuration at all.
 *
 * Undefined is returned only for 'auto' on a Gemini 3 model, where omitting the field is
 * exactly what auto means: the model applies its own default. It is never a way to ask for
 * less thinking. Omitting the field on Gemini 2.5 would also mean the default, but there
 * -1 states the same intent explicitly, so it is sent.
 *
 * 'none' cannot be honoured literally on Gemini 3, which has no off switch, so it asks for
 * 'minimal', which Google describes as similar to no thinking. On Gemini 2.5 it is exact.
 */
export function geminiThinkingConfig(
  model: string,
  effort: LanguageModelEffort
): GeminiThinkingConfig | undefined {
  if (geminiModelUsesThinkingLevel(model)) {
    if (effort === 'auto') return undefined;
    return { thinkingLevel: effort === 'none' ? 'minimal' : effort };
  }
  switch (effort) {
    case 'auto': return { thinkingBudget: -1 };
    // 2.5 Pro cannot disable thinking and rejects a budget below 128. That is a provider
    // error the caller surfaces, not something to silently round up, because rounding 0 up
    // would spend tokens the user asked not to spend.
    case 'none': return { thinkingBudget: 0 };
    case 'minimal': return { thinkingBudget: 0 };
    default: return { thinkingBudget: GEMINI_BUDGETS[effort] };
  }
}

/**
 * Whether a provider rejection was about the thinking parameter itself.
 *
 * Which levels a Gemini 3 model accepts varies by model, and Google publishes it per model
 * rather than as a rule: Pro takes low and high, Flash adds medium and minimal. KREN cannot
 * hold a correct table of that for models the owner types by hand after a rename, so it
 * does not try. It asks for the setting, and if the model rejects the field, the caller
 * retries once without it and reports that the model chose its own level.
 *
 * Matching is on the field names, which appear in Google's message, rather than on a status
 * code alone, so an unrelated 400 is not swallowed.
 */
export function isGeminiThinkingRejection(message: string): boolean {
  return /thinking_?(level|budget)/iu.test(message);
}
