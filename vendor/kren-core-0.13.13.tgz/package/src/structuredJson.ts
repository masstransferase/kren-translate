export interface StructuredJsonOptions {
  trimBeforeFenceRemoval?: boolean;
}

/** Parses provider JSON that may be wrapped in one Markdown JSON code fence. */
export function parseStructuredJson(
  raw: string,
  options: StructuredJsonOptions = {}
): unknown {
  const input = options.trimBeforeFenceRemoval ? raw.trim() : raw;
  const cleaned = input
    .replace(/^```(?:json)?\s*/iu, '')
    .replace(/\s*```$/u, '');
  return JSON.parse(cleaned) as unknown;
}
